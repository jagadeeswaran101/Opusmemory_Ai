/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  PlayCircle,
  CheckCircle2,
  Brain,
  ArrowRight,
  Database,
  Activity,
  Zap,
  Sparkles,
  RefreshCw,
  Terminal,
  ShieldAlert,
  Sliders,
  AlertTriangle,
  FileText,
  Info,
  Clock,
  TrendingDown,
} from 'lucide-react';

interface TwoIncidentDemoViewProps {
  onRunSimulation: () => Promise<any>;
}

export const TwoIncidentDemoView: React.FC<TwoIncidentDemoViewProps> = ({
  onRunSimulation,
}) => {
  const [isRunning, setIsRunning] = useState(false);
  const [simulationResult, setSimulationResult] = useState<any | null>(null);
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [simulateFailure, setSimulateFailure] = useState(false);

  const handleStart = async () => {
    setIsRunning(true);
    try {
      const data = await onRunSimulation();
      setSimulationResult(data);
      setCurrentStep(7);
    } finally {
      setIsRunning(false);
    }
  };

  const steps = [
    {
      num: 1,
      title: 'Outage #1: Connection Pool Saturation',
      desc: 'SEV-1 alert fires on payments-db. Active pool maxes at 100/100 slots with error 53300.',
    },
    {
      num: 2,
      title: 'Ingest Synthetic Evidence',
      desc: 'Logs, Prometheus metric timeseries, and git diff attached to Incident #1.',
    },
    {
      num: 3,
      title: 'First AI Investigation',
      desc: 'Agent synthesizes 5-part report. No matching historical memory exists yet in Hindsight.',
    },
    {
      num: 4,
      title: 'Human SRE Applies Fix & Resolves',
      desc: 'Configures HikariCP maxLifetime & idleTimeout. Incident #1 marked RESOLVED.',
    },
    {
      num: 5,
      title: 'Knowledge Approval & Hindsight Retain',
      desc: 'Admin Elena approves postmortem. System commits verified playbook via hindsight.retain().',
    },
    {
      num: 6,
      title: 'Outage #2: Similar Incident Strikes',
      desc: '2 weeks later, checkout-db triggers identical SQLSTATE 53300 connection pool error.',
    },
    {
      num: 7,
      title: 'Cognitive Recall in Action!',
      desc: 'Hindsight instantly recalls Incident #1 with 94%+ similarity, citing the verified fix playbook!',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner with Stitch Styling */}
      <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center space-x-2.5">
            <PlayCircle className="w-6 h-6 text-cyan-400" />
            <h1 className="text-xl sm:text-2xl font-bold text-slate-100 tracking-tight font-sans">
              Two-Interaction Memory Reuse Studio
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800 font-bold">
              Phase 12 Demo Storyline
            </span>
          </div>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Witness how OpsMemory AI eliminates operational amnesia: Outage #1 is investigated and its verified fix is approved into institutional memory. When Outage #2 strikes 2 weeks later, Hindsight immediately recalls Outage #1, citing the exact root cause and playbook.
          </p>
        </div>

        <button
          onClick={handleStart}
          disabled={isRunning}
          className="flex items-center space-x-2 bg-gradient-to-r from-cyan-600 via-sky-600 to-emerald-600 hover:from-cyan-500 hover:to-emerald-500 text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl transition shadow-lg shadow-cyan-950/50 cursor-pointer shrink-0 disabled:opacity-50"
        >
          <Zap className={`w-4 h-4 ${isRunning ? 'animate-bounce' : ''}`} />
          <span>{isRunning ? 'Running Cognitive E2E Simulation...' : 'Execute Full Two-Interaction Storyline'}</span>
        </button>
      </div>

      {/* Human Comparison Delta (The "Why It Matters" Card) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Without Memory */}
        <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-rose-400 font-semibold text-xs uppercase tracking-wider">
              <Clock className="w-4 h-4" />
              <span>Without OpsMemory (Operational Amnesia)</span>
            </div>
            <span className="text-xs font-mono font-bold text-rose-400 tabular-nums">
              ~48.0 min MTTR
            </span>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-400 list-disc pl-4">
            <li>On-call engineer starts triage from scratch with zero institutional context.</li>
            <li>Repeated manual troubleshooting, rediscovering previously known configuration bugs.</li>
            <li>Postmortem knowledge stays trapped in forgotten Google Docs or Jira tickets.</li>
          </ul>
        </div>

        {/* With OpsMemory AI */}
        <div className="bg-gradient-to-br from-slate-900/90 to-indigo-950/40 border border-cyan-800/60 rounded-2xl p-5 space-y-3 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs uppercase tracking-wider">
              <Brain className="w-4 h-4 text-cyan-400" />
              <span>With OpsMemory AI (Hindsight Retain & Recall)</span>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 tabular-nums flex items-center">
              <TrendingDown className="w-3.5 h-3.5 mr-1" /> 3.5 min MTTR (-92%)
            </span>
          </div>
          <ul className="space-y-1.5 text-xs text-slate-300 list-disc pl-4">
            <li>Hindsight instantly recalls Outage #1 with <strong>94%+ symptom match</strong>.</li>
            <li>Agent cites verified <code>spring.datasource.hikari</code> parameters directly.</li>
            <li>Human approval ensures only verified, safe organizational knowledge is promoted.</li>
          </ul>
        </div>
      </div>

      {/* Narrative Interactive Stepper */}
      <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h2 className="text-sm font-semibold text-slate-100">
              Interactive Cognitive Lifecycle (7 Steps)
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Step {currentStep}/7 {currentStep === 7 && '· Verified'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2.5 pt-1">
          {steps.map((st) => (
            <div
              key={st.num}
              onClick={() => setCurrentStep(st.num)}
              className={`p-3.5 rounded-xl border text-xs cursor-pointer transition flex flex-col justify-between ${
                currentStep >= st.num
                  ? 'bg-cyan-950/40 border-cyan-800/80 text-cyan-200'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-[10px] font-bold w-5 h-5 rounded-full bg-slate-900 flex items-center justify-center border border-slate-800">
                  {st.num}
                </span>
                {currentStep >= st.num && (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                )}
              </div>
              <div className="font-semibold mt-2.5 text-[11px] line-clamp-2">
                {st.title}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Side-by-Side Comparison: First Interaction vs Second Interaction */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Box 1: Interaction 1 */}
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <div className="flex items-center space-x-2.5">
              <span className="w-6 h-6 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-300 flex items-center justify-center font-bold text-xs">
                1
              </span>
              <h2 className="text-sm font-bold text-slate-100">
                First Interaction: Cold Investigation & Retention
              </h2>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 font-semibold">
              Approved & Retained
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div>
              <span className="text-slate-400 font-medium">Trigger Incident:</span>
              <div className="font-semibold text-slate-100 mt-0.5">
                PostgreSQL Connection Pool Exhaustion on Payments DB
              </div>
            </div>

            <div>
              <span className="text-slate-400 font-medium">Evidence Ingested (Synthetic):</span>
              <ul className="list-disc pl-4 text-[11px] text-slate-300 mt-1 space-y-0.5">
                <li>Log: <code>SQLSTATE 53300: remaining connection slots reserved</code></li>
                <li>Metric: <code>100/100 HikariCP pool slots saturated</code></li>
                <li>Diff: <code>release/v2.4.1 unpaginated batch invoice query</code></li>
              </ul>
            </div>

            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
              <span className="text-[10px] uppercase font-mono text-cyan-400 font-semibold block">
                Human Resolution & Approved Postmortem:
              </span>
              <div className="text-[11px] text-slate-300">
                <strong>Root Cause:</strong> Missing <code>maxLifetime</code> and <code>idleTimeout</code> caused stale connection slots to leak.
              </div>
              <div className="text-[11px] text-slate-300 font-mono text-cyan-300">
                <strong>Playbook:</strong> Configure maxLifetime=1800000 and idleTimeout=600000. Restart pods.
              </div>
            </div>

            <div className="bg-emerald-950/40 border border-emerald-800/80 rounded-xl p-3 text-xs text-emerald-300 flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Hindsight Retain:</strong> Committed to bank <code>org_acme_prod_ops</code> with unique memory reference.
              </span>
            </div>
          </div>
        </div>

        {/* Box 2: Interaction 2 */}
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <div className="flex items-center space-x-2.5">
              <span className="w-6 h-6 rounded-lg bg-indigo-950 border border-indigo-700 text-indigo-300 flex items-center justify-center font-bold text-xs">
                2
              </span>
              <h2 className="text-sm font-bold text-slate-100">
                Second Interaction: Associative Memory Recall
              </h2>
            </div>
            <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800 font-semibold">
              Cognitive Recall Active
            </span>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div>
              <span className="text-slate-400 font-medium">Trigger Incident (2 Weeks Later):</span>
              <div className="font-semibold text-slate-100 mt-0.5">
                Checkout Microservice DB Connection Pool Saturation
              </div>
            </div>

            <div className="bg-indigo-950/40 border border-indigo-900/80 rounded-xl p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-cyan-300 flex items-center space-x-1.5">
                  <Brain className="w-4 h-4 text-cyan-400" />
                  <span>Recalled From Hindsight Bank:</span>
                </span>
                <span className="font-mono text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 text-[10px]">
                  94% Match
                </span>
              </div>

              <div className="text-[11px] text-slate-200">
                <strong>Source Memory:</strong> Incident #1 (Connection Pool Saturation)
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-indigo-950 text-[11px] font-mono text-cyan-200">
                <span className="text-[10px] uppercase text-indigo-400 font-semibold block mb-0.5">
                  Recommended Playbook (Cited from Incident #1):
                </span>
                <code>Configure spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000.</code>
              </div>
            </div>

            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1 text-xs">
              <div className="font-semibold text-slate-200">Why Recommendation is Grounded:</div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                The agent correlates the identical SQLSTATE <code>53300</code> and <code>100/100</code> pool saturation metric with the verified resolution of Incident #1, eliminating 45 minutes of manual triage time.
              </p>
            </div>

            <div className="text-xs text-emerald-400 font-semibold flex items-center space-x-1.5 pt-1">
              <Sparkles className="w-4 h-4" />
              <span>Result: MTTR dropped from 48 minutes down to 3.5 minutes!</span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Simulation Output Card */}
      {simulationResult && (
        <div className="bg-slate-900/90 border border-cyan-800/80 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xl animate-in fade-in duration-200">
          <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-sm">
            <CheckCircle2 className="w-5 h-5" />
            <span>Live Two-Interaction Cognitive Loop Executed & Verified</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1.5 text-slate-300">
              <div className="text-cyan-400 font-bold uppercase text-[10px]">
                Interaction 1 Retention Confirmation:
              </div>
              <div>Incident ID: {simulationResult.incidentOne?.incident?.id}</div>
              <div>Title: {simulationResult.incidentOne?.incident?.title}</div>
              <div className="text-emerald-400 truncate">
                Committed Memory ID: {simulationResult.incidentOne?.retainedMemoryId}
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1.5 text-slate-300">
              <div className="text-indigo-400 font-bold uppercase text-[10px]">
                Interaction 2 Associative Recall Result:
              </div>
              <div>Incident ID: {simulationResult.incidentTwo?.incident?.id}</div>
              <div className="text-cyan-300 truncate">
                Recalled Citation: {simulationResult.incidentTwo?.recalledMemoryTitle}
              </div>
              <div className="text-emerald-400">
                Similarity Score: {Math.round(simulationResult.incidentTwo?.similarityScore * 100)}%
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

