/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { IncidentSeverity } from '../types/index.ts';

interface CreateIncidentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    title: string;
    summary: string;
    severity: IncidentSeverity;
    service: string;
  }) => Promise<void>;
}

export const CreateIncidentModal: React.FC<CreateIncidentModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [severity, setSeverity] = useState<IncidentSeverity>('SEV-1');
  const [service, setService] = useState('payments-db');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !service) return;
    setSubmitting(true);
    try {
      await onSubmit({ title, summary, severity, service });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            <h2 className="text-sm font-bold text-slate-100">
              Declare Production Incident
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Quick SRE Scenario Presets */}
          <div className="space-y-1.5 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            <span className="text-[11px] font-mono uppercase text-slate-400 font-semibold tracking-wider">
              Quick SRE Triage Presets:
            </span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setTitle('PostgreSQL Connection Pool Saturation on Orders DB');
                  setSeverity('SEV-1');
                  setService('payments-db');
                  setSummary(
                    'FATAL: remaining connection slots are reserved for non-replication superuser connections (error 53300). Active pool reached 100/100 slots during unpaginated batch settlement.'
                  );
                }}
                className="px-2 py-1 rounded bg-slate-850 hover:bg-slate-800 text-cyan-300 border border-slate-700/80 text-[11px] cursor-pointer transition font-mono"
              >
                ✦ HikariCP Pool Saturation (53300)
              </button>
              <button
                type="button"
                onClick={() => {
                  setTitle('Redis OOM Eviction Storm on Auth Token Store');
                  setSeverity('SEV-2');
                  setService('auth-service');
                  setSummary(
                    'maxmemory policy reached 100% capacity on redis-cluster-01. Volatile-lru eviction causing 40% cache miss spike and database authentication latency spikes.'
                  );
                }}
                className="px-2 py-1 rounded bg-slate-850 hover:bg-slate-800 text-indigo-300 border border-slate-700/80 text-[11px] cursor-pointer transition font-mono"
              >
                ✦ Redis OOM Eviction
              </button>
              <button
                type="button"
                onClick={() => {
                  setTitle('Pod Eviction & CrashLoopBackOff on Checkout Workers');
                  setSeverity('SEV-2');
                  setService('checkout-worker');
                  setSummary(
                    'OOMKilled exit code 137 on checkout-worker-7b94 pods. Memory limit exceeded (2048Mi) during seasonal flash sale spike.'
                  );
                }}
                className="px-2 py-1 rounded bg-slate-850 hover:bg-slate-800 text-emerald-300 border border-slate-700/80 text-[11px] cursor-pointer transition font-mono"
              >
                ✦ Kube Pod OOMKill (137)
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Incident Title *</label>
            <input
              type="text"
              required
              placeholder="e.g., PostgreSQL Connection Pool Exhaustion on Orders DB"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Severity *</label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value as IncidentSeverity)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="SEV-1">SEV-1 Critical</option>
                <option value="SEV-2">SEV-2 Major</option>
                <option value="SEV-3">SEV-3 Moderate</option>
                <option value="SEV-4">SEV-4 Minor</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Impacted Service *</label>
              <input
                type="text"
                required
                placeholder="e.g., payments-db, auth-service"
                value={service}
                onChange={(e) => setService(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Technical Summary & Symptoms</label>
            <textarea
              rows={3}
              placeholder="Describe initial alerts, HTTP 500 error spikes, error codes observed..."
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium cursor-pointer transition shadow"
            >
              {submitting ? 'Creating...' : 'Trigger Incident'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
