/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  AlertTriangle,
  Brain,
  CheckCircle2,
  PlayCircle,
  FileText,
  Shield,
  Sparkles,
  Layers,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'gemini-copilot'
  | 'incidents'
  | 'incident-detail'
  | 'memory-explorer'
  | 'approval-queue'
  | 'two-incident-demo'
  | 'audit-logs'
  | 'documentation';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  pendingApprovalsCount: number;
  activeIncidentsCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  pendingApprovalsCount,
  activeIncidentsCount,
}) => {
  const sections = [
    {
      group: 'Intelligence',
      items: [
        {
          id: 'gemini-copilot' as ActiveTab,
          label: 'Gemini Ops Copilot',
          icon: Sparkles,
          badge: '3.8 Flash',
          badgeStyle: 'text-indigo-400 bg-indigo-950/40 border border-indigo-800/40',
        },
      ],
    },
    {
      group: 'Incident Response',
      items: [
        {
          id: 'dashboard' as ActiveTab,
          label: 'Command Center',
          icon: LayoutDashboard,
          badge: null,
          badgeStyle: '',
        },
        {
          id: 'incidents' as ActiveTab,
          label: 'Incident Console',
          icon: AlertTriangle,
          badge: activeIncidentsCount > 0 ? `${activeIncidentsCount}` : null,
          badgeStyle: 'text-rose-400 bg-rose-950/60 border border-rose-800/50',
        },
      ],
    },
    {
      group: 'Institutional Memory',
      items: [
        {
          id: 'memory-explorer' as ActiveTab,
          label: 'Hindsight Explorer',
          icon: Brain,
          badge: null,
          badgeStyle: '',
        },
        {
          id: 'approval-queue' as ActiveTab,
          label: 'Knowledge Approvals',
          icon: CheckCircle2,
          badge: pendingApprovalsCount > 0 ? `${pendingApprovalsCount}` : null,
          badgeStyle: 'text-amber-400 bg-amber-950/60 border border-amber-800/50',
        },
        {
          id: 'two-incident-demo' as ActiveTab,
          label: 'Two-Incident E2E Demo',
          icon: PlayCircle,
          badge: 'E2E',
          badgeStyle: 'text-cyan-400 bg-cyan-950/60 border border-cyan-800/50',
        },
      ],
    },
    {
      group: 'Compliance & Architecture',
      items: [
        {
          id: 'audit-logs' as ActiveTab,
          label: 'Security & Audit Logs',
          icon: Shield,
          badge: null,
          badgeStyle: '',
        },
        {
          id: 'documentation' as ActiveTab,
          label: 'Engineering Specs',
          icon: FileText,
          badge: 'v0.2.1',
          badgeStyle: 'text-slate-400 bg-slate-900 border border-slate-800',
        },
      ],
    },
  ];

  return (
    <aside className="hidden md:flex w-64 border-r border-slate-800/80 bg-slate-950 flex-col justify-between shrink-0 h-[calc(100vh-4rem)]">
      <div className="p-3 space-y-4 overflow-y-auto">
        {sections.map((sec) => (
          <div key={sec.group} className="space-y-1">
            <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
              {sec.group}
            </div>

            {sec.items.map((item) => {
              const Icon = item.icon;
              const isActive =
                activeTab === item.id ||
                (activeTab === 'incident-detail' && item.id === 'incidents');

              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full relative flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150 cursor-pointer focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:outline-none ${
                    isActive
                      ? 'bg-slate-900 text-cyan-300 font-semibold shadow-inner border border-slate-800 before:absolute before:left-0 before:top-2 before:bottom-2 before:w-1 before:bg-cyan-400 before:rounded-r'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 truncate">
                    <Icon
                      className={`w-4 h-4 shrink-0 transition-colors ${
                        isActive ? 'text-cyan-400' : 'text-slate-400'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {item.badge !== null && (
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded shrink-0 tabular-nums font-medium ${item.badgeStyle}`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Tenancy & Partition Status */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950 text-xs">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-medium">Hindsight Partition</span>
            <span className="font-mono text-emerald-400 text-[10px]">Strict RLS</span>
          </div>
          <div className="font-mono text-cyan-300 text-[10px] bg-slate-950 px-2 py-1 rounded border border-slate-800 truncate">
            org_acme_prod_ops
          </div>
          <div className="text-[10px] text-slate-500 leading-tight">
            Human Admin approval required before memory retention (Rule BR-03).
          </div>
        </div>
      </div>
    </aside>
  );
};
