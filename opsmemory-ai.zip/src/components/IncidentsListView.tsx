/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  AlertTriangle,
  Plus,
  Search,
  ArrowRight,
  Clock,
  Radio,
  LayoutList,
  Table as TableIcon,
  RotateCcw,
} from 'lucide-react';
import { Incident } from '../types/index.ts';

interface IncidentsListViewProps {
  incidents: Incident[];
  onOpenIncident: (id: string) => void;
  onCreateIncidentClick: () => void;
  onOpenWebhookSimulator?: () => void;
}

export const IncidentsListView: React.FC<IncidentsListViewProps> = ({
  incidents,
  onOpenIncident,
  onCreateIncidentClick,
  onOpenWebhookSimulator,
}) => {
  const [search, setSearch] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut '/' focuses search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === '/' &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const filtered = incidents.filter((inc) => {
    const matchesSearch =
      inc.title.toLowerCase().includes(search.toLowerCase()) ||
      inc.service.toLowerCase().includes(search.toLowerCase()) ||
      inc.summary.toLowerCase().includes(search.toLowerCase());

    const matchesSeverity =
      selectedSeverity === 'ALL' || inc.severity === selectedSeverity;
    const matchesStatus =
      selectedStatus === 'ALL' || inc.status === selectedStatus;

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2.5">
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">
              Incident Response Console
            </h1>
            <span className="text-xs font-mono text-slate-400">
              {incidents.length} Records
            </span>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Track, triage, and investigate live infrastructure and microservice incidents.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {onOpenWebhookSimulator && (
            <button
              onClick={onOpenWebhookSimulator}
              className="flex items-center space-x-2 bg-slate-900 hover:bg-slate-850 text-cyan-300 border border-slate-700/80 hover:border-cyan-500/50 text-xs font-medium px-3 py-2 rounded-xl transition shadow cursor-pointer focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
            >
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <span>Simulate Alert / ChatOps</span>
            </button>
          )}

          <button
            onClick={onCreateIncidentClick}
            className="flex items-center space-x-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition shadow cursor-pointer focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
          >
            <Plus className="w-4 h-4" />
            <span>Report Incident</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-3 text-xs shadow-sm">
        {/* Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            ref={searchInputRef}
            type="text"
            placeholder="Search service, signature, title... (Press /)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/80 text-xs font-sans"
          />
        </div>

        {/* Severity Filter */}
        <div className="flex items-center space-x-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <span className="text-slate-500 font-medium shrink-0 mr-1">Severity:</span>
          {['ALL', 'SEV-1', 'SEV-2', 'SEV-3', 'SEV-4'].map((sev) => (
            <button
              key={sev}
              onClick={() => setSelectedSeverity(sev)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-mono font-medium transition cursor-pointer ${
                selectedSeverity === sev
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>

        {/* Status Filter */}
        <div className="flex items-center space-x-1.5 w-full md:w-auto overflow-x-auto">
          <span className="text-slate-500 font-medium shrink-0 mr-1">Status:</span>
          {['ALL', 'TRIGGERED', 'INVESTIGATING', 'RESOLVED'].map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition cursor-pointer ${
                selectedStatus === st
                  ? 'bg-indigo-950 text-indigo-300 border border-indigo-800'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center border border-slate-800 bg-slate-950 p-0.5 rounded-xl shrink-0">
          <button
            onClick={() => setViewMode('cards')}
            className={`p-1.5 rounded-lg transition cursor-pointer ${
              viewMode === 'cards'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="Card Feed View"
          >
            <LayoutList className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setViewMode('table')}
            className={`p-1.5 rounded-lg transition cursor-pointer ${
              viewMode === 'table'
                ? 'bg-slate-800 text-cyan-300 shadow-sm'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title="SRE Data Grid Table View"
          >
            <TableIcon className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Incidents Table / List View */}
      {filtered.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-10 text-center space-y-3">
          <p className="text-slate-400 text-xs">
            No incidents matched the current search or filter criteria.
          </p>
          {(search || selectedSeverity !== 'ALL' || selectedStatus !== 'ALL') && (
            <button
              onClick={() => {
                setSearch('');
                setSelectedSeverity('ALL');
                setSelectedStatus('ALL');
              }}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-cyan-300 text-xs rounded-xl border border-slate-700 cursor-pointer transition font-medium"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset All Filters</span>
            </button>
          )}
        </div>
      ) : viewMode === 'table' ? (
        /* High-Density SRE Data Grid (Table Mode) */
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-mono text-[11px]">
              <tr>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">ID</th>
                <th className="py-3 px-4">Service</th>
                <th className="py-3 px-4">Title & Symptoms</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Created</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filtered.map((inc) => (
                <tr
                  key={inc.id}
                  onClick={() => onOpenIncident(inc.id)}
                  className="hover:bg-slate-850/60 cursor-pointer transition group"
                >
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                        inc.severity === 'SEV-1'
                          ? 'bg-rose-950/80 text-rose-300 border border-rose-800'
                          : inc.severity === 'SEV-2'
                          ? 'bg-orange-950/80 text-orange-300 border border-orange-800'
                          : 'bg-amber-950/80 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {inc.severity}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-cyan-400 font-medium">
                    #{inc.incidentNumber}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {inc.service}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-200 group-hover:text-cyan-300 transition">
                      {inc.title}
                    </div>
                    <div className="text-slate-400 text-[11px] truncate max-w-md">
                      {inc.summary}
                    </div>
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300">
                    {inc.status}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400 text-[11px] tabular-nums">
                    {new Date(inc.createdAt).toLocaleTimeString()}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <span className="text-cyan-400 font-medium text-xs group-hover:underline">
                      Investigate →
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        /* Card Feed Mode */
        <div className="space-y-3">
          {filtered.map((inc) => (
            <div
              key={inc.id}
              onClick={() => onOpenIncident(inc.id)}
              className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 transition cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm"
            >
              <div className="space-y-1.5 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                      inc.severity === 'SEV-1'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : inc.severity === 'SEV-2'
                        ? 'bg-orange-950 text-orange-300 border border-orange-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {inc.severity}
                  </span>
                  <span className="text-xs font-mono text-cyan-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                    {inc.service}
                  </span>
                  <span className="text-sm font-semibold text-slate-200">
                    #{inc.incidentNumber}: {inc.title}
                  </span>
                </div>

                <p className="text-xs text-slate-400 line-clamp-1">
                  {inc.summary}
                </p>

                <div className="text-[11px] text-slate-500 flex items-center space-x-3 pt-1 font-mono">
                  <span className="flex items-center space-x-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span className="tabular-nums">Opened: {new Date(inc.createdAt).toLocaleString()}</span>
                  </span>
                  <span>·</span>
                  <span>
                    Status: <strong className="text-slate-300">{inc.status}</strong>
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3 shrink-0 self-end sm:self-center">
                <div className="text-right hidden md:block">
                  <span className="text-xs text-cyan-400 font-medium block">
                    Investigate & Recall
                  </span>
                  <span className="text-[10px] text-slate-500">
                    Hindsight Cognition
                  </span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400 group-hover:bg-cyan-900/30 transition">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
