/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Radio,
  Send,
  Terminal,
  Zap,
  CheckCircle2,
  ExternalLink,
  Brain,
  ShieldAlert,
  MessageSquare,
  AlertTriangle,
} from 'lucide-react';

interface WebhookSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onIncidentCreated: (incidentId: string) => void;
}

type Mode = 'webhook' | 'chatops';

export const WebhookSimulatorModal: React.FC<WebhookSimulatorModalProps> = ({
  isOpen,
  onClose,
  onIncidentCreated,
}) => {
  const [mode, setMode] = useState<Mode>('webhook');
  const [selectedPreset, setSelectedPreset] = useState<string>('pagerduty');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [responseResult, setResponseResult] = useState<any>(null);
  const [autoInvestigate, setAutoInvestigate] = useState(true);

  // Webhook JSON Payloads
  const presets: Record<string, { name: string; source: string; payload: any }> = {
    pagerduty: {
      name: 'PagerDuty: DB Pool Saturation (SQLSTATE 53300)',
      source: 'pagerduty',
      payload: {
        event_action: 'trigger',
        routing_key: 'prod-database-ops-key',
        payload: {
          summary: 'CRITICAL: PostgreSQL remaining connection slots reserved for superuser on payments-db',
          severity: 'critical',
          source: 'payments-db',
          custom_details: {
            sqlState: '53300',
            active_connections: 100,
            max_connections: 100,
            description: 'HikariCP client pools throwing ConnectionTimeoutException across all worker pods.',
            environment: 'production-us-east',
          },
        },
      },
    },
    datadog: {
      name: 'Datadog: Redis Cache Cluster Evictions Spike',
      source: 'datadog',
      payload: {
        event_type: 'anomaly_monitor',
        title: '[Triggered] High Eviction Rate and OOM on Redis cluster',
        body: 'Cache memory reached 99.2% limit with maxmemory-policy allkeys-lru evicting 4,800 keys/sec.',
        priority: 'high',
        tags: ['env:production', 'service:redis-cache', 'tier:caching'],
      },
    },
    prometheus: {
      name: 'Prometheus: Kubernetes Container OOMKilled (Exit 137)',
      source: 'prometheus',
      payload: {
        receiver: 'opsmemory-webhook',
        status: 'firing',
        alerts: [
          {
            status: 'firing',
            labels: {
              alertname: 'KubePodOOMKilled',
              severity: 'critical',
              service: 'checkout-api',
              namespace: 'production',
            },
            annotations: {
              summary: 'Kubernetes Pod checkout-api terminated with exit code 137',
              description: 'JVM heap spike saturated 2Gi container cgroup limit during flash sale surge.',
            },
          },
        ],
      },
    },
  };

  const [customJson, setCustomJson] = useState(
    JSON.stringify(presets.pagerduty.payload, null, 2)
  );

  // ChatOps State
  const [chatOpsCommand, setChatOpsCommand] = useState(
    'recall hikari pool connection saturation'
  );
  const [chatOpsResponse, setChatOpsResponse] = useState<any>(null);

  if (!isOpen) return null;

  const handlePresetChange = (presetKey: string) => {
    setSelectedPreset(presetKey);
    setCustomJson(JSON.stringify(presets[presetKey].payload, null, 2));
    setResponseResult(null);
  };

  const handleSendWebhook = async () => {
    setIsSubmitting(true);
    setResponseResult(null);
    try {
      const parsedBody = JSON.parse(customJson);
      parsedBody.autoInvestigate = autoInvestigate;

      const res = await fetch('/api/webhooks/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsedBody),
      });

      const json = await res.json();
      if (res.ok) {
        setResponseResult(json.data);
      } else {
        alert(`Webhook error: ${json.error?.message || 'Failed'}`);
      }
    } catch (e: any) {
      alert(`Invalid JSON: ${e.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendChatOps = async () => {
    setIsSubmitting(true);
    setChatOpsResponse(null);
    try {
      const res = await fetch('/api/chatops/slack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: chatOpsCommand }),
      });
      const json = await res.json();
      setChatOpsResponse(json);
    } catch (e: any) {
      alert(`ChatOps error: ${e.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Radio className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                Alert Gateway & ChatOps Simulator
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold">
                  Live API
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Simulate inbound alerts from monitoring systems or trigger Slack slash commands.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-4 pt-2 gap-2 text-xs">
          <button
            onClick={() => setMode('webhook')}
            className={`flex items-center space-x-2 px-3 py-2 border-b-2 font-medium transition cursor-pointer ${
              mode === 'webhook'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Inbound Alert Webhook (PagerDuty / Datadog / Prometheus)</span>
          </button>
          <button
            onClick={() => setMode('chatops')}
            className={`flex items-center space-x-2 px-3 py-2 border-b-2 font-medium transition cursor-pointer ${
              mode === 'chatops'
                ? 'border-indigo-400 text-indigo-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>ChatOps Slack Commands (/opsmemory)</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1 text-xs">
          {mode === 'webhook' ? (
            <>
              {/* Presets */}
              <div className="space-y-1.5">
                <label className="text-slate-400 font-medium">
                  Select Alert Scenario Preset:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {Object.entries(presets).map(([k, v]) => (
                    <button
                      key={k}
                      type="button"
                      onClick={() => handlePresetChange(k)}
                      className={`text-left p-2.5 rounded-xl border transition cursor-pointer ${
                        selectedPreset === k
                          ? 'bg-cyan-950/60 border-cyan-500/80 text-cyan-200 shadow-sm'
                          : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-semibold text-[11px] truncate">{v.name}</div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5 uppercase">
                        Source: {v.source}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* JSON Payload Editor */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="font-mono text-[11px]">POST /api/webhooks/alerts</span>
                  <label className="flex items-center space-x-1.5 cursor-pointer text-[11px]">
                    <input
                      type="checkbox"
                      checked={autoInvestigate}
                      onChange={(e) => setAutoInvestigate(e.target.checked)}
                      className="rounded bg-slate-950 border-slate-700 text-cyan-500 focus:ring-0"
                    />
                    <span>Auto-trigger AI Investigation & Recall</span>
                  </label>
                </div>
                <textarea
                  rows={8}
                  value={customJson}
                  onChange={(e) => setCustomJson(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 font-mono text-[11px] text-slate-300 focus:outline-none focus:border-cyan-500/80"
                />
              </div>

              {/* Action Button */}
              <button
                onClick={handleSendWebhook}
                disabled={isSubmitting}
                className="w-full bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold py-2.5 rounded-xl transition flex items-center justify-center space-x-2 shadow-lg cursor-pointer text-xs"
              >
                {isSubmitting ? (
                  <>
                    <Zap className="w-4 h-4 animate-spin" />
                    <span>Ingesting & Consulting Hindsight...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Dispatch Alert Webhook</span>
                  </>
                )}
              </button>

              {/* Result Preview */}
              {responseResult && (
                <div className="bg-slate-950 border border-emerald-500/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-emerald-400 font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Incident #{responseResult.incident?.incidentNumber} Triaged Successfully</span>
                    </div>
                    <button
                      onClick={() => {
                        onIncidentCreated(responseResult.incident.id);
                        onClose();
                      }}
                      className="inline-flex items-center space-x-1 px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold cursor-pointer transition shadow"
                    >
                      <span>Open Incident</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="text-slate-300 text-xs">
                    <strong>Title:</strong> {responseResult.incident?.title}
                  </div>

                  {responseResult.recalledMemories && responseResult.recalledMemories.length > 0 && (
                    <div className="bg-slate-900 border border-indigo-900/40 rounded-lg p-3 space-y-1.5">
                      <div className="flex items-center space-x-1.5 text-indigo-400 font-semibold text-[11px]">
                        <Brain className="w-3.5 h-3.5" />
                        <span>Hindsight Institutional Memory Matched ({Math.round(responseResult.recalledMemories[0].similarityScore * 100)}% match)</span>
                      </div>
                      <div className="text-slate-200 font-medium">
                        Incident #{responseResult.recalledMemories[0].incidentNumber}: {responseResult.recalledMemories[0].title}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        <strong>Verified Playbook:</strong> {responseResult.recalledMemories[0].resolutionPlaybook}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </>
          ) : (
            <>
              {/* ChatOps Slack Commands */}
              <div className="space-y-2">
                <label className="text-slate-400 font-medium">
                  Select ChatOps Command Preset:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    { label: 'Recall Hikari Pool Resolution', cmd: 'recall hikari connection pool saturation' },
                    { label: 'Recall Redis OOM Eviction Fix', cmd: 'recall redis oom eviction maxmemory' },
                    { label: 'Operational Status Overview', cmd: 'status' },
                    { label: 'Investigate Active Incident #142', cmd: 'investigate 142' },
                  ].map((p) => (
                    <button
                      key={p.cmd}
                      type="button"
                      onClick={() => setChatOpsCommand(p.cmd)}
                      className={`text-left p-2.5 rounded-xl border transition cursor-pointer font-mono text-[11px] ${
                        chatOpsCommand === p.cmd
                          ? 'bg-indigo-950/70 border-indigo-500/80 text-indigo-200'
                          : 'bg-slate-950/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-sans font-medium text-slate-300 text-xs">{p.label}</div>
                      <div className="text-[10px] text-indigo-400 mt-0.5">/opsmemory {p.cmd}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Command Input */}
              <div className="space-y-1.5">
                <span className="text-slate-400 font-medium">Slack Slash Command:</span>
                <div className="flex items-center space-x-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 focus-within:border-indigo-500">
                  <span className="font-mono text-indigo-400 font-bold">/opsmemory</span>
                  <input
                    type="text"
                    value={chatOpsCommand}
                    onChange={(e) => setChatOpsCommand(e.target.value)}
                    placeholder="recall <query> | status | investigate <id>"
                    className="flex-1 bg-transparent text-slate-200 text-xs focus:outline-none font-mono"
                  />
                </div>
              </div>

              <button
                onClick={handleSendChatOps}
                disabled={isSubmitting}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold py-2.5 rounded-xl transition flex items-center justify-center space-x-2 shadow-lg cursor-pointer text-xs"
              >
                {isSubmitting ? (
                  <>
                    <Zap className="w-4 h-4 animate-spin" />
                    <span>Executing ChatOps Command...</span>
                  </>
                ) : (
                  <>
                    <Terminal className="w-4 h-4" />
                    <span>Execute Slack Slash Command</span>
                  </>
                )}
              </button>

              {/* Slack Card Simulation */}
              {chatOpsResponse && (
                <div className="bg-[#1a1d21] border border-slate-700 rounded-xl p-4 font-sans space-y-2 shadow-inner">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 rounded bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-[10px] font-bold text-white">
                      OM
                    </div>
                    <span className="font-bold text-slate-200 text-xs">OpsMemory Bot</span>
                    <span className="text-[10px] px-1 bg-slate-800 text-slate-400 rounded">APP</span>
                    <span className="text-[10px] text-slate-500">in #war-room-outages</span>
                  </div>
                  <div className="whitespace-pre-wrap font-mono text-[11px] text-slate-200 bg-black/40 p-3 rounded-lg border border-slate-800 leading-relaxed">
                    {chatOpsResponse.text}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
