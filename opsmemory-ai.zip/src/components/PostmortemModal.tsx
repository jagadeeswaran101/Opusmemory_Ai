/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, BookOpen, CheckCircle2, ShieldAlert } from 'lucide-react';
import { Incident, Postmortem } from '../types/index.ts';

interface PostmortemModalProps {
  isOpen: boolean;
  onClose: () => void;
  incident: Incident;
  existingPostmortem?: Postmortem;
  onSubmit: (data: {
    title: string;
    rootCause: string;
    triggerEvent: string;
    resolutionPlaybook: string;
    preventionItems: string[];
  }) => Promise<void>;
}

export const PostmortemModal: React.FC<PostmortemModalProps> = ({
  isOpen,
  onClose,
  incident,
  existingPostmortem,
  onSubmit,
}) => {
  const [title, setTitle] = useState(
    existingPostmortem?.title || `${incident.title} Resolution Postmortem`
  );
  const [rootCause, setRootCause] = useState(
    existingPostmortem?.rootCause ||
      'Missing spring.datasource.hikari.maxLifetime and idleTimeout on HikariCP connection pool.'
  );
  const [triggerEvent, setTriggerEvent] = useState(
    existingPostmortem?.triggerEvent ||
      'Deployment of release v2.4.1 containing unpaginated batch settlement queries.'
  );
  const [resolutionPlaybook, setResolutionPlaybook] = useState(
    existingPostmortem?.resolutionPlaybook ||
      '1. Configure spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000.\n2. Perform rolling restart of payments-service pods.\n3. Verify active connection pool returns to baseline < 20.'
  );
  const [preventionText, setPreventionText] = useState(
    existingPostmortem?.preventionItems?.join('\n') ||
      'Enforce datasource timeout configuration linting in CI.\nProvision PgBouncer connection pooler in staging.'
  );
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !rootCause || !resolutionPlaybook) return;
    setSubmitting(true);
    try {
      const preventionItems = preventionText
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean);
      await onSubmit({
        title,
        rootCause,
        triggerEvent,
        resolutionPlaybook,
        preventionItems,
      });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-2xl w-full p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-slate-100">
              {existingPostmortem ? 'Incident Postmortem' : 'Author Postmortem & Submit for Approval'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {existingPostmortem?.retainedInHindsight && (
          <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800 text-xs text-emerald-300 flex items-center space-x-2 font-mono">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Retained in Hindsight Memory Bank: {existingPostmortem.hindsightMemoryId}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Postmortem Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Verified Root Cause *</label>
            <textarea
              rows={2}
              required
              placeholder="Concrete verified root cause discovered during triage..."
              value={rootCause}
              onChange={(e) => setRootCause(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Trigger Event</label>
            <input
              type="text"
              placeholder="What event or deployment triggered the outage?"
              value={triggerEvent}
              onChange={(e) => setTriggerEvent(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">
              Verified Resolution Playbook (Instructions for future incidents) *
            </label>
            <textarea
              rows={3}
              required
              placeholder="Step 1... Step 2... Commands to run..."
              value={resolutionPlaybook}
              onChange={(e) => setResolutionPlaybook(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">
              Prevention Measures (One per line)
            </label>
            <textarea
              rows={2}
              placeholder="Architectural guardrails or CI checks..."
              value={preventionText}
              onChange={(e) => setPreventionText(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <span className="text-[11px] text-slate-400">
              Submits to Knowledge Approval Queue for admin review.
            </span>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium cursor-pointer transition shadow"
              >
                {submitting ? 'Submitting...' : 'Submit to Approval Queue'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
