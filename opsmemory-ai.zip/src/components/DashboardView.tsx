/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Activity,
  Brain,
  Clock,
  TrendingDown,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Zap,
  Server,
  Sparkles,
  Search,
  Database,
  RefreshCw,
} from 'lucide-react';
import { Incident, User } from '../types/index.ts';
import { ActiveTab } from './Sidebar.tsx';

interface DashboardViewProps {
  incidents: Incident[];
  memories: any[];
  currentUser?: User;
  onOpenIncident: (id: string) => void;
  onNavigateTab: (tab: ActiveTab) => void;
  onOpenLearnGuide?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  incidents,
  memories,
  currentUser,
  onOpenIncident,
  onNavigateTab,
  onOpenLearnGuide,
}) => {
  const activeIncidents = incidents.filter((i) => i.status !== 'RESOLVED');
  const sev1Count = incidents.filter(
    (i) => i.severity === 'SEV-1' && i.status !== 'RESOLVED'
  ).length;

  const [poolSimulatedActive, setPoolSimulatedActive] = useState(100);

  return (
    <div className="space-y-6">
      {/* Human Welcome & Situation Overview */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center space-x-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-100 tracking-tight">
              Operational Command Center
            </h1>
            <span className="text-[11px] font-mono text-emerald-400 font-medium">
              · Live SRE Monitoring
            </span>
          </div>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Welcome back, <strong className="text-slate-100">{currentUser?.fullName || 'Elena'}</strong>. {activeIncidents.length > 0 ? (
              <span>You have <strong className="text-rose-400 font-semibold">{activeIncidents.length} active incident</strong> requiring triage. Hindsight associative memory is ready to correlate historical postmortems.</span>
            ) : (
              <span>All services are operating nominally. Memory bank is synchronized with the PostgreSQL System of Record.</span>
            )}
          </p>
        </div>

        {/* Quick Action Shortcuts */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => onNavigateTab('gemini-copilot')}
            className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-xl transition shadow-md cursor-pointer focus-visible:ring-2 focus-visible:ring-indigo-400 focus-visible:outline-none"
          >
            <Sparkles className="w-4 h-4 text-cyan-200" />
            <span>Gemini Ops Copilot</span>
          </button>

          {onOpenLearnGuide && (
            <button
              onClick={onOpenLearnGuide}
              className="flex items-center space-x-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs font-medium px-3.5 py-2 rounded-xl border border-slate-700/60 transition cursor-pointer focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
            >
              <span>How It Thinks</span>
            </button>
          )}

          <button
            onClick={() => onNavigateTab('two-incident-demo')}
            className="flex items-center space-x-1.5 bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 text-xs font-medium px-3.5 py-2 rounded-xl border border-slate-700/60 transition cursor-pointer focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none"
          >
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>Two-Incident Demo</span>
            <ArrowRight className="w-3.5 h-3.5 ml-0.5 text-slate-400" />
          </button>
        </div>
      </div>

      {/* Gemini AI Interactive Intelligence Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-semibold text-slate-200">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>Gemini Ops Copilot · Grounded in Hindsight Institutional Memory</span>
          </div>
          <button
            onClick={() => onNavigateTab('gemini-copilot')}
            className="text-[11px] text-indigo-300 hover:text-white font-medium flex items-center space-x-1 transition cursor-pointer"
          >
            <span>Open Copilot Console</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        <div
          onClick={() => onNavigateTab('gemini-copilot')}
          className="relative flex items-center bg-slate-950/90 border border-slate-800 hover:border-indigo-500/70 rounded-xl px-4 py-3 cursor-pointer group transition shadow-inner"
        >
          <Search className="w-4 h-4 text-slate-500 mr-3 group-hover:text-cyan-400 transition" />
          <span className="text-xs sm:text-sm text-slate-400 group-hover:text-slate-200 transition flex-1">
            Ask Gemini anything about active telemetry, root causes, or Hindsight memory precedents...
          </span>
          <span className="text-[10px] font-mono text-slate-500 border border-slate-800 px-2 py-0.5 rounded hidden sm:inline-block">
            ⌘K
          </span>
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto text-[11px] pt-1 text-slate-400">
          <span className="text-slate-500 shrink-0 font-medium">Quick recall:</span>
          <button
            onClick={() => onNavigateTab('gemini-copilot')}
            className="bg-slate-950 hover:bg-slate-850 text-slate-300 px-3 py-1 rounded-lg border border-slate-800 hover:border-slate-700 transition cursor-pointer shrink-0 truncate max-w-xs"
          >
            Analyze connection pool saturation on payments-db
          </button>
          <button
            onClick={() => onNavigateTab('gemini-copilot')}
            className="bg-slate-950 hover:bg-slate-850 text-slate-300 px-3 py-1 rounded-lg border border-slate-800 hover:border-slate-700 transition cursor-pointer shrink-0 truncate max-w-xs"
          >
            Recall Incident #89 from Hindsight memory bank
          </button>
          <button
            onClick={() => onNavigateTab('gemini-copilot')}
            className="bg-slate-950 hover:bg-slate-850 text-slate-300 px-3 py-1 rounded-lg border border-slate-800 hover:border-slate-700 transition cursor-pointer shrink-0 truncate max-w-xs"
          >
            Recommend safe read-only diagnostics
          </button>
        </div>
      </div>

      {/* 4 Executive Metric Cards with Sparklines */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Active Incidents */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 transition hover:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Active Outages</span>
            <Activity className="w-4 h-4 text-rose-400" />
          </div>
          <div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-slate-100 font-mono tabular-nums">
                {activeIncidents.length}
              </span>
              {sev1Count > 0 ? (
                <span className="text-[11px] font-semibold text-rose-400 tabular-nums">
                  {sev1Count} Critical SEV-1
                </span>
              ) : (
                <span className="text-[11px] text-emerald-400 font-medium">All Nominally Mitigated</span>
              )}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Live investigations running
            </div>
          </div>
          {/* Micro Sparkline SVG */}
          <div className="h-6 w-full pt-1">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 100 20">
              <path
                d="M 0 15 Q 25 18, 50 10 T 100 4"
                fill="none"
                stroke="#f43f5e"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>

        {/* Mean Time to Resolve */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 transition hover:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Mean Time to Resolve (MTTR)</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-cyan-400 font-mono tabular-nums">
                18.5m
              </span>
              <span className="text-[11px] font-medium text-emerald-400 flex items-center tabular-nums">
                <TrendingDown className="w-3.5 h-3.5 mr-0.5" /> -62%
              </span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Industry baseline: 48.0m without memory
            </div>
          </div>
          {/* Micro Sparkline SVG */}
          <div className="h-6 w-full pt-1">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 100 20">
              <path
                d="M 0 4 Q 25 8, 50 14 T 100 18"
                fill="none"
                stroke="#06b6d4"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>

        {/* Memory Reuse Velocity */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 transition hover:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Memory Reuse Rate</span>
            <Brain className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-emerald-400 font-mono tabular-nums">
                82.5%
              </span>
              <span className="text-[11px] text-slate-400">of incidents</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Prior playbooks directly reused
            </div>
          </div>
          {/* Micro Sparkline SVG */}
          <div className="h-6 w-full pt-1">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 100 20">
              <path
                d="M 0 16 Q 25 12, 50 8 T 100 2"
                fill="none"
                stroke="#10b981"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>

        {/* Retained Memory Partition */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 transition hover:border-slate-700 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-medium">Hindsight Bank</span>
            <Server className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-indigo-300 font-mono tabular-nums">
                {memories.length}
              </span>
              <span className="text-[11px] text-slate-400">approved postmortems</span>
            </div>
            <div className="text-[11px] font-mono text-slate-500 mt-1 truncate">
              bank: org_acme_prod_ops
            </div>
          </div>
          {/* Micro Sparkline SVG */}
          <div className="h-6 w-full pt-1">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 100 20">
              <path
                d="M 0 14 Q 30 14, 60 10 T 100 4"
                fill="none"
                stroke="#818cf8"
                strokeWidth="1.5"
                strokeLinecap="round"
              />
            </svg>
          </div>
        </div>
      </div>

      {/* Live Infrastructure Telemetry Gauge (HikariCP / Connection Pool Health) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <Database className="w-4 h-4 text-cyan-400" />
            <div>
              <h2 className="text-sm font-semibold text-slate-100">
                Live Microservice Telemetry Monitor: payments-db Connection Pool
              </h2>
              <p className="text-xs text-slate-400">
                Real-time Prometheus stream for HikariCP datasource capacity and worker threads.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                setPoolSimulatedActive(poolSimulatedActive === 100 ? 18 : 100);
              }}
              className="text-xs px-2.5 py-1 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-lg border border-slate-700 transition cursor-pointer flex items-center space-x-1"
            >
              <RefreshCw className="w-3 h-3 text-cyan-400" />
              <span>Toggle State ({poolSimulatedActive === 100 ? 'Saturated' : 'Nominal'})</span>
            </button>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
              poolSimulatedActive >= 90
                ? 'bg-rose-950/80 text-rose-300 border border-rose-800'
                : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
            }`}>
              {poolSimulatedActive >= 90 ? 'SATURATED (53300)' : 'HEALTHY'}
            </span>
          </div>
        </div>

        {/* Progress Bar & Telemetry Stats */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">
              Active Leaked Connections: <strong className={poolSimulatedActive >= 90 ? 'text-rose-400' : 'text-emerald-400'}>{poolSimulatedActive} / 100 slots</strong>
            </span>
            <span className="text-slate-400">Capacity Utilization: {poolSimulatedActive}%</span>
          </div>
          <div className="w-full bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                poolSimulatedActive >= 90 ? 'bg-gradient-to-r from-amber-500 to-rose-500' : 'bg-emerald-500'
              }`}
              style={{ width: `${poolSimulatedActive}%` }}
            />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px] font-mono text-slate-400">
            <div>Max Lifetime: <span className="text-slate-200">0ms (LEAKING)</span></div>
            <div>Idle Timeout: <span className="text-slate-200">0ms (DISABLED)</span></div>
            <div>Threads Waiting: <span className="text-rose-400 font-semibold">{poolSimulatedActive >= 90 ? '48 threads' : '0 threads'}</span></div>
            <div>SQLSTATE: <span className="text-rose-400 font-semibold">{poolSimulatedActive >= 90 ? '53300' : '00000'}</span></div>
          </div>
        </div>
      </div>

      {/* Main Grid: Operational Incident Feed & Memory Spotlight */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Incidents List (2 Cols) */}
        <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-slate-100">
                Operational Incident Feed
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('incidents')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center transition cursor-pointer"
            >
              <span>View All Console Incidents</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </button>
          </div>

          <div className="space-y-3">
            {incidents.slice(0, 4).map((inc) => (
              <div
                key={inc.id}
                onClick={() => onOpenIncident(inc.id)}
                className="group bg-slate-950/70 hover:bg-slate-850/80 border border-slate-800/80 hover:border-slate-700 p-4 rounded-xl transition cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-inner"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                        inc.severity === 'SEV-1'
                          ? 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
                          : inc.severity === 'SEV-2'
                          ? 'bg-orange-950/80 text-orange-300 border border-orange-800/80'
                          : 'bg-amber-950/80 text-amber-300 border border-amber-800/80'
                      }`}
                    >
                      {inc.severity}
                    </span>
                    <span className="font-mono text-xs text-cyan-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {inc.service}
                    </span>
                    <span className="font-semibold text-slate-100 text-xs sm:text-sm group-hover:text-cyan-300 transition">
                      #{inc.incidentNumber}: {inc.title}
                    </span>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-1">
                    {inc.summary}
                  </p>

                  <div className="text-[11px] text-slate-500 flex items-center space-x-3 pt-0.5 font-mono">
                    <span>Status: <strong className="text-slate-300">{inc.status}</strong></span>
                    <span>·</span>
                    <span>{new Date(inc.createdAt).toLocaleTimeString()}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0 self-end sm:self-center">
                  <span className="text-xs text-cyan-400 font-medium group-hover:translate-x-0.5 transition hidden sm:inline">
                    Investigate
                  </span>
                  <div className="w-7 h-7 rounded-lg bg-slate-800/80 group-hover:bg-cyan-900/40 flex items-center justify-center text-cyan-400 transition">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Retained Memory Spotlight (1 Col) */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div className="flex items-center space-x-2">
                <Brain className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-semibold text-slate-100">
                  Hindsight Spotlight
                </h2>
              </div>
              <button
                onClick={() => onNavigateTab('memory-explorer')}
                className="text-xs text-cyan-400 hover:text-cyan-300 font-medium transition cursor-pointer"
              >
                Explore Bank
              </button>
            </div>

            <div className="space-y-3">
              {memories.slice(0, 2).map((m: any) => (
                <div
                  key={m.memoryId}
                  className="bg-slate-950/70 border border-slate-800/80 p-3.5 rounded-xl space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/60 font-semibold">
                      Inc #{m.document?.incidentNumber || 89}
                    </span>
                    <span className="text-[10px] text-emerald-400 font-medium flex items-center">
                      <CheckCircle2 className="w-3 h-3 mr-1" /> Approved & Retained
                    </span>
                  </div>
                  <div className="font-semibold text-slate-200">
                    {m.document?.title || 'HikariCP Idle Connection Leak'}
                  </div>
                  <div className="text-slate-400 text-[11px] line-clamp-2 leading-relaxed">
                    {m.document?.rootCause}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono bg-slate-900 p-1.5 rounded border border-slate-800 truncate">
                    Playbook: {m.document?.resolutionPlaybook?.split('\n')[0] || 'Configure pool limits'}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span className="flex items-center space-x-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Human Approval (Rule BR-03)</span>
            </span>
            <span className="text-emerald-400 font-medium">100% Governed</span>
          </div>
        </div>
      </div>
    </div>
  );
};
