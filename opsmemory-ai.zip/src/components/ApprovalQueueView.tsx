/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Brain,
  FileText,
  User,
} from 'lucide-react';
import { KnowledgeApproval, UserRole } from '../types/index.ts';

interface ApprovalQueueViewProps {
  approvals: KnowledgeApproval[];
  onReview: (
    approvalId: string,
    decision: 'APPROVED' | 'REJECTED',
    notes?: string
  ) => Promise<void>;
  currentUserRole: UserRole;
}

export const ApprovalQueueView: React.FC<ApprovalQueueViewProps> = ({
  approvals,
  onReview,
  currentUserRole,
}) => {
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});
  const [submittingId, setSubmittingId] = useState<string | null>(null);

  const isAuthorized =
    currentUserRole === 'OPERATIONS_ADMIN' ||
    currentUserRole === 'ORGANIZATION_OWNER';

  const pendingApprovals = approvals.filter((a) => a.status === 'PENDING');
  const pastApprovals = approvals.filter((a) => a.status !== 'PENDING');

  const handleAction = async (
    approvalId: string,
    decision: 'APPROVED' | 'REJECTED'
  ) => {
    setSubmittingId(approvalId);
    try {
      await onReview(approvalId, decision, reviewNotes[approvalId] || '');
    } finally {
      setSubmittingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Knowledge Approval & Governance Queue
          </h1>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
            {pendingApprovals.length} Pending Review
          </span>
        </div>
        <p className="text-slate-400 text-xs mt-1">
          Enforces Human-in-the-Loop Governance (Rule BR-03). Postmortems must be reviewed and approved by an Operations Admin before retention into Hindsight organizational memory banks.
        </p>
      </div>

      {!isAuthorized && (
        <div className="bg-amber-950/40 border border-amber-800/80 rounded-xl p-4 text-xs text-amber-300 flex items-center space-x-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <strong>Notice:</strong> Your current persona is <strong>{currentUserRole}</strong>. Approving or rejecting knowledge requires an <strong>OPERATIONS_ADMIN</strong> or <strong>ORGANIZATION_OWNER</strong> role. Use the persona switcher in the top right header to simulate an Admin.
          </div>
        </div>
      )}

      {/* Pending Items */}
      <div className="space-y-4">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-300">
          Pending Knowledge Review ({pendingApprovals.length})
        </h2>

        {pendingApprovals.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
            All postmortems have been reviewed. No knowledge items pending retention.
          </div>
        ) : (
          pendingApprovals.map((appr) => (
            <div
              key={appr.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold">
                      Pending Approval
                    </span>
                    <h3 className="font-bold text-slate-100 text-sm">
                      {appr.incidentTitle}
                    </h3>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center space-x-3">
                    <span>Submitted by: <strong className="text-slate-300">{appr.submittedBy}</strong></span>
                    <span>•</span>
                    <span>{new Date(appr.createdAt).toLocaleString()}</span>
                  </div>
                </div>

                <div className="text-xs font-mono text-cyan-400 flex items-center space-x-1">
                  <Brain className="w-4 h-4" />
                  <span>Target Bank: org_acme_prod_ops</span>
                </div>
              </div>

              {/* Review Notes Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-slate-300">
                  Reviewer Notes & Verification Sign-off:
                </label>
                <textarea
                  rows={2}
                  value={reviewNotes[appr.id] || ''}
                  onChange={(e) =>
                    setReviewNotes({ ...reviewNotes, [appr.id]: e.target.value })
                  }
                  placeholder="e.g., Verified root cause in staging; playbook tested and safe for institutional retention."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Review Buttons */}
              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  onClick={() => handleAction(appr.id, 'REJECTED')}
                  disabled={!isAuthorized || submittingId === appr.id}
                  className="bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-rose-300 border border-slate-700 text-xs px-3.5 py-2 rounded-lg font-medium transition cursor-pointer flex items-center space-x-1.5"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Reject</span>
                </button>

                <button
                  onClick={() => handleAction(appr.id, 'APPROVED')}
                  disabled={!isAuthorized || submittingId === appr.id}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs px-4 py-2 rounded-lg font-medium transition shadow cursor-pointer flex items-center space-x-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{submittingId === appr.id ? 'Retaining...' : 'Approve & Commit to Hindsight'}</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Historical Approvals */}
      {pastApprovals.length > 0 && (
        <div className="space-y-3 pt-4 border-t border-slate-800">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Recent Approval Ledger ({pastApprovals.length})
          </h2>

          <div className="space-y-2">
            {pastApprovals.map((appr) => (
              <div
                key={appr.id}
                className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-center justify-between text-xs"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded font-bold ${
                        appr.status === 'APPROVED'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {appr.status}
                    </span>
                    <span className="font-medium text-slate-200">
                      {appr.incidentTitle}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Reviewed by {appr.reviewedBy} • {appr.reviewNotes || 'Approved without extra notes'}
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 font-mono">
                  {new Date(appr.reviewedAt || appr.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
