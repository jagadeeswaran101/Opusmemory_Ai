/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Brain,
  Search,
  Sparkles,
  Server,
  Activity,
  CheckCircle2,
  ShieldCheck,
  RefreshCw,
  Terminal,
} from 'lucide-react';
import { MemoryBankStats } from '../types/index.ts';

interface MemoryExplorerViewProps {
  stats?: MemoryBankStats;
  memories: any[];
  onTestRecall: (query: string) => Promise<any[]>;
  onTriggerReflect: () => Promise<any>;
}

export const MemoryExplorerView: React.FC<MemoryExplorerViewProps> = ({
  stats,
  memories,
  onTestRecall,
  onTriggerReflect,
}) => {
  const [testQuery, setTestQuery] = useState('PostgreSQL connection pool leak 53300');
  const [testResults, setTestResults] = useState<any[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [reflectionResult, setReflectionResult] = useState<any | null>(null);
  const [isReflecting, setIsReflecting] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testQuery) return;
    setIsSearching(true);
    try {
      const res = await onTestRecall(testQuery);
      setTestResults(res);
    } finally {
      setIsSearching(false);
    }
  };

  const handleReflect = async () => {
    setIsReflecting(true);
    try {
      const res = await onTriggerReflect();
      setReflectionResult(res);
    } finally {
      setIsReflecting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <div className="flex items-center space-x-2">
          <Brain className="w-6 h-6 text-cyan-400" />
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Hindsight Cognitive Memory Explorer
          </h1>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
            Bank Isolation Active
          </span>
        </div>
        <p className="text-slate-400 text-xs mt-1">
          Explore retained organizational memories, test associative recall against historical postmortems, and synthesize recurring systemic patterns.
        </p>
      </div>

      {/* Memory Bank Health Card */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Memory Bank Partition</div>
          <div className="text-sm font-bold font-mono text-cyan-300 mt-1 truncate">
            {stats?.bankId || 'org_acme_prod_ops'}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Tenant: acme-cloud
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Retained Postmortems</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {memories.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            100% human-approved
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Cognitive Engine Status</div>
          <div className="text-sm font-bold font-mono text-emerald-400 mt-1 flex items-center">
            <CheckCircle2 className="w-4 h-4 mr-1.5" /> ONLINE (HEALTHY)
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Average recall latency: 42ms
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="text-xs text-slate-400 font-medium">Systemic Reflection</div>
            <div className="text-[11px] text-slate-400 mt-1">
              Synthesize cross-incident patterns
            </div>
          </div>
          <button
            onClick={handleReflect}
            disabled={isReflecting}
            className="mt-2 w-full bg-indigo-950 hover:bg-indigo-900 text-indigo-200 border border-indigo-800 text-xs py-1.5 rounded-lg transition font-medium flex items-center justify-center space-x-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>{isReflecting ? 'Reflecting...' : 'Run Hindsight Reflect'}</span>
          </button>
        </div>
      </div>

      {/* Reflection Findings if Active */}
      {reflectionResult && (
        <div className="bg-indigo-950/40 border border-indigo-900/80 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <h2 className="text-sm font-bold text-indigo-200">
                Hindsight Reflect Synthesis: Systemic Operational Fragility
              </h2>
            </div>
            <span className="text-[10px] font-mono text-indigo-300 bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800">
              Cross-Incident Insight
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {reflectionResult.summary}
          </p>

          <div className="space-y-1.5">
            <div className="text-[11px] font-semibold text-indigo-300 uppercase tracking-wider">
              Identified Recurrent Failure Modes:
            </div>
            <ul className="space-y-1 pl-4 text-xs text-slate-300 list-disc">
              {reflectionResult.recurrentPatterns?.map((pat: string, idx: number) => (
                <li key={idx}>{pat}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Live Recall Query Tester */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center space-x-2">
          <Search className="w-4 h-4 text-cyan-400" />
          <h2 className="text-sm font-semibold text-slate-100">
            Associative Recall Sandbox
          </h2>
        </div>
        <p className="text-xs text-slate-400">
          Simulate how the AI Investigation Agent recalls previous incidents matching an alert symptom vector.
        </p>

        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            value={testQuery}
            onChange={(e) => setTestQuery(e.target.value)}
            placeholder="Type symptom keywords (e.g. 53300 pool, OOMKilled, redis timeout)..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={isSearching}
            className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs px-4 py-2 rounded-lg font-medium transition cursor-pointer shrink-0"
          >
            {isSearching ? 'Recalling...' : 'Test Recall'}
          </button>
        </form>

        {testResults && (
          <div className="space-y-3 pt-2">
            <div className="text-xs text-slate-400 font-medium">
              Recall Results ({testResults.length} matches):
            </div>
            {testResults.length === 0 ? (
              <div className="text-xs text-slate-500 italic p-3 bg-slate-950 rounded border border-slate-800">
                No memories scored &ge; 40% similarity for this query.
              </div>
            ) : (
              testResults.map((m) => (
                <div
                  key={m.memoryId}
                  className="bg-slate-950 border border-slate-800 p-3.5 rounded-lg text-xs space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">
                      Incident #{m.incidentNumber}: {m.title}
                    </span>
                    <span className="font-mono text-cyan-300 font-bold bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800 text-[10px]">
                      {Math.round(m.similarityScore * 100)}% Similarity
                    </span>
                  </div>
                  <div className="text-slate-300 text-[11px]">
                    <strong>Root Cause:</strong> {m.rootCause}
                  </div>
                  <div className="text-[11px] font-mono text-cyan-300 bg-slate-900 p-2 rounded">
                    <strong>Playbook:</strong> {m.resolutionPlaybook}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Retained Memories List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Server className="w-4 h-4 text-indigo-400" />
            <h2 className="text-sm font-semibold text-slate-100">
              Retained Memories in Bank ({memories.length})
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Isolated to {stats?.bankId || 'org_acme_prod_ops'}
          </span>
        </div>

        <div className="space-y-3">
          {memories.map((entry: any) => (
            <div
              key={entry.memoryId}
              className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 text-xs"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                <div className="flex items-center space-x-2">
                  <span className="font-mono text-[10px] text-cyan-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 font-bold">
                    Incident #{entry.document.incidentNumber}
                  </span>
                  <span className="font-bold text-slate-100 text-sm">
                    {entry.document.title}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-[10px] text-slate-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Approved by {entry.metadata.approvedBy}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold">
                    Root Cause:
                  </span>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    {entry.document.rootCause}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold">
                    Key Symptoms Retained:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {entry.document.symptoms?.map((s: string, idx: number) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono bg-slate-900 text-slate-300 px-1.5 py-0.5 rounded border border-slate-800"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800/80 rounded p-3 text-[11px] font-mono text-cyan-200">
                <span className="text-[10px] uppercase text-cyan-400 font-semibold block mb-1">
                  Resolution Playbook:
                </span>
                <pre className="whitespace-pre-wrap">{entry.document.resolutionPlaybook}</pre>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
