/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Brain,
  ShieldCheck,
  Check,
  Copy,
  RefreshCw,
  Terminal,
  Zap,
  Info,
  Layers,
  Activity,
  Bot,
  User as UserIcon,
} from 'lucide-react';
import { Incident } from '../types/index.ts';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  model?: string;
  recalledMemories?: any[];
}

interface GeminiCopilotViewProps {
  incidents: Incident[];
  selectedIncidentId?: string;
  onOpenIncident?: (id: string) => void;
}

export const GeminiCopilotView: React.FC<GeminiCopilotViewProps> = ({
  incidents,
  selectedIncidentId: initialIncidentId,
  onOpenIncident,
}) => {
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>(
    initialIncidentId || (incidents.length > 0 ? incidents[0].id : '')
  );
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: `Hello, I'm **Gemini Ops Intelligence** powered by Google's **Gemini 3.8 Flash** and your organization's **Hindsight** memory bank.

I synthesize real-time technical evidence (logs, Prometheus metrics, git diffs) and correlate them with historical postmortems to help you:
- Pinpoint root causes in seconds instead of hours
- Check if an outage has happened before in institutional memory
- Provide verified, safe read-only diagnostic commands
- Draft human-in-the-loop postmortems

How can I assist your investigation today?`,
      timestamp: new Date().toLocaleTimeString(),
      model: 'gemini-3.8-flash',
    },
  ]);

  const activeIncident = incidents.find((i) => i.id === selectedIncidentId);

  const samplePrompts = [
    {
      label: '✦ Analyze active connection pool saturation',
      prompt: 'Analyze the active database connection pool saturation on payments-db. Why did it fail and what is the root cause?',
    },
    {
      label: '✦ Compare with Incident #89 in Hindsight',
      prompt: 'How does this current outage compare with historical Incident #89 in Hindsight? Cite the matching symptoms and resolution playbook.',
    },
    {
      label: '✦ Suggest safe diagnostic commands',
      prompt: 'What are the recommended safe, read-only diagnostic commands I should run right now on PostgreSQL to inspect the pool?',
    },
    {
      label: '✦ Draft executive postmortem',
      prompt: 'Draft an executive postmortem summary of this incident for the engineering leadership team with root cause and prevention items.',
    },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputMessage.trim();
    if (!textToSend || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInputMessage('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          incidentId: selectedIncidentId,
          history: messages.slice(-6).map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      if (!res.ok) throw new Error('Gemini API call failed');
      const json = await res.json();

      const aiMsg: ChatMessage = {
        id: `ai_${Date.now()}`,
        role: 'model',
        text: json.data.reply,
        timestamp: new Date().toLocaleTimeString(),
        model: json.data.model || 'gemini-3.8-flash',
        recalledMemories: json.data.recalledMemories,
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      const errorMsg: ChatMessage = {
        id: `err_${Date.now()}`,
        role: 'model',
        text: `Error connecting to Gemini Ops Intelligence: ${err?.message || 'Network error'}. Please try again.`,
        timestamp: new Date().toLocaleTimeString(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-6.5rem)] space-y-4">
      {/* Gemini Header & Active Context Bar */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-900/50 rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg shrink-0">
        <div className="flex items-center space-x-3.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 flex items-center justify-center text-white shadow-md shadow-indigo-950/60 ring-2 ring-white/10">
            <Sparkles className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base sm:text-lg font-bold text-slate-100 tracking-tight font-sans">
                Gemini Ops Intelligence
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-indigo-950/90 text-indigo-300 border border-indigo-700/60 font-semibold flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>Gemini 3.8 Flash</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Grounded in live telemetry & Hindsight institutional memory banks.
            </p>
          </div>
        </div>

        {/* Incident Grounding Selector */}
        <div className="flex items-center space-x-2.5 w-full md:w-auto">
          <span className="text-xs text-slate-400 font-medium shrink-0">
            Grounding Context:
          </span>
          <select
            value={selectedIncidentId}
            onChange={(e) => setSelectedIncidentId(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500 flex-1 md:w-72 truncate cursor-pointer"
          >
            <option value="">No incident (General Ops & Hindsight)</option>
            {incidents.map((inc) => (
              <option key={inc.id} value={inc.id}>
                #{inc.incidentNumber}: {inc.service} — {inc.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="flex-1 overflow-y-auto bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 sm:p-6 space-y-5 shadow-inner">
        {messages.map((msg) => {
          const isAi = msg.role === 'model';
          return (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${
                isAi ? 'justify-start' : 'justify-end'
              }`}
            >
              {isAi && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 flex items-center justify-center text-white shrink-0 mt-0.5 shadow-sm">
                  <Sparkles className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-2xl rounded-2xl p-4 sm:p-5 space-y-3 text-xs sm:text-sm leading-relaxed shadow-sm ${
                  isAi
                    ? 'bg-slate-950/80 border border-slate-800/80 text-slate-200'
                    : 'bg-indigo-600/90 text-white border border-indigo-500'
                }`}
              >
                {isAi && (
                  <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 text-[11px] font-mono text-slate-400">
                    <span className="flex items-center space-x-1.5 text-cyan-300">
                      <Sparkles className="w-3 h-3 text-cyan-400" />
                      <span>{msg.model || 'gemini-3.8-flash'}</span>
                    </span>
                    <div className="flex items-center space-x-2">
                      <span>{msg.timestamp}</span>
                      <button
                        onClick={() => handleCopyText(msg.id, msg.text)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
                        title="Copy message"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {/* Formatted Text Content */}
                <div className="whitespace-pre-wrap leading-relaxed font-sans">
                  {msg.text}
                </div>

                {/* Recalled Memory Citations if available */}
                {isAi && msg.recalledMemories && msg.recalledMemories.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 space-y-1.5">
                    <div className="text-[10px] font-mono uppercase tracking-wider text-indigo-400 font-semibold flex items-center space-x-1">
                      <Brain className="w-3.5 h-3.5" />
                      <span>Hindsight Recalled Precedents ({msg.recalledMemories.length}):</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.recalledMemories.map((mem: any) => (
                        <span
                          key={mem.memoryId}
                          className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-indigo-950/80 text-indigo-300 border border-indigo-800/60"
                        >
                          Inc #{mem.incidentNumber} ({Math.round(mem.similarityScore * 100)}% Match)
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {!isAi && (
                <div className="w-8 h-8 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                  <UserIcon className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {/* Gemini Thinking State */}
        {isLoading && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 flex items-center justify-center text-white shrink-0 animate-pulse">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs text-slate-300 max-w-md shadow-sm">
              <div className="flex items-center space-x-2 text-cyan-400 font-mono text-[11px] font-semibold">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Gemini 3.8 Flash is reasoning...</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Correlating live telemetry with Hindsight associative memory bank...
              </p>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Starter Prompts (Pills) */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 shrink-0 text-xs">
        {samplePrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(p.prompt)}
            disabled={isLoading}
            className="bg-slate-900/90 hover:bg-slate-850 hover:border-indigo-600/60 border border-slate-800 text-slate-300 text-xs px-3 py-1.5 rounded-full transition cursor-pointer shrink-0 font-medium disabled:opacity-50"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Input Prompt Bar (Gemini Style) */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="relative shrink-0"
      >
        <div className="relative flex items-center">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder={
              activeIncident
                ? `Ask Gemini about Incident #${activeIncident.incidentNumber} (${activeIncident.service})...`
                : 'Ask Gemini anything about your infrastructure or past incident postmortems...'
            }
            disabled={isLoading}
            className="w-full bg-slate-900/90 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-2xl pl-4 pr-12 py-3.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none shadow-lg transition"
          />
          <button
            type="submit"
            disabled={!inputMessage.trim() || isLoading}
            className="absolute right-2.5 p-2 rounded-xl bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 hover:opacity-95 text-white transition disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-md"
            aria-label="Send message to Gemini"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
