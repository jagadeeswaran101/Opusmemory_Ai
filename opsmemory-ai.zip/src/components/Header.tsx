/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Brain,
  Database,
  ShieldCheck,
  ChevronDown,
  Activity,
  Sparkles,
  Layers,
  Check,
} from 'lucide-react';
import { User, Organization } from '../types/index.ts';

interface HeaderProps {
  currentOrg: Organization;
  currentUser: User;
  onUserChange: (user: User) => void;
  users: User[];
  activeSev1Count: number;
  onToggleLearnMode?: () => void;
  isLearnModeOpen?: boolean;
  onOpenGeminiCopilot?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentOrg,
  currentUser,
  onUserChange,
  users,
  activeSev1Count,
  onToggleLearnMode,
  isLearnModeOpen,
  onOpenGeminiCopilot,
}) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between z-30 sticky top-0">
      {/* Zone 1: Wordmark & Breadcrumb Trail */}
      <div className="flex items-center space-x-4 shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-sm ring-1 ring-white/10">
            <Brain className="w-4 h-4" />
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-100 text-sm tracking-tight whitespace-nowrap">
              OpsMemory AI
            </span>
            <span className="text-[11px] font-mono text-slate-500 font-normal">
              v0.2.1
            </span>
          </div>
        </div>

        {/* Clean Contextual Breadcrumbs */}
        <div className="hidden lg:flex items-center space-x-2 pl-3 border-l border-slate-800 text-xs text-slate-400">
          <span className="text-slate-300 font-medium">{currentOrg.name}</span>
          <span className="text-slate-600" aria-hidden="true">/</span>
          <span>Incident Command</span>
          <span className="text-slate-600" aria-hidden="true">·</span>
          <span className="font-mono text-[11px] text-emerald-400 font-medium">Hindsight Active</span>
          <span className="text-slate-600" aria-hidden="true">·</span>
          <span className="font-mono text-[11px] text-slate-400">{currentOrg.memoryBankId}</span>
        </div>
      </div>

      {/* Zone 3: Human Actions, Alarms & Persona Switcher */}
      <div className="flex items-center space-x-2.5 sm:space-x-3 shrink-0">
        {/* Live Outage Alarm Indicator */}
        {activeSev1Count > 0 ? (
          <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-rose-950/60 border border-rose-800/70 text-rose-300 text-xs font-medium">
            <Activity className="w-3.5 h-3.5 text-rose-400" />
            <span className="font-semibold tabular-nums">{activeSev1Count} Critical SEV-1</span>
          </div>
        ) : (
          <div className="hidden sm:flex items-center space-x-1.5 text-xs text-emerald-400/90 font-medium pr-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Systems Nominal</span>
          </div>
        )}

        {/* Gemini Copilot Quick Access */}
        {onOpenGeminiCopilot && (
          <button
            onClick={onOpenGeminiCopilot}
            className="flex items-center space-x-1.5 text-xs px-3 py-1.5 rounded-lg border border-indigo-500/50 bg-indigo-950/40 hover:bg-indigo-900/40 text-indigo-200 hover:text-white transition cursor-pointer font-medium focus-visible:ring-2 focus-visible:ring-indigo-400 focus-visible:outline-none"
            title="Open Gemini Ops Copilot"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Ask Gemini</span>
          </button>
        )}

        {/* Learn Mode Guide */}
        {onToggleLearnMode && (
          <button
            onClick={onToggleLearnMode}
            className={`flex items-center space-x-1.5 text-xs px-2.5 py-1.5 rounded-lg border transition cursor-pointer font-medium focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none ${
              isLearnModeOpen
                ? 'bg-cyan-950/70 text-cyan-300 border-cyan-800'
                : 'bg-slate-900/80 text-slate-300 border-slate-800 hover:text-cyan-300 hover:border-slate-700'
            }`}
            title="Cognitive Architecture & Mental Model Guide"
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">How It Thinks</span>
          </button>
        )}

        {/* User Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center space-x-2 bg-slate-900/90 hover:bg-slate-850 px-2.5 py-1.5 rounded-lg border border-slate-800 hover:border-slate-700 cursor-pointer text-xs transition focus-visible:ring-2 focus-visible:ring-cyan-500 focus-visible:outline-none"
            aria-expanded={isDropdownOpen}
            aria-haspopup="true"
          >
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.fullName}
              className="w-6 h-6 rounded-full object-cover ring-1 ring-cyan-500/30"
            />
            <div className="text-left hidden sm:block">
              <div className="font-semibold text-slate-200 leading-none text-xs">
                {currentUser.fullName}
              </div>
              <div className="text-[10px] text-cyan-400 font-mono mt-0.5">
                {currentUser.role.replace('_', ' ')}
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {isDropdownOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setIsDropdownOpen(false)}
              />
              <div className="absolute right-0 mt-2 w-72 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-2.5 z-50 animate-in fade-in duration-100">
                <div className="px-2 py-1.5 border-b border-slate-800 mb-1.5">
                  <div className="text-[10px] uppercase font-mono text-slate-400 font-semibold tracking-wider">
                    Role-Based Access (RBAC)
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Tenant: <strong className="text-slate-300">{currentOrg.name}</strong>
                  </div>
                </div>

                <div className="space-y-1">
                  {users.map((u) => {
                    const isSelected = u.id === currentUser.id;
                    return (
                      <button
                        key={u.id}
                        onClick={() => {
                          onUserChange(u);
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-2 rounded-lg text-xs flex items-center justify-between transition cursor-pointer ${
                          isSelected
                            ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/60'
                            : 'text-slate-300 hover:bg-slate-800/70 hover:text-slate-100'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5">
                          <img
                            src={u.avatarUrl}
                            alt={u.fullName}
                            className="w-6 h-6 rounded-full object-cover"
                          />
                          <div>
                            <div className="font-medium">{u.fullName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              {u.role}
                            </div>
                          </div>
                        </div>

                        {isSelected && (
                          <Check className="w-3.5 h-3.5 text-cyan-400" />
                        )}
                      </button>
                    );
                  })}
                </div>

                <div className="mt-2 pt-2 border-t border-slate-800 text-[10px] text-slate-400 px-2 leading-relaxed">
                  Postmortem approval requires <strong>OPERATIONS_ADMIN</strong>.
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
