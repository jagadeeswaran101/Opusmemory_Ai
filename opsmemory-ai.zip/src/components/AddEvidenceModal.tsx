/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, FileCode } from 'lucide-react';
import { EvidenceType } from '../types/index.ts';

interface AddEvidenceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    evidenceType: EvidenceType;
    sourceName: string;
    summary: string;
    rawPayload: any;
  }) => Promise<void>;
}

export const AddEvidenceModal: React.FC<AddEvidenceModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [evidenceType, setEvidenceType] = useState<EvidenceType>('LOG_SNIPPET');
  const [sourceName, setSourceName] = useState('k8s.payments-pod-99c');
  const [summary, setSummary] = useState(
    'PostgreSQL error 53300: remaining connection slots are reserved'
  );
  const [rawPayload, setRawPayload] = useState(
    JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        sqlState: '53300',
        activeConnections: 100,
        maxPoolSize: 100,
        pendingThreads: 32,
      },
      null,
      2
    )
  );
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceName || !summary) return;
    setSubmitting(true);
    try {
      let parsedPayload: any = rawPayload;
      try {
        parsedPayload = JSON.parse(rawPayload);
      } catch {
        // use raw string
      }
      await onSubmit({ evidenceType, sourceName, summary, rawPayload: parsedPayload });
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <FileCode className="w-5 h-5 text-cyan-400" />
            <h2 className="text-sm font-bold text-slate-100">
              Attach Technical Evidence
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Evidence Type</label>
              <select
                value={evidenceType}
                onChange={(e) => setEvidenceType(e.target.value as EvidenceType)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="LOG_SNIPPET">LOG_SNIPPET</option>
                <option value="METRIC_SERIES">METRIC_SERIES</option>
                <option value="STACK_TRACE">STACK_TRACE</option>
                <option value="DEPLOYMENT_DIFF">DEPLOYMENT_DIFF</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Source Identifier</label>
              <input
                type="text"
                required
                value={sourceName}
                onChange={(e) => setSourceName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Summary Description</label>
            <input
              type="text"
              required
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Raw Payload (JSON or text)</label>
            <textarea
              rows={4}
              value={rawPayload}
              onChange={(e) => setRawPayload(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-cyan-300 font-mono focus:outline-none focus:border-cyan-500 text-[11px]"
            />
          </div>

          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium cursor-pointer transition shadow"
            >
              {submitting ? 'Attaching...' : 'Attach Evidence'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
