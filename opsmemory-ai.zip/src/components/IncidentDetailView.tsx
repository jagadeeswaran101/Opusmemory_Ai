/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ArrowLeft,
  Activity,
  Brain,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  GitCommit,
  Terminal,
  Copy,
  Check,
  RefreshCw,
  Plus,
  BookOpen,
  Sparkles,
  Search,
  Layers,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  Incident,
  IncidentEvidence,
  InvestigationReport,
  Postmortem,
  IncidentStatus,
} from '../types/index.ts';

interface IncidentDetailViewProps {
  incident: Incident;
  evidence: IncidentEvidence[];
  investigation?: InvestigationReport;
  postmortem?: Postmortem;
  onBack: () => void;
  onUpdateStatus: (status: IncidentStatus) => void;
  onRunInvestigation: () => void;
  onOpenPostmortemModal: () => void;
  onAddEvidenceModal: () => void;
  isInvestigating: boolean;
  onOpenGeminiCopilot?: () => void;
}

export const IncidentDetailView: React.FC<IncidentDetailViewProps> = ({
  incident,
  evidence,
  investigation,
  postmortem,
  onBack,
  onUpdateStatus,
  onRunInvestigation,
  onOpenPostmortemModal,
  onAddEvidenceModal,
  isInvestigating,
  onOpenGeminiCopilot,
}) => {
  const [copiedCommandId, setCopiedCommandId] = useState<string | null>(null);
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<
    'investigation' | 'evidence' | 'postmortem'
  >('investigation');
  const [simulatedDiagnostic, setSimulatedDiagnostic] = useState<{
    id: string;
    command: string;
    output: string;
    status: 'idle' | 'running' | 'completed';
  } | null>(null);

  const handleCopyCommand = (id: string, command: string) => {
    navigator.clipboard.writeText(command);
    setCopiedCommandId(id);
    setTimeout(() => setCopiedCommandId(null), 2000);
  };

  const handleSimulateDiagnostic = (id: string, command: string) => {
    setSimulatedDiagnostic({ id, command, output: '', status: 'running' });
    setTimeout(() => {
      let mockResult = '';
      if (command.toLowerCase().includes('pg_stat_activity')) {
        mockResult = `psql (PostgreSQL 16.2 on x86_64-pc-linux-gnu)\n` +
          `Timing is on.\n\n` +
          ` pid  | state  | query                                            | age\n` +
          `------+--------+--------------------------------------------------+-----------------\n` +
          ` 4091 | active | SELECT * FROM invoices WHERE status = 'PENDING'  | 00:04:12.891\n` +
          ` 4092 | active | SELECT * FROM invoices WHERE status = 'PENDING'  | 00:04:09.112\n` +
          ` 4093 | active | SELECT * FROM invoices WHERE status = 'PENDING'  | 00:03:58.405\n` +
          `(3 rows in 8.42ms)\n\n` +
          `[DIAGNOSTIC SUMMARY]: 97 lingering idle connections detected without datasource timeout.\n` +
          `Non-destructive execution verified. 0 rows modified.`;
      } else {
        mockResult = `$ ${command}\n` +
          `[OK] Read-only verification completed in 14.1ms.\n` +
          `Active connections count: 100/100 (Max Capacity)\n` +
          `DataSource status: HikariPool-1 - Connection timeout after 10000ms.`;
      }
      setSimulatedDiagnostic({ id, command, output: mockResult, status: 'completed' });
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Top Bar Navigation & Status Transitions */}
      <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-5 sm:p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center space-x-3.5">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/60 hover:bg-slate-700 text-slate-300 transition cursor-pointer mt-0.5 sm:mt-0"
              aria-label="Back to Incident Console"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-md font-bold ${
                    incident.severity === 'SEV-1'
                      ? 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
                      : 'bg-orange-950/80 text-orange-300 border border-orange-800/80'
                  }`}
                >
                  {incident.severity}
                </span>
                <span className="font-mono text-xs text-cyan-400 bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                  {incident.service}
                </span>
                <h1 className="text-base sm:text-lg font-bold text-slate-100 tracking-tight">
                  #{incident.incidentNumber}: {incident.title}
                </h1>
              </div>

              <div className="text-[11px] text-slate-400 mt-1 flex flex-wrap items-center gap-2 font-mono">
                <span>
                  Status: <strong className="text-cyan-400">{incident.status}</strong>
                </span>
                <span>·</span>
                <span>Opened: {new Date(incident.createdAt).toLocaleString()}</span>
                {incident.resolvedAt && (
                  <>
                    <span>·</span>
                    <span className="text-emerald-400">
                      Resolved: {new Date(incident.resolvedAt).toLocaleTimeString()}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Incident Lifecycle Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 self-stretch md:self-auto">
            {onOpenGeminiCopilot && (
              <button
                onClick={onOpenGeminiCopilot}
                className="bg-gradient-to-r from-blue-950/90 via-indigo-950/90 to-purple-950/90 hover:from-blue-900/90 hover:to-purple-900/90 text-indigo-200 hover:text-white border border-indigo-600/70 text-xs px-3.5 py-2 rounded-xl transition cursor-pointer font-semibold shadow-md flex items-center space-x-1.5"
                title="Open Gemini Ops Copilot with this incident context"
              >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                <span>Ask Gemini</span>
              </button>
            )}

            {incident.status === 'TRIGGERED' && (
              <button
                onClick={() => onUpdateStatus('INVESTIGATING')}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3.5 py-2 rounded-xl border border-slate-700 transition cursor-pointer font-medium"
              >
                Mark Investigating
              </button>
            )}

            {incident.status !== 'RESOLVED' && (
              <>
                <button
                  onClick={() => onUpdateStatus('MITIGATED')}
                  className="bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-xs px-3.5 py-2 rounded-xl transition cursor-pointer font-medium"
                >
                  Mark Mitigated
                </button>

                <button
                  onClick={onOpenPostmortemModal}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-4 py-2 rounded-xl transition cursor-pointer font-semibold shadow-md flex items-center space-x-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Resolve & Draft Postmortem</span>
                </button>
              </>
            )}

            {incident.status === 'RESOLVED' && (
              <button
                onClick={onOpenPostmortemModal}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs px-4 py-2 rounded-xl transition cursor-pointer font-medium flex items-center space-x-1.5"
              >
                <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
                <span>{postmortem ? 'View Approved Postmortem' : 'Draft Postmortem'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Human-Centered Navigation Tabs */}
        <div className="flex items-center space-x-2 border-t border-slate-800/80 pt-3 text-xs">
          <button
            onClick={() => setActiveWorkspaceTab('investigation')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
              activeWorkspaceTab === 'investigation'
                ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/60'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <Brain className="w-4 h-4 text-cyan-400" />
            <span>AI Investigation & Memory Recall</span>
          </button>

          <button
            onClick={() => setActiveWorkspaceTab('evidence')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
              activeWorkspaceTab === 'evidence'
                ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/60'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <FileCode className="w-4 h-4 text-indigo-400" />
            <span>Telemetry & Evidence</span>
            <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
              {evidence.length}
            </span>
          </button>

          <button
            onClick={() => setActiveWorkspaceTab('postmortem')}
            className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-lg font-medium transition cursor-pointer ${
              activeWorkspaceTab === 'postmortem'
                ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-800/60'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>Postmortem & Knowledge Bank</span>
            {postmortem && (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>
      </div>

      {/* Tab 1: AI Investigation & Epistemological Contract */}
      {activeWorkspaceTab === 'investigation' && (
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-6 shadow-sm">
          {/* Section Trigger Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800/70 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <Brain className="w-5 h-5 text-cyan-400" />
                <h2 className="text-base font-bold text-slate-100">
                  Epistemological Investigation Report
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                  Hindsight Associative Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Strict cognitive separation: facts, historical memories, ranked hypotheses, safe read-only diagnostics, and unknowns.
              </p>
            </div>

            <button
              onClick={onRunInvestigation}
              disabled={isInvestigating}
              className="flex items-center space-x-2 bg-gradient-to-r from-cyan-600 via-sky-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 disabled:opacity-60 text-white text-xs font-semibold px-4 py-2 rounded-xl transition shadow-md cursor-pointer shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isInvestigating ? 'animate-spin' : ''}`} />
              <span>{isInvestigating ? 'Correlating Hindsight...' : 'Run Investigation'}</span>
            </button>
          </div>

          {/* Investigation Report Display */}
          {isInvestigating ? (
            <div className="py-16 text-center space-y-3">
              <div className="inline-block p-4 rounded-2xl bg-cyan-950/80 border border-cyan-800 text-cyan-400 animate-spin">
                <RefreshCw className="w-7 h-7" />
              </div>
              <div className="text-sm font-semibold text-slate-100">
                Executing Hindsight Associative Memory Recall...
              </div>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Comparing current alert symptom vector with tenant memory bank (<code>org_acme_prod_ops</code>).
              </p>
            </div>
          ) : investigation ? (
            <div className="space-y-6">
              {/* Confidence Metric Bar */}
              <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-semibold text-slate-200">
                    Investigation Confidence Score: <span className="text-cyan-400 font-mono tabular-nums">{investigation.confidenceScore}%</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {investigation.confidenceRationale}
                  </div>
                </div>
                <div className="w-full sm:w-36 bg-slate-800 h-2.5 rounded-full overflow-hidden shrink-0">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                    style={{ width: `${investigation.confidenceScore}%` }}
                  />
                </div>
              </div>

              {/* 1. Observed Facts */}
              <div className="space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-slate-200 uppercase tracking-wider">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  <span>1. Observed Facts (Grounded in Raw Telemetry)</span>
                </div>
                <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4">
                  <ul className="space-y-2 text-xs text-slate-300 list-disc pl-4">
                    {investigation.observedFacts.map((fact, idx) => (
                      <li key={idx} className="leading-relaxed">
                        {fact}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* 2. Recalled Historical Memories */}
              <div className="space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-indigo-300 uppercase tracking-wider">
                  <Brain className="w-4 h-4 text-indigo-400" />
                  <span>2. Recalled Historical Memories (Hindsight Memory Bank)</span>
                </div>

                {investigation.historicalMemories.length === 0 ? (
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-5 text-xs text-slate-500 italic">
                    No prior postmortems in memory bank scored &ge; 70% similarity with this alert. Cold investigation active.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {investigation.historicalMemories.map((mem) => (
                      <div
                        key={mem.memoryId}
                        className="bg-indigo-950/30 border border-indigo-900/60 rounded-xl p-4 space-y-3 text-xs"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-indigo-200 text-sm">
                            Incident #{mem.incidentNumber}: {mem.title}
                          </span>
                          <span className="font-mono text-[10px] text-emerald-300 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 font-bold tabular-nums">
                            {Math.round(mem.similarityScore * 100)}% Memory Match
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-300 leading-relaxed">
                          <strong className="text-indigo-300">Historical Root Cause:</strong> {mem.rootCause}
                        </div>

                        <div className="bg-slate-950/90 border border-indigo-950/80 p-3 rounded-lg text-[11px] font-mono text-cyan-300">
                          <div className="text-[10px] uppercase text-indigo-400 font-semibold mb-1">
                            Verified Resolution Playbook:
                          </div>
                          <pre className="whitespace-pre-wrap">{mem.resolutionPlaybook}</pre>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 3. Possible Root Causes */}
              <div className="space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-300 uppercase tracking-wider">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>3. Possible Root Causes (Evidence-Ranked)</span>
                </div>

                <div className="space-y-2.5">
                  {investigation.possibleCauses.map((hyp) => (
                    <div
                      key={hyp.id}
                      className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 text-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-100 text-xs sm:text-sm">
                          {hyp.hypothesis}
                        </span>
                        <span
                          className={`font-mono text-[10px] px-2 py-0.5 rounded-md font-bold ${
                            hyp.likelihood === 'HIGH'
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-800/80'
                              : 'bg-amber-950/80 text-amber-300 border border-amber-800/80'
                          }`}
                        >
                          {hyp.likelihood} LIKELIHOOD
                        </span>
                      </div>

                      {hyp.recalledMemoryCitations.length > 0 && (
                        <div className="text-[11px] text-indigo-400 font-mono flex items-center space-x-1.5">
                          <Brain className="w-3.5 h-3.5" />
                          <span>Corroborated by Hindsight Memory: {hyp.recalledMemoryCitations.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* 4. Recommended Safe Diagnostics */}
              <div className="space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-emerald-300 uppercase tracking-wider">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>4. Recommended Diagnostic Checks (Safe & Read-Only)</span>
                </div>

                <div className="space-y-3">
                  {investigation.recommendedDiagnosticChecks.map((diag) => (
                    <div
                      key={diag.id}
                      className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-4 space-y-2.5 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-100">
                          {diag.title}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                          {diag.safetyLevel}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {diag.rationale}
                      </p>

                      <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-2.5 rounded-lg text-cyan-300 font-mono text-[11px]">
                        <span className="truncate pr-3">{diag.command}</span>
                        <div className="flex items-center space-x-1.5 shrink-0">
                          <button
                            onClick={() => handleSimulateDiagnostic(diag.id, diag.command)}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-750 text-emerald-400 rounded text-[10px] font-sans font-medium transition cursor-pointer flex items-center space-x-1"
                            title="Simulate safe query execution"
                          >
                            <Terminal className="w-3 h-3" />
                            <span>Run Safe Check</span>
                          </button>
                          <button
                            onClick={() => handleCopyCommand(diag.id, diag.command)}
                            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
                            title="Copy command"
                          >
                            {copiedCommandId === diag.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Simulated Interactive Execution Terminal */}
                      {simulatedDiagnostic?.id === diag.id && (
                        <div className="bg-black/90 border border-slate-800 rounded-lg p-3 font-mono text-[11px] space-y-1.5 shadow-inner">
                          <div className="flex items-center justify-between text-slate-500 border-b border-slate-900 pb-1 text-[10px]">
                            <span>Read-Only Sandbox (Rule BR-07)</span>
                            <span className={simulatedDiagnostic.status === 'running' ? 'text-amber-400 animate-pulse' : 'text-emerald-400'}>
                              {simulatedDiagnostic.status === 'running' ? 'Executing query...' : 'Query Finished (0 rows modified)'}
                            </span>
                          </div>
                          {simulatedDiagnostic.status === 'running' ? (
                            <div className="text-slate-400 animate-pulse py-2">
                              Connecting to PostgreSQL replica socket...
                            </div>
                          ) : (
                            <pre className="text-slate-200 whitespace-pre-wrap leading-relaxed overflow-x-auto">
                              {simulatedDiagnostic.output}
                            </pre>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* 5. Unknown Information */}
              <div className="space-y-2.5">
                <div className="flex items-center space-x-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
                  <span>5. Unknown Information (Telemetry Gaps)</span>
                </div>
                <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4">
                  <ul className="space-y-1.5 text-xs text-slate-400 list-disc pl-4">
                    {investigation.unknownInformation.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-14 text-center space-y-3">
              <Brain className="w-10 h-10 text-slate-700 mx-auto" />
              <div className="text-sm font-medium text-slate-300">
                No active investigation report generated yet.
              </div>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Click <strong>Run Investigation</strong> above to trigger Hindsight associative memory recall and correlate all attached telemetry.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Attached Telemetry & Evidence */}
      {activeWorkspaceTab === 'evidence' && (
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <FileCode className="w-5 h-5 text-indigo-400" />
                <h2 className="text-base font-bold text-slate-100">
                  Technical Telemetry & Evidence Ledger
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Normalized logs, Prometheus timeseries metrics, and deployment git diffs attached to this incident.
              </p>
            </div>

            <button
              onClick={onAddEvidenceModal}
              className="flex items-center space-x-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Attach Evidence</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {evidence.map((item) => (
              <div
                key={item.id}
                className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 space-y-3 text-xs flex flex-col justify-between"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] text-cyan-300 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800 font-bold">
                      {item.evidenceType}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(item.createdAt).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="font-semibold text-slate-200 text-xs sm:text-sm">
                    {item.summary}
                  </div>

                  <div className="text-[11px] text-slate-400 font-mono">
                    Source: <span className="text-slate-300">{item.sourceName}</span>
                  </div>
                </div>

                <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-3 overflow-x-auto text-[11px] font-mono text-cyan-200/90 max-h-48">
                  <pre>{JSON.stringify(item.rawPayload, null, 2)}</pre>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Postmortem & Knowledge Retention */}
      {activeWorkspaceTab === 'postmortem' && (
        <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-5 sm:p-6 space-y-5 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <BookOpen className="w-5 h-5 text-emerald-400" />
                <h2 className="text-base font-bold text-slate-100">
                  Incident Postmortem & Knowledge Retention
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Rule BR-03: Postmortems must be verified by humans before being committed into Hindsight organizational memory.
              </p>
            </div>

            <button
              onClick={onOpenPostmortemModal}
              className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-4 py-2 rounded-xl transition cursor-pointer shadow-sm"
            >
              {postmortem ? 'Edit Postmortem' : 'Draft Postmortem'}
            </button>
          </div>

          {postmortem ? (
            <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-5 space-y-4 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <h3 className="font-bold text-slate-100 text-sm">
                  {postmortem.title}
                </h3>
                <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800 font-bold">
                  Document Ready for Review
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold">
                  Root Cause Explanation:
                </span>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {postmortem.rootCause}
                </p>
              </div>

              <div className="space-y-1">
                <span className="text-[10px] uppercase font-mono text-slate-400 font-semibold">
                  Trigger Event:
                </span>
                <p className="text-slate-300 text-xs leading-relaxed">
                  {postmortem.triggerEvent}
                </p>
              </div>

              <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg space-y-1 text-cyan-200 font-mono text-[11px]">
                <span className="text-[10px] uppercase text-cyan-400 font-semibold block">
                  Resolution Playbook:
                </span>
                <pre className="whitespace-pre-wrap">{postmortem.resolutionPlaybook}</pre>
              </div>
            </div>
          ) : (
            <div className="py-14 text-center space-y-3">
              <BookOpen className="w-10 h-10 text-slate-700 mx-auto" />
              <div className="text-sm font-medium text-slate-300">
                No postmortem drafted yet.
              </div>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Once the incident is resolved, draft a postmortem to queue it for Operations Admin approval and Hindsight retention.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

