/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Brain,
  Database,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  ArrowRight,
  Sparkles,
  Lock,
  Layers,
  X,
  Zap,
} from 'lucide-react';

interface LearnGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LearnGuideModal: React.FC<LearnGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const cognitiveStages = [
    {
      num: '01',
      title: 'Active Technical Evidence',
      badge: 'Observed Facts',
      badgeColor: 'bg-cyan-950 text-cyan-300 border-cyan-800',
      description:
        'When an outage occurs, raw telemetry (application logs, Prometheus timeseries, and git commit diffs) is ingested and normalized.',
      principle: 'Strict separation: Facts must not be confused with hypotheses.',
    },
    {
      num: '02',
      title: 'Hindsight Associative Recall',
      badge: 'Long-Term Memory',
      badgeColor: 'bg-indigo-950 text-indigo-300 border-indigo-800',
      description:
        'The agent queries tenant-isolated Hindsight memory banks using symptom vectors to recall previously approved postmortems.',
      principle: 'Rule BR-01: Only approved historical knowledge is recalled.',
    },
    {
      num: '03',
      title: 'Epistemological Agent Synthesis',
      badge: 'Evidence-Ranked',
      badgeColor: 'bg-purple-950 text-purple-300 border-purple-800',
      description:
        'The investigation engine separates observed facts, historical memories, ranked hypotheses, safe read-only diagnostics, and unknowns.',
      principle: 'Rule BR-05: Non-invasive. Never auto-execute mutations.',
    },
    {
      num: '04',
      title: 'Human-in-the-Loop Governance',
      badge: 'Rule BR-03',
      badgeColor: 'bg-emerald-950 text-emerald-300 border-emerald-800',
      description:
        'An Operations Admin reviews the resolution playbook. Only human approval commits new postmortem knowledge back to Hindsight.',
      principle: 'Operational amnesia is cured without runaway AI hallucination.',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl overflow-hidden shadow-2xl space-y-6 p-6">
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-slate-800/80 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <span>How OpsMemory AI Thinks</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Human-in-the-Loop Architecture
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Understanding the 4-step cognitive loop that eliminates operational amnesia.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition cursor-pointer"
            aria-label="Close Guide"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 4 Cognitive Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cognitiveStages.map((stage) => (
            <div
              key={stage.num}
              className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2 flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-cyan-400">
                    STAGE {stage.num}
                  </span>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded border font-semibold ${stage.badgeColor}`}
                  >
                    {stage.badge}
                  </span>
                </div>
                <h3 className="text-xs font-bold text-slate-200">
                  {stage.title}
                </h3>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {stage.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-900 text-[10px] font-mono text-slate-500 flex items-center space-x-1.5">
                <ShieldCheck className="w-3 h-3 text-cyan-500 shrink-0" />
                <span className="truncate">{stage.principle}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Two-Interaction Reality Check */}
        <div className="bg-gradient-to-r from-slate-950 to-indigo-950/50 border border-indigo-900/60 rounded-xl p-4 space-y-2">
          <div className="flex items-center space-x-2 text-indigo-300 text-xs font-bold">
            <Zap className="w-4 h-4 text-cyan-400" />
            <span>The Power of Associative Recall in Action</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            In standard operations, when an outage strikes, engineers spend <strong>45+ minutes</strong> rediscovering root causes from scratch. With OpsMemory AI, Outage #1’s approved fix is retained into Hindsight. When Outage #2 occurs 2 weeks later, the agent instantly recalls the exact root cause and playbook in <strong>3.5 minutes</strong>.
          </p>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
          <div className="text-[11px] text-slate-400 flex items-center space-x-2">
            <Lock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Strict Tenant Isolation · PostgreSQL SOR · Zero Destructive Commands</span>
          </div>
          <button
            onClick={onClose}
            className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs px-4 py-2 rounded-lg font-medium transition cursor-pointer"
          >
            Got it, Let's Investigate
          </button>
        </div>
      </div>
    </div>
  );
};
