/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  FileText,
  Search,
  ExternalLink,
  ChevronRight,
  Code,
  Layers,
} from 'lucide-react';

interface DocCategory {
  id: string;
  phase: string;
  name: string;
  files: { filename: string; title: string }[];
}

const DOC_CATALOG: DocCategory[] = [
  {
    id: 'research',
    phase: 'Phase 0',
    name: 'Research & Reconnaissance',
    files: [
      { filename: 'REPOSITORY_DISCOVERY.md', title: 'Repository Discovery & Prior Art' },
      { filename: 'HINDSIGHT_RESEARCH.md', title: 'Hindsight Cognitive Memory Research' },
      { filename: 'REVERSE_ENGINEERING_ANALYSIS.md', title: 'Reverse Engineering & Amnesia Tax' },
      { filename: 'OPEN_SOURCE_COMPARISON.md', title: 'Open-Source Comparison Matrix' },
      { filename: 'TECHNOLOGY_EVALUATION.md', title: 'Technology Evaluation' },
      { filename: 'LICENSE_AND_DEPENDENCY_REVIEW.md', title: 'License & Dependency Review' },
      { filename: 'RESEARCH_DECISIONS.md', title: 'Research Decisions (ADR-000)' },
    ],
  },
  {
    id: 'product',
    phase: 'Phase 1',
    name: 'Product Requirements',
    files: [
      { filename: 'PRODUCT_BRIEF.md', title: 'Product Vision & Positioning' },
      { filename: 'PROBLEM_STATEMENT.md', title: 'Problem Statement & Impact' },
      { filename: 'PRODUCT_REQUIREMENTS.md', title: 'PRD & Core Workflows' },
      { filename: 'FUNCTIONAL_REQUIREMENTS.md', title: 'Functional Requirements (FR)' },
      { filename: 'NON_FUNCTIONAL_REQUIREMENTS.md', title: 'Non-Functional Requirements (NFR)' },
      { filename: 'USER_PERSONAS.md', title: 'Target Personas' },
      { filename: 'USER_STORIES.md', title: 'User Stories & Epics' },
      { filename: 'BUSINESS_RULES.md', title: 'Business Rules & Integrity' },
      { filename: 'MVP_SCOPE.md', title: 'MVP Boundaries' },
      { filename: 'ACCEPTANCE_CRITERIA.md', title: 'Acceptance Criteria' },
    ],
  },
  {
    id: 'architecture',
    phase: 'Phase 2',
    name: 'System Architecture',
    files: [
      { filename: 'SYSTEM_ARCHITECTURE.md', title: 'System Architecture & C4 Model' },
      { filename: 'FRONTEND_ARCHITECTURE.md', title: 'Frontend Architecture' },
      { filename: 'BACKEND_ARCHITECTURE.md', title: 'Backend Service Architecture' },
      { filename: 'AI_AGENT_ARCHITECTURE.md', title: 'AI Agent Architecture' },
      { filename: 'HINDSIGHT_ARCHITECTURE.md', title: 'Hindsight Memory Architecture' },
      { filename: 'DATA_FLOW.md', title: 'Data Flow & Sequences' },
      { filename: 'DEPLOYMENT_ARCHITECTURE.md', title: 'Cloud Deployment Topology' },
      { filename: 'ARCHITECTURE_DECISIONS.md', title: 'Architecture Decision Records' },
    ],
  },
  {
    id: 'database',
    phase: 'Phase 3',
    name: 'Database & Schema',
    files: [
      { filename: 'DATABASE_SCHEMA.md', title: 'PostgreSQL Relational Schema' },
      { filename: 'ENTITY_RELATIONSHIPS.md', title: 'Entity Relationships' },
      { filename: 'TENANT_ISOLATION.md', title: 'Multi-Tenant Isolation Defense' },
      { filename: 'DATA_RETENTION.md', title: 'Data Retention & Durability' },
    ],
  },
  {
    id: 'api',
    phase: 'Phase 3',
    name: 'API Contracts',
    files: [
      { filename: 'API_CONTRACT.md', title: 'REST API Overview' },
      { filename: 'AUTHENTICATION_API.md', title: 'Authentication API' },
      { filename: 'INCIDENT_API.md', title: 'Incident & Evidence API' },
      { filename: 'INVESTIGATION_API.md', title: 'Investigation & Findings API' },
      { filename: 'MEMORY_API.md', title: 'Memory Engine API' },
      { filename: 'ERROR_RESPONSE_STANDARD.md', title: 'Standard Error Codes' },
    ],
  },
  {
    id: 'ui-ux',
    phase: 'Phase 4',
    name: 'UI/UX Design System',
    files: [
      { filename: 'DESIGN_SYSTEM.md', title: 'Design Tokens & Visual Direction' },
      { filename: 'PAGE_INVENTORY.md', title: '36-Page Directory' },
      { filename: 'USER_FLOWS.md', title: 'User Flows & Triage Journey' },
      { filename: 'COMPONENT_INVENTORY.md', title: 'Component Inventory' },
      { filename: 'WIREFRAME_SPECIFICATION.md', title: 'Wireframe Specifications' },
      { filename: 'RESPONSIVE_DESIGN.md', title: 'Responsive Design Strategy' },
      { filename: 'ACCESSIBILITY.md', title: 'WCAG 2.1 AA Accessibility' },
    ],
  },
  {
    id: 'ai-memory',
    phase: 'Phase 6',
    name: 'Hindsight Memory Engine',
    files: [
      { filename: 'HINDSIGHT_INTEGRATION.md', title: 'Hindsight Integration' },
      { filename: 'MEMORY_SCHEMA.md', title: 'Memory Retain & Recall Schema' },
      { filename: 'MEMORY_LIFECYCLE.md', title: 'Ten-Step Memory Lifecycle' },
      { filename: 'MEMORY_RETRIEVAL_STRATEGY.md', title: 'Hybrid Retrieval Formula' },
      { filename: 'MEMORY_SECURITY.md', title: 'Memory Security & Bank Isolation' },
      { filename: 'MEMORY_FAILURE_HANDLING.md', title: 'Failure Handling & Circuit Breaker' },
      { filename: 'MEMORY_EVALUATION.md', title: 'Memory Evaluation & Benchmarks' },
    ],
  },
  {
    id: 'ai-agent',
    phase: 'Phase 7',
    name: 'AI Investigation Agent',
    files: [
      { filename: 'AGENT_WORKFLOW.md', title: 'Agent Workflow & Orchestration' },
      { filename: 'INVESTIGATION_ALGORITHM.md', title: 'Epistemological Separation' },
      { filename: 'PROMPT_DESIGN.md', title: 'System Prompt Design' },
      { filename: 'STRUCTURED_OUTPUTS.md', title: 'Structured Output Schema' },
      { filename: 'TOOL_DEFINITIONS.md', title: 'Safe Read-Only Diagnostic Tools' },
      { filename: 'AI_FAILURE_HANDLING.md', title: 'AI Failure Handling' },
      { filename: 'AI_SAFETY_RULES.md', title: 'Safety Non-Negotiables' },
      { filename: 'EVALUATION_DATASET.md', title: 'Ground-Truth Scenarios' },
    ],
  },
  {
    id: 'security',
    phase: 'Phase 9',
    name: 'Security & Reliability',
    files: [
      { filename: 'THREAT_MODEL.md', title: 'STRIDE Threat Model' },
      { filename: 'SECURITY_REVIEW.md', title: 'Security Audit & Compliance' },
      { filename: 'PRIVACY_POLICY_REQUIREMENTS.md', title: 'Privacy Policy Requirements' },
      { filename: 'TENANT_SECURITY_TESTS.md', title: 'Automated Tenant Security Tests' },
      { filename: 'INCIDENT_RESPONSE_PLAN.md', title: 'Disaster Recovery Plan' },
      { filename: 'RELIABILITY_PLAN.md', title: 'Reliability & Chaos Tests' },
    ],
  },
  {
    id: 'testing',
    phase: 'Phase 10',
    name: 'Quality Assurance',
    files: [
      { filename: 'TEST_STRATEGY.md', title: 'Quality Assurance Strategy' },
      { filename: 'TEST_CASES.md', title: 'Test Cases Suite' },
      { filename: 'TEST_RESULTS.md', title: 'Test Execution Results' },
      { filename: 'E2E_SCENARIOS.md', title: 'Two-Incident E2E Scenario' },
      { filename: 'BUG_TRACKER.md', title: 'Defect Log & Resolution' },
      { filename: 'QUALITY_REPORT.md', title: 'Quality Assessment Report' },
    ],
  },
  {
    id: 'deployment',
    phase: 'Phase 11',
    name: 'Deployment & Production',
    files: [
      { filename: 'LOCAL_SETUP.md', title: 'Local Setup & Runbook' },
      { filename: 'ENVIRONMENT_VARIABLES.md', title: 'Environment Variables Directory' },
      { filename: 'DOCKER_SETUP.md', title: 'Docker & Docker Compose' },
      { filename: 'DEPLOYMENT_GUIDE.md', title: 'Cloud Run / K8s Deployment' },
      { filename: 'PRODUCTION_CHECKLIST.md', title: 'Production Readiness Checklist' },
      { filename: 'BACKUP_AND_RECOVERY.md', title: 'Backup & Recovery' },
      { filename: 'TROUBLESHOOTING.md', title: 'Production Troubleshooting' },
    ],
  },
  {
    id: 'submission',
    phase: 'Phase 12',
    name: 'Hackathon Submission Package',
    files: [
      { filename: 'PROJECT_OVERVIEW.md', title: 'Project Overview & Value Prop' },
      { filename: 'DEMO_SCRIPT.md', title: 'Two-Interaction Demo Script' },
      { filename: 'VIDEO_STORYBOARD.md', title: '3-Minute Video Storyboard' },
      { filename: 'HINDSIGHT_EXPLANATION.md', title: 'Why Hindsight vs Vector DBs' },
      { filename: 'SUBMISSION_CHECKLIST.md', title: 'Submission Verification Audit' },
    ],
  },
  {
    id: 'root',
    phase: 'Phase 13',
    name: 'Version Control & Governance',
    files: [
      { filename: 'VERSION.md', title: 'VERSION.md (SemVer 2.0)' },
      { filename: 'CHANGELOG.md', title: 'CHANGELOG.md (Full Change Log)' },
      { filename: 'IMPLEMENTATION_STATUS.md', title: 'IMPLEMENTATION_STATUS.md (Status Ledger)' },
      { filename: 'ROADMAP.md', title: 'ROADMAP.md (Milestones v0.1 - v1.0)' },
      { filename: 'DECISION_LOG.md', title: 'DECISION_LOG.md (ADR-001 to ADR-006)' },
      { filename: 'CONTRIBUTING.md', title: 'CONTRIBUTING.md (Engineering Standards)' },
      { filename: 'README.md', title: 'README.md (Repository Overview)' },
    ],
  },
];

export const DocumentationView: React.FC = () => {
  const [selectedCat, setSelectedCat] = useState<string>('research');
  const [selectedFile, setSelectedFile] = useState<string>('REPOSITORY_DISCOVERY.md');
  const [docContent, setDocContent] = useState<string>('Loading specification...');
  const [loading, setLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    async function loadDoc() {
      setLoading(true);
      try {
        const res = await fetch(`/api/docs/${selectedCat}/${selectedFile}`);
        if (!res.ok) throw new Error('Document not found');
        const json = await res.json();
        setDocContent(json.data.content);
      } catch (err) {
        setDocContent(`# Document: ${selectedFile}\n\nUnable to load document via API. Please inspect /docs/${selectedCat}/${selectedFile} directly.`);
      } finally {
        setLoading(false);
      }
    }
    loadDoc();
  }, [selectedCat, selectedFile]);

  // Filter Catalog by Search Query
  const filteredCatalog = DOC_CATALOG.map((cat) => {
    if (!searchQuery.trim()) return cat;
    const matchingFiles = cat.files.filter(
      (f) =>
        f.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        f.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cat.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    return { ...cat, files: matchingFiles };
  }).filter((cat) => cat.files.length > 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center space-x-2">
          <BookOpen className="w-6 h-6 text-cyan-400" />
          <h1 className="text-xl font-bold text-slate-100 tracking-tight">
            Engineering & Product Documentation Browser
          </h1>
          <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
            Phase 0 to 13 Specs
          </span>
        </div>
        <p className="text-slate-400 text-xs mt-1">
          Full in-app navigation across all research, architectural decision records, database schemas, API contracts, security models, and verification suites.
        </p>
      </div>

      {/* Main Dual-Pane Browser */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-14rem)]">
        {/* Left Index (4 Cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-3 overflow-y-auto space-y-3 flex flex-col">
          {/* Search Box */}
          <div className="relative shrink-0">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search 60+ specifications & phases..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-4 overflow-y-auto flex-1 pr-1">
            {filteredCatalog.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                No specifications match "{searchQuery}"
              </div>
            ) : (
              filteredCatalog.map((cat) => (
                <div key={cat.id} className="space-y-1">
                  <div className="px-2 py-1 flex items-center justify-between text-[11px] font-mono text-cyan-400 uppercase font-semibold">
                    <span>{cat.phase}: {cat.name}</span>
                  </div>

                  <div className="space-y-0.5">
                    {cat.files.map((f) => {
                      const isSelected = selectedCat === cat.id && selectedFile === f.filename;
                      return (
                        <button
                          key={f.filename}
                          onClick={() => {
                            setSelectedCat(cat.id);
                            setSelectedFile(f.filename);
                          }}
                          className={`w-full text-left px-2.5 py-1.5 rounded text-xs flex items-center justify-between transition cursor-pointer ${
                            isSelected
                              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-medium'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                          }`}
                        >
                          <span className="truncate pr-2">{f.title}</span>
                          <ChevronRight className="w-3 h-3 opacity-50 shrink-0" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Content Viewer (8 Cols) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-6 overflow-y-auto font-mono text-xs text-slate-300 space-y-4 shadow-inner">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 font-sans">
            <div>
              <div className="text-[11px] text-cyan-400 font-mono">
                /docs/{selectedCat}/{selectedFile}
              </div>
              <h2 className="text-sm font-bold text-slate-100 mt-0.5">
                {DOC_CATALOG.find((c) => c.id === selectedCat)?.files.find((f) => f.filename === selectedFile)?.title || selectedFile}
              </h2>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
              Markdown Source
            </span>
          </div>

          {loading ? (
            <div className="py-20 text-center text-slate-500 font-sans text-xs">
              Loading document content...
            </div>
          ) : (
            <div className="bg-slate-950 p-4 rounded-lg border border-slate-800/80 leading-relaxed overflow-x-auto whitespace-pre-wrap text-slate-300">
              {docContent}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
