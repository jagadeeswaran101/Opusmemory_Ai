/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Search, Lock, Clock, Eye, Download } from 'lucide-react';
import { AuditLogEntry } from '../types/index.ts';

interface AuditLogsViewProps {
  logs: AuditLogEntry[];
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ logs }) => {
  const [filterAction, setFilterAction] = useState('ALL');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const actions = ['ALL', ...Array.from(new Set(logs.map((l) => l.action)))];

  const filtered = logs.filter(
    (l) => filterAction === 'ALL' || l.action === filterAction
  );

  return (
    <div className="space-y-6">
      {/* Header with Compliance Export Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Shield className="w-6 h-6 text-cyan-400" />
            <h1 className="text-xl font-bold text-slate-100 tracking-tight">
              Security & Audit Trail
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              Append-Only WORM Ledger
            </span>
          </div>
          <p className="text-slate-400 text-xs mt-1">
            Complete, tamper-evident audit record of all incident mutations, investigations, postmortem approvals, and Hindsight memory commits.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <a
            href="/api/audit-logs/export?format=json"
            download
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-xs text-slate-200 transition font-medium cursor-pointer"
            title="Export full audit log in JSON format for compliance audits"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </a>
          <a
            href="/api/audit-logs/export?format=csv"
            download
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-850 hover:bg-slate-800 border border-slate-700/80 text-xs text-slate-200 transition font-medium cursor-pointer"
            title="Export full audit log in CSV format for spreadsheet analysis"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Export CSV</span>
          </a>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl flex items-center space-x-3 text-xs overflow-x-auto">
        <span className="text-slate-400 font-medium shrink-0">Filter Action:</span>
        {actions.map((act) => (
          <button
            key={act}
            onClick={() => setFilterAction(act)}
            className={`px-2.5 py-1 rounded text-[11px] font-mono transition cursor-pointer shrink-0 ${
              filterAction === act
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {act}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 font-mono text-[11px] uppercase border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Actor</th>
                <th className="py-3 px-4">Action</th>
                <th className="py-3 px-4">Resource</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {filtered.map((log) => {
                const isExpanded = expandedId === log.id;
                return (
                  <React.Fragment key={log.id}>
                    <tr className="hover:bg-slate-850/60 transition">
                      <td className="py-3 px-4 font-mono text-slate-400 text-[11px] whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-200 whitespace-nowrap">
                        {log.userEmail}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-mono text-[10px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-cyan-300">
                          {log.action}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                        {log.resourceType} ({log.resourceId.substring(0, 12)}...)
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setExpandedId(isExpanded ? null : log.id)}
                          className="text-cyan-400 hover:text-cyan-300 text-xs font-medium cursor-pointer"
                        >
                          {isExpanded ? 'Hide' : 'Inspect'}
                        </button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="bg-slate-950/90">
                        <td colSpan={5} className="p-4">
                          <div className="bg-slate-900 p-3 rounded border border-slate-800 text-[11px] font-mono text-cyan-200">
                            <pre className="whitespace-pre-wrap">{JSON.stringify(log.details, null, 2)}</pre>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
