/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { Sidebar, ActiveTab } from './components/Sidebar.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { GeminiCopilotView } from './components/GeminiCopilotView.tsx';
import { IncidentsListView } from './components/IncidentsListView.tsx';
import { IncidentDetailView } from './components/IncidentDetailView.tsx';
import { MemoryExplorerView } from './components/MemoryExplorerView.tsx';
import { ApprovalQueueView } from './components/ApprovalQueueView.tsx';
import { TwoIncidentDemoView } from './components/TwoIncidentDemoView.tsx';
import { AuditLogsView } from './components/AuditLogsView.tsx';
import { DocumentationView } from './components/DocumentationView.tsx';
import { CreateIncidentModal } from './components/CreateIncidentModal.tsx';
import { PostmortemModal } from './components/PostmortemModal.tsx';
import { AddEvidenceModal } from './components/AddEvidenceModal.tsx';
import { LearnGuideModal } from './components/LearnGuideModal.tsx';
import { WebhookSimulatorModal } from './components/WebhookSimulatorModal.tsx';
import {
  User,
  Organization,
  Incident,
  IncidentEvidence,
  InvestigationReport,
  Postmortem,
  KnowledgeApproval,
  AuditLogEntry,
  MemoryBankStats,
  IncidentSeverity,
  IncidentStatus,
  EvidenceType,
} from './types/index.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [selectedIncidentId, setSelectedIncidentId] = useState<string>('inc_142_payments_db');
  const [isLearnModalOpen, setIsLearnModalOpen] = useState(false);

  // Multi-Tenancy & User State
  const [currentOrg, setCurrentOrg] = useState<Organization>({
    id: 'org_acme_prod',
    slug: 'acme-cloud',
    name: 'Acme Cloud Infrastructure',
    tier: 'ENTERPRISE',
    memoryBankId: 'org_acme_prod_ops',
    createdAt: '2026-01-10T00:00:00Z',
  });

  const [users, setUsers] = useState<User[]>([
    {
      id: 'usr_elena',
      organizationId: 'org_acme_prod',
      email: 'elena.rostova@acme.internal',
      fullName: 'Elena Rostova',
      role: 'OPERATIONS_ADMIN',
      avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
      createdAt: '2026-01-10T00:00:00Z',
    },
    {
      id: 'usr_marcus',
      organizationId: 'org_acme_prod',
      email: 'marcus.vance@acme.internal',
      fullName: 'Marcus Vance',
      role: 'DEVOPS_ENGINEER',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      createdAt: '2026-01-11T00:00:00Z',
    },
    {
      id: 'usr_priya',
      organizationId: 'org_acme_prod',
      email: 'priya.sharma@acme.internal',
      fullName: 'Priya Sharma',
      role: 'ORGANIZATION_OWNER',
      avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
      createdAt: '2026-01-10T00:00:00Z',
    },
  ]);

  const [currentUser, setCurrentUser] = useState<User>(users[0]); // Default to Elena (Admin)

  // Incident & Operational State
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [evidenceList, setEvidenceList] = useState<IncidentEvidence[]>([]);
  const [currentInvestigation, setCurrentInvestigation] = useState<InvestigationReport | undefined>();
  const [currentPostmortem, setCurrentPostmortem] = useState<Postmortem | undefined>();
  const [approvals, setApprovals] = useState<KnowledgeApproval[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [memoryBankStats, setMemoryBankStats] = useState<MemoryBankStats | undefined>();
  const [bankMemories, setBankMemories] = useState<any[]>([]);

  // Modals & Async Loaders
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isPostmortemModalOpen, setIsPostmortemModalOpen] = useState(false);
  const [isEvidenceModalOpen, setIsEvidenceModalOpen] = useState(false);
  const [isWebhookModalOpen, setIsWebhookModalOpen] = useState(false);

  // Initial Data Fetch
  const refreshData = async () => {
    try {
      const [incRes, apprRes, memRes, audRes] = await Promise.all([
        fetch('/api/incidents'),
        fetch('/api/knowledge-approvals'),
        fetch('/api/memory/banks'),
        fetch('/api/audit-logs'),
      ]);

      if (incRes.ok) {
        const json = await incRes.json();
        setIncidents(json.data);
      }
      if (apprRes.ok) {
        const json = await apprRes.json();
        setApprovals(json.data);
      }
      if (memRes.ok) {
        const json = await memRes.json();
        setMemoryBankStats(json.data.stats);
        setBankMemories(json.data.memories);
      }
      if (audRes.ok) {
        const json = await audRes.json();
        setAuditLogs(json.data);
      }
    } catch (err) {
      console.warn('Initial data load error:', err);
    }
  };

  useEffect(() => {
    refreshData();
  }, [currentUser]);

  // Global Keyboard Accessibility (UX-002: Escape dismisses open modals)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isCreateModalOpen) setIsCreateModalOpen(false);
        if (isPostmortemModalOpen) setIsPostmortemModalOpen(false);
        if (isEvidenceModalOpen) setIsEvidenceModalOpen(false);
        if (isLearnModalOpen) setIsLearnModalOpen(false);
        if (isWebhookModalOpen) setIsWebhookModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCreateModalOpen, isPostmortemModalOpen, isEvidenceModalOpen, isLearnModalOpen, isWebhookModalOpen]);

  // Load Incident Detail
  const loadIncidentDetail = async (id: string) => {
    try {
      const res = await fetch(`/api/incidents/${id}`);
      if (res.ok) {
        const json = await res.json();
        setEvidenceList(json.data.evidence);
        setCurrentInvestigation(json.data.investigation);
        setCurrentPostmortem(json.data.postmortem);
      }
    } catch (err) {
      console.warn('Failed loading incident detail:', err);
    }
  };

  useEffect(() => {
    if (selectedIncidentId) {
      loadIncidentDetail(selectedIncidentId);
    }
  }, [selectedIncidentId]);

  // Actions
  const handleOpenIncident = (id: string) => {
    setSelectedIncidentId(id);
    setActiveTab('incident-detail');
  };

  const handleCreateIncident = async (data: {
    title: string;
    summary: string;
    severity: IncidentSeverity;
    service: string;
  }) => {
    const res = await fetch('/api/incidents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      const json = await res.json();
      await refreshData();
      handleOpenIncident(json.data.id);
    }
  };

  const handleUpdateIncidentStatus = async (status: IncidentStatus) => {
    const res = await fetch(`/api/incidents/${selectedIncidentId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      await refreshData();
      await loadIncidentDetail(selectedIncidentId);
    }
  };

  const handleRunInvestigation = async () => {
    setIsInvestigating(true);
    try {
      const res = await fetch(`/api/incidents/${selectedIncidentId}/investigate`, {
        method: 'POST',
      });
      if (res.ok) {
        const json = await res.json();
        setCurrentInvestigation(json.data);
        await refreshData();
      }
    } finally {
      setIsInvestigating(false);
    }
  };

  const handleAddEvidence = async (data: {
    evidenceType: EvidenceType;
    sourceName: string;
    summary: string;
    rawPayload: any;
  }) => {
    const res = await fetch(`/api/incidents/${selectedIncidentId}/evidence`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      await loadIncidentDetail(selectedIncidentId);
      await refreshData();
    }
  };

  const handleSavePostmortem = async (data: {
    title: string;
    rootCause: string;
    triggerEvent: string;
    resolutionPlaybook: string;
    preventionItems: string[];
  }) => {
    const res = await fetch(`/api/incidents/${selectedIncidentId}/postmortem`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (res.ok) {
      await handleUpdateIncidentStatus('RESOLVED');
      await refreshData();
      await loadIncidentDetail(selectedIncidentId);
    }
  };

  const handleReviewApproval = async (
    approvalId: string,
    decision: 'APPROVED' | 'REJECTED',
    notes?: string
  ) => {
    const res = await fetch(`/api/knowledge-approvals/${approvalId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision, reviewNotes: notes }),
    });
    if (res.ok) {
      await refreshData();
    }
  };

  const handleTestRecall = async (query: string) => {
    const res = await fetch('/api/memory/recall', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query }),
    });
    if (res.ok) {
      const json = await res.json();
      return json.data;
    }
    return [];
  };

  const handleTriggerReflect = async () => {
    const res = await fetch('/api/memory/reflect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: 'systemic-fragility' }),
    });
    if (res.ok) {
      const json = await res.json();
      return json.data;
    }
    return null;
  };

  const handleRunTwoIncidentSimulation = async () => {
    const res = await fetch('/api/simulate-two-incident-journey', {
      method: 'POST',
    });
    if (res.ok) {
      const json = await res.json();
      await refreshData();
      return json.data;
    }
    throw new Error('Simulation failed');
  };

  const activeIncident = incidents.find((i) => i.id === selectedIncidentId);
  const activeSev1Count = incidents.filter(
    (i) => i.severity === 'SEV-1' && i.status !== 'RESOLVED'
  ).length;
  const pendingApprovalsCount = approvals.filter(
    (a) => a.status === 'PENDING'
  ).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      <Header
        currentOrg={currentOrg}
        currentUser={currentUser}
        onUserChange={setCurrentUser}
        users={users}
        activeSev1Count={activeSev1Count}
        onToggleLearnMode={() => setIsLearnModalOpen(!isLearnModalOpen)}
        isLearnModeOpen={isLearnModalOpen}
        onOpenGeminiCopilot={() => setActiveTab('gemini-copilot')}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          pendingApprovalsCount={pendingApprovalsCount}
          activeIncidentsCount={incidents.filter((i) => i.status !== 'RESOLVED').length}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-950 pb-20 md:pb-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardView
                incidents={incidents}
                memories={bankMemories}
                currentUser={currentUser}
                onOpenIncident={handleOpenIncident}
                onNavigateTab={setActiveTab}
                onOpenLearnGuide={() => setIsLearnModalOpen(true)}
              />
            )}

            {activeTab === 'gemini-copilot' && (
              <GeminiCopilotView
                incidents={incidents}
                selectedIncidentId={selectedIncidentId}
                onOpenIncident={handleOpenIncident}
              />
            )}

            {activeTab === 'incidents' && (
              <IncidentsListView
                incidents={incidents}
                onOpenIncident={handleOpenIncident}
                onCreateIncidentClick={() => setIsCreateModalOpen(true)}
                onOpenWebhookSimulator={() => setIsWebhookModalOpen(true)}
              />
            )}

            {activeTab === 'incident-detail' && activeIncident && (
              <IncidentDetailView
                incident={activeIncident}
                evidence={evidenceList}
                investigation={currentInvestigation}
                postmortem={currentPostmortem}
                onBack={() => setActiveTab('incidents')}
                onUpdateStatus={handleUpdateIncidentStatus}
                onRunInvestigation={handleRunInvestigation}
                onOpenPostmortemModal={() => setIsPostmortemModalOpen(true)}
                onAddEvidenceModal={() => setIsEvidenceModalOpen(true)}
                isInvestigating={isInvestigating}
                onOpenGeminiCopilot={() => setActiveTab('gemini-copilot')}
              />
            )}

            {activeTab === 'memory-explorer' && (
              <MemoryExplorerView
                stats={memoryBankStats}
                memories={bankMemories}
                onTestRecall={handleTestRecall}
                onTriggerReflect={handleTriggerReflect}
              />
            )}

            {activeTab === 'approval-queue' && (
              <ApprovalQueueView
                approvals={approvals}
                onReview={handleReviewApproval}
                currentUserRole={currentUser.role}
              />
            )}

            {activeTab === 'two-incident-demo' && (
              <TwoIncidentDemoView onRunSimulation={handleRunTwoIncidentSimulation} />
            )}

            {activeTab === 'audit-logs' && <AuditLogsView logs={auditLogs} />}

            {activeTab === 'documentation' && <DocumentationView />}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav aria-label="Mobile Navigation" className="md:hidden fixed bottom-0 left-0 right-0 h-14 bg-slate-950 border-t border-slate-800 flex items-center justify-around z-30 px-2 text-[10px]">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center py-1 cursor-pointer ${activeTab === 'dashboard' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          <span>Dashboard</span>
        </button>
        <button
          onClick={() => setActiveTab('gemini-copilot')}
          className={`flex flex-col items-center py-1 cursor-pointer ${activeTab === 'gemini-copilot' ? 'text-indigo-400 font-bold' : 'text-slate-400'}`}
        >
          <span className="text-cyan-400 font-semibold">✦ Gemini</span>
        </button>
        <button
          onClick={() => setActiveTab('incidents')}
          className={`flex flex-col items-center py-1 cursor-pointer ${activeTab === 'incidents' || activeTab === 'incident-detail' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          <span>Incidents</span>
        </button>
        <button
          onClick={() => setActiveTab('memory-explorer')}
          className={`flex flex-col items-center py-1 cursor-pointer ${activeTab === 'memory-explorer' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          <span>Memory</span>
        </button>
        <button
          onClick={() => setActiveTab('two-incident-demo')}
          className={`flex flex-col items-center py-1 cursor-pointer ${activeTab === 'two-incident-demo' ? 'text-cyan-400 font-bold' : 'text-slate-400'}`}
        >
          <span>E2E Demo</span>
        </button>
      </nav>

      {/* Modals */}
      <CreateIncidentModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreateIncident}
      />

      {activeIncident && (
        <PostmortemModal
          isOpen={isPostmortemModalOpen}
          onClose={() => setIsPostmortemModalOpen(false)}
          incident={activeIncident}
          existingPostmortem={currentPostmortem}
          onSubmit={handleSavePostmortem}
        />
      )}

      <AddEvidenceModal
        isOpen={isEvidenceModalOpen}
        onClose={() => setIsEvidenceModalOpen(false)}
        onSubmit={handleAddEvidence}
      />

      <LearnGuideModal
        isOpen={isLearnModalOpen}
        onClose={() => setIsLearnModalOpen(false)}
      />

      <WebhookSimulatorModal
        isOpen={isWebhookModalOpen}
        onClose={() => setIsWebhookModalOpen(false)}
        onIncidentCreated={async (id) => {
          await refreshData();
          handleOpenIncident(id);
        }}
      />
    </div>
  );
}
