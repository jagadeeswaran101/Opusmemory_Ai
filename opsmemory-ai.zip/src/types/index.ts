/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole =
  | 'ORGANIZATION_OWNER'
  | 'OPERATIONS_ADMIN'
  | 'DEVOPS_ENGINEER'
  | 'INCIDENT_RESPONDER'
  | 'READ_ONLY_OBSERVER';

export interface User {
  id: string;
  organizationId: string;
  email: string;
  fullName: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string;
}

export interface Organization {
  id: string;
  slug: string;
  name: string;
  tier: 'STARTER' | 'PRO' | 'ENTERPRISE';
  memoryBankId: string;
  createdAt: string;
}

export type IncidentSeverity = 'SEV-1' | 'SEV-2' | 'SEV-3' | 'SEV-4';

export type IncidentStatus =
  | 'TRIGGERED'
  | 'INVESTIGATING'
  | 'IDENTIFIED'
  | 'MITIGATED'
  | 'RESOLVED';

export interface Incident {
  id: string;
  organizationId: string;
  incidentNumber: number;
  title: string;
  summary: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  service: string;
  assignedUserId?: string;
  createdAt: string;
  resolvedAt?: string;
  updatedAt: string;
}

export type EvidenceType =
  | 'LOG_SNIPPET'
  | 'METRIC_SERIES'
  | 'STACK_TRACE'
  | 'DEPLOYMENT_DIFF'
  | 'ALERT_PAYLOAD';

export interface IncidentEvidence {
  id: string;
  organizationId: string;
  incidentId: string;
  evidenceType: EvidenceType;
  sourceName: string;
  summary: string;
  rawPayload: Record<string, unknown> | Array<unknown> | string;
  createdAt: string;
}

export interface RecalledMemory {
  memoryId: string;
  incidentNumber: number;
  sourceIncidentId: string;
  title: string;
  service: string;
  similarityScore: number;
  relevanceExplanation: string;
  rootCause: string;
  keyTakeaway: string;
  resolutionPlaybook: string;
  retainedAt: string;
}

export interface Hypothesis {
  id: string;
  hypothesis: string;
  likelihood: 'HIGH' | 'MEDIUM' | 'LOW';
  supportingEvidenceIds: string[];
  contradictingEvidenceIds: string[];
  recalledMemoryCitations: string[];
}

export interface SafeDiagnosticCheck {
  id: string;
  title: string;
  command: string;
  safetyLevel: 'READ_ONLY_SAFE' | 'CAUTION';
  rationale: string;
  expectedInsight: string;
}

export interface InvestigationReport {
  id: string;
  organizationId: string;
  incidentId: string;
  confidenceScore: number;
  confidenceRationale: string;
  observedFacts: string[];
  historicalMemories: RecalledMemory[];
  possibleCauses: Hypothesis[];
  recommendedDiagnosticChecks: SafeDiagnosticCheck[];
  unknownInformation: string[];
  createdAt: string;
}

export interface Postmortem {
  id: string;
  organizationId: string;
  incidentId: string;
  authorId: string;
  title: string;
  rootCause: string;
  triggerEvent: string;
  resolutionPlaybook: string;
  preventionItems: string[];
  retainedInHindsight: boolean;
  hindsightMemoryId?: string;
  createdAt: string;
  updatedAt: string;
}

export type ApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface KnowledgeApproval {
  id: string;
  organizationId: string;
  postmortemId: string;
  incidentId: string;
  incidentTitle: string;
  submittedBy: string;
  status: ApprovalStatus;
  reviewedBy?: string;
  reviewNotes?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  organizationId: string;
  userId: string;
  userEmail: string;
  action: string;
  resourceType: string;
  resourceId: string;
  details: Record<string, unknown>;
  createdAt: string;
}

export interface MemoryBankStats {
  bankId: string;
  organizationId: string;
  totalMemories: number;
  lastRetentionAt?: string;
  health: 'HEALTHY' | 'DEGRADED';
  averageRecallLatencyMs: number;
}
