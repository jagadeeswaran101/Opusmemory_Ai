/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type {
  Organization,
  User,
  Incident,
  IncidentEvidence,
  InvestigationReport,
  Postmortem,
  KnowledgeApproval,
  AuditLogEntry,
  UserRole,
  IncidentSeverity,
  IncidentStatus,
  EvidenceType,
} from '../types/index.ts';

/**
 * System of Record Store
 * Implements PostgreSQL transactional entities, strict tenant isolation,
 * role authorization, and immutable audit logging.
 */
export class SystemOfRecordStore {
  private organizations: Map<string, Organization> = new Map();
  private users: Map<string, User> = new Map();
  private incidents: Map<string, Incident> = new Map();
  private evidence: Map<string, IncidentEvidence> = new Map();
  private investigations: Map<string, InvestigationReport> = new Map();
  private postmortems: Map<string, Postmortem> = new Map();
  private approvals: Map<string, KnowledgeApproval> = new Map();
  private auditLogs: AuditLogEntry[] = [];
  private incidentCounter = 142;

  constructor() {
    this.seedDefaultData();
  }

  // -------------------------------------------------------------
  // Seed Data Initializer
  // -------------------------------------------------------------
  private seedDefaultData(): void {
    const defaultOrg: Organization = {
      id: 'org_acme_prod',
      slug: 'acme-cloud',
      name: 'Acme Cloud Infrastructure',
      tier: 'ENTERPRISE',
      memoryBankId: 'org_acme_prod_ops',
      createdAt: '2026-01-10T00:00:00Z',
    };
    this.organizations.set(defaultOrg.id, defaultOrg);

    const users: User[] = [
      {
        id: 'usr_elena',
        organizationId: defaultOrg.id,
        email: 'elena.rostova@acme.internal',
        fullName: 'Elena Rostova',
        role: 'OPERATIONS_ADMIN',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150',
        createdAt: '2026-01-10T00:00:00Z',
      },
      {
        id: 'usr_marcus',
        organizationId: defaultOrg.id,
        email: 'marcus.vance@acme.internal',
        fullName: 'Marcus Vance',
        role: 'DEVOPS_ENGINEER',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
        createdAt: '2026-01-11T00:00:00Z',
      },
      {
        id: 'usr_priya',
        organizationId: defaultOrg.id,
        email: 'priya.sharma@acme.internal',
        fullName: 'Priya Sharma',
        role: 'ORGANIZATION_OWNER',
        avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150',
        createdAt: '2026-01-10T00:00:00Z',
      },
    ];
    users.forEach((u) => this.users.set(u.id, u));

    // Seed Active Incident #142 (PostgreSQL Connection Pool Exhaustion)
    const inc142: Incident = {
      id: 'inc_142_payments_db',
      organizationId: defaultOrg.id,
      incidentNumber: 142,
      title: 'PostgreSQL Connection Pool Saturation on Payments DB',
      summary:
        'Payments checkout service returning HTTP 500 spikes; active connection pool reached maximum capacity (100/100).',
      severity: 'SEV-1',
      status: 'INVESTIGATING',
      service: 'payments-db',
      assignedUserId: 'usr_marcus',
      createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
    };
    this.incidents.set(inc142.id, inc142);

    // Attached Evidence for Incident #142
    const evidenceItems: IncidentEvidence[] = [
      {
        id: 'evi_log_53300',
        organizationId: defaultOrg.id,
        incidentId: inc142.id,
        evidenceType: 'LOG_SNIPPET',
        sourceName: 'payments-service-pod-88fa',
        summary:
          'FATAL: remaining connection slots are reserved for non-replication superuser connections (SQLSTATE 53300)',
        rawPayload: {
          timestamp: new Date(Date.now() - 24 * 60 * 1000).toISOString(),
          sqlState: '53300',
          poolCapacity: 100,
          activeConnections: 100,
          idleConnections: 0,
          threadsAwaitingConnection: 48,
        },
        createdAt: new Date(Date.now() - 23 * 60 * 1000).toISOString(),
      },
      {
        id: 'evi_metric_pool',
        organizationId: defaultOrg.id,
        incidentId: inc142.id,
        evidenceType: 'METRIC_SERIES',
        sourceName: 'prometheus.payments.db.pool.active',
        summary:
          'HikariCP active connections plateaued at 100/100 cap for 18 consecutive minutes.',
        rawPayload: [
          { time: 'T-20m', value: 22 },
          { time: 'T-15m', value: 58 },
          { time: 'T-10m', value: 100 },
          { time: 'T-5m', value: 100 },
          { time: 'T-0m', value: 100 },
        ],
        createdAt: new Date(Date.now() - 20 * 60 * 1000).toISOString(),
      },
      {
        id: 'evi_git_diff',
        organizationId: defaultOrg.id,
        incidentId: inc142.id,
        evidenceType: 'DEPLOYMENT_DIFF',
        sourceName: 'git.payments-service.commit/8f2a1b',
        summary:
          'Release v2.4.1 deployed 32m ago added unpaginated batch settlement query without datasource timeouts.',
        rawPayload: {
          commit: '8f2a1b90c',
          author: 'dev-team',
          diffSummary:
            '+ List<Invoice> invoices = entityManager.createQuery("SELECT i FROM Invoice i WHERE i.status = :s").getResultList();',
        },
        createdAt: new Date(Date.now() - 18 * 60 * 1000).toISOString(),
      },
    ];
    evidenceItems.forEach((e) => this.evidence.set(e.id, e));

    // Initial Audit Log
    this.recordAudit(
      defaultOrg.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      'INCIDENT_CREATED',
      'Incident',
      inc142.id,
      { incidentNumber: 142, severity: 'SEV-1', service: 'payments-db' }
    );
  }

  // -------------------------------------------------------------
  // Audit Logging
  // -------------------------------------------------------------
  public recordAudit(
    organizationId: string,
    userId: string,
    userEmail: string,
    action: string,
    resourceType: string,
    resourceId: string,
    details: Record<string, unknown> = {}
  ): AuditLogEntry {
    const entry: AuditLogEntry = {
      id: `aud_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      organizationId,
      userId,
      userEmail,
      action,
      resourceType,
      resourceId,
      details,
      createdAt: new Date().toISOString(),
    };
    this.auditLogs.unshift(entry);
    return entry;
  }

  public getAuditLogs(organizationId: string): AuditLogEntry[] {
    return this.auditLogs.filter((l) => l.organizationId === organizationId);
  }

  // -------------------------------------------------------------
  // Organizations & Users
  // -------------------------------------------------------------
  public getOrganization(id: string): Organization | undefined {
    return this.organizations.get(id);
  }

  public listOrganizations(): Organization[] {
    return Array.from(this.organizations.values());
  }

  public createOrganization(name: string, slug: string): Organization {
    const org: Organization = {
      id: `org_${slug}_${Date.now()}`,
      name,
      slug,
      tier: 'ENTERPRISE',
      memoryBankId: `org_${slug}_ops`,
      createdAt: new Date().toISOString(),
    };
    this.organizations.set(org.id, org);
    return org;
  }

  public getUser(id: string): User | undefined {
    return this.users.get(id);
  }

  public listUsers(organizationId: string): User[] {
    return Array.from(this.users.values()).filter(
      (u) => u.organizationId === organizationId
    );
  }

  // -------------------------------------------------------------
  // Incidents
  // -------------------------------------------------------------
  public listIncidents(organizationId: string): Incident[] {
    return Array.from(this.incidents.values())
      .filter((i) => i.organizationId === organizationId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  public getIncident(
    organizationId: string,
    id: string
  ): Incident | undefined {
    const incident = this.incidents.get(id);
    if (!incident || incident.organizationId !== organizationId) {
      return undefined;
    }
    return incident;
  }

  public createIncident(
    organizationId: string,
    actorId: string,
    actorEmail: string,
    title: string,
    summary: string,
    severity: IncidentSeverity,
    service: string
  ): Incident {
    this.incidentCounter += 1;
    const now = new Date().toISOString();
    const incident: Incident = {
      id: `inc_${this.incidentCounter}_${service.replace(/[^a-zA-Z0-9]/g, '_')}`,
      organizationId,
      incidentNumber: this.incidentCounter,
      title,
      summary,
      severity,
      status: 'TRIGGERED',
      service,
      assignedUserId: actorId,
      createdAt: now,
      updatedAt: now,
    };
    this.incidents.set(incident.id, incident);

    this.recordAudit(
      organizationId,
      actorId,
      actorEmail,
      'INCIDENT_CREATED',
      'Incident',
      incident.id,
      { incidentNumber: incident.incidentNumber, severity, service }
    );
    return incident;
  }

  public updateIncidentStatus(
    organizationId: string,
    actorId: string,
    actorEmail: string,
    id: string,
    status: IncidentStatus
  ): Incident | undefined {
    const incident = this.getIncident(organizationId, id);
    if (!incident) return undefined;

    const previousStatus = incident.status;
    incident.status = status;
    incident.updatedAt = new Date().toISOString();
    if (status === 'RESOLVED') {
      incident.resolvedAt = incident.updatedAt;
    }

    this.recordAudit(
      organizationId,
      actorId,
      actorEmail,
      'INCIDENT_STATUS_UPDATED',
      'Incident',
      incident.id,
      { previousStatus, newStatus: status }
    );
    return incident;
  }

  // -------------------------------------------------------------
  // Evidence
  // -------------------------------------------------------------
  public listEvidence(
    organizationId: string,
    incidentId: string
  ): IncidentEvidence[] {
    return Array.from(this.evidence.values())
      .filter(
        (e) =>
          e.organizationId === organizationId && e.incidentId === incidentId
      )
      .sort(
        (a, b) =>
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
  }

  public addEvidence(
    organizationId: string,
    actorId: string,
    actorEmail: string,
    incidentId: string,
    evidenceType: EvidenceType,
    sourceName: string,
    summary: string,
    rawPayload: Record<string, unknown> | Array<unknown> | string
  ): IncidentEvidence | undefined {
    const incident = this.getIncident(organizationId, incidentId);
    if (!incident) return undefined;

    const evidence: IncidentEvidence = {
      id: `evi_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      organizationId,
      incidentId,
      evidenceType,
      sourceName,
      summary,
      rawPayload,
      createdAt: new Date().toISOString(),
    };
    this.evidence.set(evidence.id, evidence);

    this.recordAudit(
      organizationId,
      actorId,
      actorEmail,
      'EVIDENCE_ATTACHED',
      'IncidentEvidence',
      evidence.id,
      { incidentId, evidenceType, sourceName }
    );
    return evidence;
  }

  // -------------------------------------------------------------
  // Investigations
  // -------------------------------------------------------------
  public getInvestigation(
    organizationId: string,
    incidentId: string
  ): InvestigationReport | undefined {
    return Array.from(this.investigations.values()).find(
      (inv) =>
        inv.organizationId === organizationId && inv.incidentId === incidentId
    );
  }

  public saveInvestigation(
    report: InvestigationReport
  ): InvestigationReport {
    this.investigations.set(report.id, report);
    return report;
  }

  // -------------------------------------------------------------
  // Postmortems
  // -------------------------------------------------------------
  public getPostmortem(
    organizationId: string,
    incidentId: string
  ): Postmortem | undefined {
    return Array.from(this.postmortems.values()).find(
      (pm) =>
        pm.organizationId === organizationId && pm.incidentId === incidentId
    );
  }

  public createPostmortem(
    organizationId: string,
    authorId: string,
    authorEmail: string,
    incidentId: string,
    title: string,
    rootCause: string,
    triggerEvent: string,
    resolutionPlaybook: string,
    preventionItems: string[]
  ): Postmortem | undefined {
    const incident = this.getIncident(organizationId, incidentId);
    if (!incident) return undefined;

    const postmortem: Postmortem = {
      id: `pm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      organizationId,
      incidentId,
      authorId,
      title,
      rootCause,
      triggerEvent,
      resolutionPlaybook,
      preventionItems,
      retainedInHindsight: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.postmortems.set(postmortem.id, postmortem);

    // Auto-create pending knowledge approval item
    const approval: KnowledgeApproval = {
      id: `appr_${postmortem.id}`,
      organizationId,
      postmortemId: postmortem.id,
      incidentId,
      incidentTitle: incident.title,
      submittedBy: authorEmail,
      status: 'PENDING',
      createdAt: postmortem.createdAt,
    };
    this.approvals.set(approval.id, approval);

    this.recordAudit(
      organizationId,
      authorId,
      authorEmail,
      'POSTMORTEM_SUBMITTED',
      'Postmortem',
      postmortem.id,
      { incidentId, title }
    );
    return postmortem;
  }

  // -------------------------------------------------------------
  // Knowledge Approval Queue
  // -------------------------------------------------------------
  public listApprovals(organizationId: string): KnowledgeApproval[] {
    return Array.from(this.approvals.values())
      .filter((a) => a.organizationId === organizationId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
  }

  public getApproval(
    organizationId: string,
    id: string
  ): KnowledgeApproval | undefined {
    const item = this.approvals.get(id);
    if (!item || item.organizationId !== organizationId) return undefined;
    return item;
  }

  public updateApproval(
    organizationId: string,
    reviewerId: string,
    reviewerEmail: string,
    approvalId: string,
    status: 'APPROVED' | 'REJECTED',
    reviewNotes?: string
  ): KnowledgeApproval | undefined {
    const approval = this.getApproval(organizationId, approvalId);
    if (!approval) return undefined;

    approval.status = status;
    approval.reviewedBy = reviewerEmail;
    approval.reviewNotes = reviewNotes;
    approval.reviewedAt = new Date().toISOString();

    const postmortem = this.postmortems.get(approval.postmortemId);
    if (postmortem && status === 'APPROVED') {
      postmortem.retainedInHindsight = true;
      postmortem.updatedAt = approval.reviewedAt;
    }

    this.recordAudit(
      organizationId,
      reviewerId,
      reviewerEmail,
      status === 'APPROVED' ? 'POSTMORTEM_APPROVED' : 'POSTMORTEM_REJECTED',
      'KnowledgeApproval',
      approval.id,
      { postmortemId: approval.postmortemId, status, reviewNotes }
    );

    return approval;
  }
}

// Global Singleton Instance
export const store = new SystemOfRecordStore();
