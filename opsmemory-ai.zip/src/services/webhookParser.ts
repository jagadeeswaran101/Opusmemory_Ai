/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { IncidentSeverity } from '../types/index.ts';

export interface NormalizedAlert {
  title: string;
  summary: string;
  severity: IncidentSeverity;
  service: string;
  source: string;
  rawPayload: any;
}

export function parseAlertWebhook(payload: any): NormalizedAlert {
  if (!payload || typeof payload !== 'object') {
    return {
      title: 'Unknown Alert Ingestion',
      summary: 'Alert received with empty or non-object payload.',
      severity: 'SEV-3',
      service: 'infrastructure-general',
      source: 'unknown',
      rawPayload: payload || {},
    };
  }

  // 1. PagerDuty Events API v2 / v3
  if (payload.event_action || (payload.event && payload.event.data)) {
    const pdPayload = payload.payload || payload.event?.data || {};
    const summary = pdPayload.summary || pdPayload.title || 'PagerDuty Triggered Alert';
    const rawSev = (pdPayload.severity || pdPayload.urgency || 'critical').toString().toLowerCase();
    const serviceName =
      pdPayload.source ||
      payload.event?.data?.service?.summary ||
      pdPayload.custom_details?.service ||
      'core-service';

    return {
      title: summary.slice(0, 120),
      summary: pdPayload.custom_details?.description || summary,
      severity: mapSeverity(rawSev),
      service: sanitizeServiceName(serviceName),
      source: 'pagerduty',
      rawPayload: payload,
    };
  }

  // 2. Datadog Webhook
  if (payload.event_type || payload.date_happened || payload.priority || (payload.tags && Array.isArray(payload.tags))) {
    const title = payload.title || payload.event_title || 'Datadog Monitor Alert';
    const body = payload.body || payload.text || 'Datadog monitor triggered an anomaly alert threshold.';
    const rawSev = payload.priority || (payload.alert_type === 'error' ? 'critical' : 'warning');
    
    // Extract service from tags if available (e.g. "service:payments-db")
    let serviceName = 'datadog-monitored-service';
    if (Array.isArray(payload.tags)) {
      const svcTag = payload.tags.find((t: string) => t.startsWith('service:'));
      if (svcTag) {
        serviceName = svcTag.replace('service:', '').trim();
      }
    }

    return {
      title: title.slice(0, 120),
      summary: body,
      severity: mapSeverity(rawSev),
      service: sanitizeServiceName(serviceName),
      source: 'datadog',
      rawPayload: payload,
    };
  }

  // 3. Prometheus / Alertmanager
  if (Array.isArray(payload.alerts) && payload.alerts.length > 0) {
    const firstAlert = payload.alerts[0];
    const labels = firstAlert.labels || {};
    const annotations = firstAlert.annotations || {};
    const title = annotations.summary || annotations.title || labels.alertname || 'Prometheus Metric Alert';
    const summary = annotations.description || annotations.message || `Prometheus alert ${labels.alertname || ''} is firing.`;
    const rawSev = labels.severity || payload.commonLabels?.severity || 'critical';
    const serviceName = labels.service || labels.job || labels.instance || 'kubernetes-cluster';

    return {
      title: title.slice(0, 120),
      summary,
      severity: mapSeverity(rawSev),
      service: sanitizeServiceName(serviceName),
      source: 'prometheus-alertmanager',
      rawPayload: payload,
    };
  }

  // 4. Generic OpsMemory / OpenTelemetry payload
  const title = payload.title || payload.alertName || 'External Automated Infrastructure Alert';
  const summary = payload.summary || payload.description || payload.message || 'Alert received from external webhook pipeline.';
  const rawSev = payload.severity || payload.level || 'SEV-2';
  const serviceName = payload.service || payload.serviceName || payload.component || 'platform-service';

  return {
    title: title.slice(0, 120),
    summary,
    severity: mapSeverity(rawSev),
    service: sanitizeServiceName(serviceName),
    source: payload.source || 'external-webhook',
    rawPayload: payload,
  };
}

export function parseChatOpsCommand(text: string): {
  action: 'recall' | 'status' | 'investigate' | 'help';
  arg: string;
} {
  const trimmed = (text || '').trim();
  if (!trimmed || trimmed === 'help') {
    return { action: 'help', arg: '' };
  }

  const parts = trimmed.split(/\s+/);
  const firstWord = parts[0].toLowerCase();
  const rest = parts.slice(1).join(' ');

  if (firstWord === 'recall' || firstWord === 'memory' || firstWord === 'search') {
    return { action: 'recall', arg: rest };
  }

  if (firstWord === 'status' || firstWord === 'health' || firstWord === 'overview') {
    return { action: 'status', arg: rest };
  }

  if (firstWord === 'investigate' || firstWord === 'analyze' || firstWord === 'triage') {
    return { action: 'investigate', arg: rest };
  }

  // Default: if users just type symptoms like "/opsmemory hikari pool connection limit"
  return { action: 'recall', arg: trimmed };
}

function mapSeverity(input: string): IncidentSeverity {
  const s = input.toLowerCase();
  if (s.includes('1') || s.includes('crit') || s.includes('emerg') || s.includes('fatal') || s.includes('p1')) {
    return 'SEV-1';
  }
  if (s.includes('2') || s.includes('err') || s.includes('high') || s.includes('p2')) {
    return 'SEV-2';
  }
  if (s.includes('3') || s.includes('warn') || s.includes('med') || s.includes('p3')) {
    return 'SEV-3';
  }
  return 'SEV-4';
}

function sanitizeServiceName(name: string): string {
  return name.replace(/[^a-zA-Z0-9_-]/g, '-').toLowerCase();
}
