/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { parseAlertWebhook, parseChatOpsCommand } from './webhookParser.ts';

test('Webhook Parser: PagerDuty Event API v2 / v3 payload', () => {
  const pdPayload = {
    event_action: 'trigger',
    routing_key: 'sample-routing-key',
    payload: {
      summary: 'PostgreSQL Active Connections Exceeded 95% on Payments Cluster',
      severity: 'critical',
      source: 'payments-db',
      custom_details: {
        description: 'Remaining connection slots reserved for superuser (SQLSTATE 53300).',
        pool_capacity: 100,
        active: 98,
      },
    },
  };

  const alert = parseAlertWebhook(pdPayload);
  assert.equal(alert.source, 'pagerduty');
  assert.equal(alert.severity, 'SEV-1');
  assert.equal(alert.service, 'payments-db');
  assert.match(alert.title, /PostgreSQL Active Connections/);
  assert.match(alert.summary, /53300/);
});

test('Webhook Parser: Datadog Monitor Alert with Tags', () => {
  const ddPayload = {
    event_type: 'anomaly_monitor',
    title: '[Triggered] High CPU and Redis Cache Evictions in worker cluster',
    body: 'Redis memory limit reached 99.4% with evictions spiking to 4,200 keys/sec.',
    priority: 'high',
    tags: ['env:production', 'service:redis-cache', 'team:platform'],
  };

  const alert = parseAlertWebhook(ddPayload);
  assert.equal(alert.source, 'datadog');
  assert.equal(alert.severity, 'SEV-2');
  assert.equal(alert.service, 'redis-cache');
  assert.match(alert.summary, /evictions spiking/);
});

test('Webhook Parser: Prometheus Alertmanager alerts array', () => {
  const promPayload = {
    receiver: 'opsmemory-webhook',
    status: 'firing',
    alerts: [
      {
        status: 'firing',
        labels: {
          alertname: 'KubePodOOMKilled',
          severity: 'critical',
          service: 'checkout-api',
          namespace: 'production',
        },
        annotations: {
          summary: 'Kubernetes Container OOMKilled in checkout-api pod',
          description: 'Pod checkout-api-79b terminated with exit code 137 (OOMKilled). Memory limit exceeded.',
        },
      },
    ],
  };

  const alert = parseAlertWebhook(promPayload);
  assert.equal(alert.source, 'prometheus-alertmanager');
  assert.equal(alert.severity, 'SEV-1');
  assert.equal(alert.service, 'checkout-api');
  assert.match(alert.title, /Kubernetes Container OOMKilled/);
  assert.match(alert.summary, /exit code 137/);
});

test('Webhook Parser: Generic OpenTelemetry or OpsMemory payload', () => {
  const generic = {
    title: 'Kafka Consumer Group Lag Exceeded Threshold',
    summary: 'Consumer group analytics-lag exceeds 50,000 messages.',
    severity: 'SEV-3',
    service: 'kafka-eventbus',
    source: 'otel-collector',
  };

  const alert = parseAlertWebhook(generic);
  assert.equal(alert.source, 'otel-collector');
  assert.equal(alert.severity, 'SEV-3');
  assert.equal(alert.service, 'kafka-eventbus');
});

test('ChatOps Command Parser: slash commands', () => {
  const cmd1 = parseChatOpsCommand('recall hikari pool connection leak');
  assert.equal(cmd1.action, 'recall');
  assert.equal(cmd1.arg, 'hikari pool connection leak');

  const cmd2 = parseChatOpsCommand('status');
  assert.equal(cmd2.action, 'status');

  const cmd3 = parseChatOpsCommand('investigate 142');
  assert.equal(cmd3.action, 'investigate');
  assert.equal(cmd3.arg, '142');

  const cmd4 = parseChatOpsCommand('');
  assert.equal(cmd4.action, 'help');

  const cmd5 = parseChatOpsCommand('unknown text query without command prefix');
  assert.equal(cmd5.action, 'recall');
  assert.equal(cmd5.arg, 'unknown text query without command prefix');
});
