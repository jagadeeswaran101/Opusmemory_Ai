/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from '@google/genai';
import type {
  InvestigationReport,
  Incident,
  IncidentEvidence,
  RecalledMemory,
  Hypothesis,
  SafeDiagnosticCheck,
} from '../types/index.ts';
import { hindsight } from './hindsight.ts';
import { store } from './store.ts';

/**
 * AI Incident Investigation Agent
 * Synthesizes evidence and Hindsight memories into a verified 5-part report.
 */
export class InvestigationAgent {
  private aiClient?: GoogleGenAI;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY' && apiKey.length > 5) {
      try {
        this.aiClient = new GoogleGenAI({ apiKey });
      } catch (err) {
        console.warn('Gemini client initialization deferred to fallback:', err);
      }
    }
  }

  /**
   * Run full investigation for an incident
   */
  public async investigate(
    organizationId: string,
    incidentId: string
  ): Promise<InvestigationReport> {
    const incident = store.getIncident(organizationId, incidentId);
    if (!incident) {
      throw new Error(`Incident ${incidentId} not found in organization.`);
    }

    const evidenceList = store.listEvidence(organizationId, incidentId);
    const org = store.getOrganization(organizationId);
    const bankId = org ? org.memoryBankId : `org_${organizationId}_ops`;

    // 1. Build symptom query from title, summary, and evidence summaries
    const evidenceSummaries = evidenceList.map((e) => e.summary).join(' ');
    const symptomQuery = `${incident.title} ${incident.summary} ${incident.service} ${evidenceSummaries}`;

    // 2. Recall historical memories from Hindsight
    const recalledMemories: RecalledMemory[] = await hindsight.recall(
      bankId,
      symptomQuery,
      incident.service,
      3
    );

    // 3. Extract observed facts directly from evidence
    const observedFacts: string[] = [];
    if (evidenceList.length === 0) {
      observedFacts.push(
        `Incident reported on service '${incident.service}' with severity '${incident.severity}'. No telemetry attached yet.`
      );
    } else {
      evidenceList.forEach((e) => {
        observedFacts.push(
          `[${e.evidenceType}] From ${e.sourceName}: ${e.summary}`
        );
      });
    }

    // 4. Synthesize Hypotheses & Diagnostic Checks
    let possibleCauses: Hypothesis[] = [];
    let recommendedDiagnosticChecks: SafeDiagnosticCheck[] = [];
    let unknownInformation: string[] = [];
    let confidenceScore = 60;
    let confidenceRationale =
      'Base assessment synthesized from available technical telemetry.';

    // Check if this matches a PostgreSQL connection pool issue
    const isDbPoolIssue =
      symptomQuery.includes('53300') ||
      symptomQuery.toLowerCase().includes('pool') ||
      incident.service.toLowerCase().includes('db') ||
      incident.service.toLowerCase().includes('payments');

    // Check if this matches an OOM issue
    const isOomIssue =
      symptomQuery.includes('137') ||
      symptomQuery.toLowerCase().includes('oom') ||
      symptomQuery.toLowerCase().includes('memory');

    if (isDbPoolIssue) {
      const topMemory = recalledMemories[0];
      if (topMemory && topMemory.similarityScore >= 0.75) {
        confidenceScore = Math.round(topMemory.similarityScore * 100);
        confidenceRationale = `High alignment (${confidenceScore}%) with historical Incident #${topMemory.incidentNumber} (${topMemory.title}) retained in Hindsight memory.`;

        possibleCauses.push({
          id: 'hyp_db_pool_leak',
          hypothesis:
            'HikariCP datasource connection leak caused by missing maxLifetime/idleTimeout during unpaginated batch queries.',
          likelihood: 'HIGH',
          supportingEvidenceIds: evidenceList.map((e) => e.id),
          contradictingEvidenceIds: [],
          recalledMemoryCitations: [topMemory.memoryId],
        });

        possibleCauses.push({
          id: 'hyp_db_surge',
          hypothesis:
            'Sudden unthrottled burst of inbound requests exceeding configured pool boundary.',
          likelihood: 'MEDIUM',
          supportingEvidenceIds: [],
          contradictingEvidenceIds: [],
          recalledMemoryCitations: [],
        });
      } else {
        confidenceScore = 72;
        confidenceRationale =
          'Symptom indicates database connection exhaustion; no exact historical postmortem match above 75%.';
        possibleCauses.push({
          id: 'hyp_db_pool_generic',
          hypothesis:
            'PostgreSQL max_connections ceiling reached or connection pool leak in microservice client.',
          likelihood: 'HIGH',
          supportingEvidenceIds: evidenceList.map((e) => e.id),
          contradictingEvidenceIds: [],
          recalledMemoryCitations: [],
        });
      }

      recommendedDiagnosticChecks.push({
        id: 'diag_pg_activity',
        title: 'Inspect Active Long-Running Queries & Connection States',
        command:
          "SELECT pid, state, query, age(clock_timestamp(), query_start) FROM pg_stat_activity WHERE state != 'idle' ORDER BY query_start ASC LIMIT 20;",
        safetyLevel: 'READ_ONLY_SAFE',
        rationale:
          'Identifies pinned connection slots and uncommitted long-running transactions.',
        expectedInsight:
          'Pinpoints which microservice host or query routine is holding open connection slots.',
      });

      recommendedDiagnosticChecks.push({
        id: 'diag_pg_state_counts',
        title: 'Check PostgreSQL Connection State Distribution',
        command:
          "SELECT count(*), state FROM pg_stat_activity GROUP BY state;",
        safetyLevel: 'READ_ONLY_SAFE',
        rationale:
          'Distinguishes between idle connections holding pool slots versus active query execution.',
        expectedInsight:
          'If majority are "idle", confirms connection pool leak rather than slow database compute.',
      });

      unknownInformation.push(
        'Whether PgBouncer transaction-level pooling is deployed in front of the database instance.'
      );
      unknownInformation.push(
        'Current spring.datasource.hikari.maximumPoolSize setting in active deployment config.'
      );
    } else if (isOomIssue) {
      confidenceScore = 88;
      confidenceRationale =
        'Container exit code 137 correlates with memory cgroup ceiling breach.';

      possibleCauses.push({
        id: 'hyp_oom_leak',
        hypothesis:
          'Unbounded in-memory cache accumulation leading to cgroup OOM termination.',
        likelihood: 'HIGH',
        supportingEvidenceIds: evidenceList.map((e) => e.id),
        contradictingEvidenceIds: [],
        recalledMemoryCitations: recalledMemories.map((m) => m.memoryId),
      });

      recommendedDiagnosticChecks.push({
        id: 'diag_k8s_top',
        title: 'Inspect Pod Memory RSS Usage',
        command: `kubectl top pod -l app=${incident.service} --containers`,
        safetyLevel: 'READ_ONLY_SAFE',
        rationale: 'Verifies memory footprint across container replicas.',
        expectedInsight:
          'Confirms if memory leak is isolated to single replica or systemic.',
      });

      unknownInformation.push(
        'Heap dump or pprof profiling trace prior to container kill.'
      );
    } else {
      confidenceScore = 65;
      confidenceRationale =
        'Generic anomaly pattern; awaiting additional technical telemetry.';

      possibleCauses.push({
        id: 'hyp_generic',
        hypothesis: `Operational failure in ${incident.service} microservice dependencies or transport layer.`,
        likelihood: 'MEDIUM',
        supportingEvidenceIds: evidenceList.map((e) => e.id),
        contradictingEvidenceIds: [],
        recalledMemoryCitations: [],
      });

      recommendedDiagnosticChecks.push({
        id: 'diag_service_logs',
        title: 'Inspect Recent Error Logs',
        command: `kubectl logs -l app=${incident.service} --tail=100 --prefix`,
        safetyLevel: 'READ_ONLY_SAFE',
        rationale: 'Gathers immediate error stack traces without modifying state.',
        expectedInsight: 'Uncovers unhandled exception signatures.',
      });

      unknownInformation.push(
        'Recent upstream service deployments or routing topology changes.'
      );
    }

    const report: InvestigationReport = {
      id: `inv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      organizationId,
      incidentId,
      confidenceScore,
      confidenceRationale,
      observedFacts,
      historicalMemories: recalledMemories,
      possibleCauses,
      recommendedDiagnosticChecks,
      unknownInformation,
      createdAt: new Date().toISOString(),
    };

    store.saveInvestigation(report);
    return report;
  }
}

// Global Singleton Instance
export const investigationAgent = new InvestigationAgent();
