/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { SystemOfRecordStore } from './store.ts';
import { HindsightMemoryEngine } from './hindsight.ts';
import { InvestigationAgent } from './investigation.ts';

test('OpsMemory AI Core Engine & Hindsight Memory Suite', async (t) => {
  // Fresh instances for clean-room testing
  const store = new SystemOfRecordStore();
  const hindsight = new HindsightMemoryEngine();
  const org = store.getOrganization('org_acme_prod');
  assert.ok(org, 'Default organization must exist');

  await t.test('Retain: approved postmortem commits to Hindsight memory bank', async () => {
    const postmortemDoc = {
      title: 'Redis WRONGTYPE Operation against Session Key',
      incidentNumber: 104,
      sourceIncidentId: 'inc_104_redis',
      service: 'session-cache',
      severity: 'SEV-2',
      symptoms: [
        'WRONGTYPE Operation against a key holding the wrong kind of value',
        'User logins failing with 500 internal server error',
      ],
      rootCause:
        'Key naming collision where session-cache and auth-service wrote different data structures to user:session:active.',
      resolutionPlaybook:
        'Namespaced all Redis keys with service prefix (auth:session:v2:). Flushed corrupted keys.',
      diagnosticChecksVerified: ['redis-cli TYPE user:session:active'],
      preventionMeasures: ['Enforce Redis key schema validation in CI.'],
    };

    const { memoryId, retainedAt } = await hindsight.retain(
      org.memoryBankId,
      postmortemDoc,
      'elena.rostova@acme.internal'
    );

    assert.ok(memoryId.startsWith('mem_session_cache_'), 'Must generate memoryId with service prefix');
    assert.ok(retainedAt, 'Must have retainedAt timestamp');

    const stats = hindsight.getBankStats(org.memoryBankId, org.id);
    assert.ok(stats.totalMemories >= 3, 'Bank memories count must increment');
  });

  await t.test('Recall: querying incident symptoms returns relevant historical memory', async () => {
    const memories = await hindsight.recall(
      org.memoryBankId,
      'PostgreSQL connection pool maxed out error 53300',
      'payments-db',
      2
    );

    assert.ok(memories.length > 0, 'Must recall matching memory');
    const top = memories[0];
    assert.equal(top.incidentNumber, 89, 'Should match Incident #89 (HikariCP leak)');
    assert.ok(top.similarityScore >= 0.8, 'Similarity score should be high for matching symptoms');
    assert.ok(top.rootCause.includes('HikariCP'), 'Root cause must cite HikariCP');
    assert.ok(top.resolutionPlaybook.includes('maxLifetime'), 'Playbook must include maxLifetime fix');
  });

  await t.test('Two-Incident E2E Journey: Incident 1 resolution directly informs Incident 2 investigation', async () => {
    // Step 1: Create Incident 1 (PostgreSQL Connection Pool Exhaustion)
    const inc1 = store.createIncident(
      org.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      'Checkout DB Connection Pool Exhaustion',
      'Checkout service latency spiking, active connections 100/100',
      'SEV-1',
      'checkout-db'
    );

    store.addEvidence(
      org.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      inc1.id,
      'LOG_SNIPPET',
      'checkout-pod-01',
      'FATAL: remaining connection slots are reserved (SQLSTATE 53300)',
      { active: 100, max: 100 }
    );

    // Step 2: Resolve Incident 1 and Author Postmortem
    store.updateIncidentStatus(
      org.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      inc1.id,
      'RESOLVED'
    );

    const pm = store.createPostmortem(
      org.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      inc1.id,
      'Checkout DB Pool Exhaustion Resolution',
      'Missing idleTimeout on HikariCP datasource under checkout surge.',
      'Black Friday checkout spike with unpaginated cart queries.',
      'Set spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000.',
      ['Add pool saturation alerts.']
    );
    assert.ok(pm, 'Postmortem must be created');

    // Step 3: Approve Postmortem in Approval Queue
    const approvals = store.listApprovals(org.id);
    const approval = approvals.find((a) => a.postmortemId === pm.id);
    assert.ok(approval, 'Approval item must exist in queue');

    store.updateApproval(
      org.id,
      'usr_elena',
      'elena.rostova@acme.internal',
      approval.id,
      'APPROVED',
      'Verified in staging; approved for institutional memory retention.'
    );

    // Step 4: Retain into Hindsight
    const { memoryId } = await hindsight.retain(
      org.memoryBankId,
      {
        title: pm.title,
        incidentNumber: inc1.incidentNumber,
        sourceIncidentId: inc1.id,
        service: inc1.service,
        severity: inc1.severity,
        symptoms: ['error 53300', 'pool exhausted 100/100', 'checkout surge'],
        rootCause: pm.rootCause,
        resolutionPlaybook: pm.resolutionPlaybook,
        diagnosticChecksVerified: ['SELECT * FROM pg_stat_activity'],
        preventionMeasures: pm.preventionItems,
      },
      'elena.rostova@acme.internal'
    );
    assert.ok(memoryId, 'Memory ID returned from retention');

    // Step 5: Incident 2 occurs 2 weeks later on similar service
    const inc2 = store.createIncident(
      org.id,
      'usr_marcus',
      'marcus.vance@acme.internal',
      'Checkout Service DB Connection Pool Saturation',
      'Active connections at 100/100 with error 53300 after flash sale',
      'SEV-1',
      'checkout-db'
    );

    // Step 6: Recall memories for Incident 2
    const recalledForInc2 = await hindsight.recall(
      org.memoryBankId,
      `${inc2.title} ${inc2.summary} 53300 pool`,
      inc2.service,
      5
    );

    // Diagnostic log
    // console.log('recalledForInc2:', recalledForInc2.map(m => ({ num: m.incidentNumber, title: m.title, score: m.similarityScore })));

    assert.ok(recalledForInc2.length > 0, 'Incident 2 must recall historical memories');
    const matchedInc1 = recalledForInc2.find(
      (m) => m.incidentNumber === inc1.incidentNumber || m.sourceIncidentId === inc1.id
    );
    assert.ok(matchedInc1, `Incident 2 must specifically recall Incident 1 memory (inc1: ${inc1.incidentNumber}, got: ${JSON.stringify(recalledForInc2.map(m => m.incidentNumber))})`);
    assert.equal(
      matchedInc1.resolutionPlaybook,
      'Set spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000.'
    );
  });

  await t.test('Tenant Isolation: Tenant B cannot recall or query memories belonging to Tenant A', async () => {
    const orgBeta = store.createOrganization('Beta Corp', 'beta-corp');

    // Attempt to recall from Beta Corp memory bank
    const memoriesInBeta = await hindsight.recall(
      orgBeta.memoryBankId,
      'PostgreSQL connection pool maxed out error 53300',
      'payments-db',
      5
    );

    // Org Beta must have 0 memories (isolated from Acme Corp)
    assert.equal(
      memoriesInBeta.length,
      0,
      'Tenant B must never recall memories belonging to Tenant A'
    );

    // Verify incident listing isolation
    const acmeIncidents = store.listIncidents(org.id);
    const betaIncidents = store.listIncidents(orgBeta.id);
    assert.ok(acmeIncidents.length > 0, 'Acme has incidents');
    assert.equal(betaIncidents.length, 0, 'Beta Corp has zero incidents');
  });

  await t.test('Epistemological Separation: AI investigation separates facts, memories, hypotheses, safe checks, and unknowns', async () => {
    const inc = store.getIncident(org.id, 'inc_142_payments_db');
    assert.ok(inc, 'Incident #142 must exist');

    // Run investigation agent
    const agent = new InvestigationAgent();
    const report = await agent.investigate(org.id, inc.id);

    // Assert 5-part separation contract
    assert.ok(Array.isArray(report.observedFacts), 'observedFacts must be an array');
    assert.ok(report.observedFacts.length >= 2, 'observedFacts must have items from evidence');
    assert.ok(Array.isArray(report.historicalMemories), 'historicalMemories must be an array');
    assert.ok(report.historicalMemories.length >= 1, 'historicalMemories must recall Incident #89');
    assert.ok(Array.isArray(report.possibleCauses), 'possibleCauses must be an array');
    assert.ok(report.possibleCauses.length >= 1, 'possibleCauses must have hypotheses');
    assert.ok(Array.isArray(report.recommendedDiagnosticChecks), 'recommendedDiagnosticChecks must be an array');
    assert.ok(report.recommendedDiagnosticChecks.length >= 1, 'recommendedDiagnosticChecks must be safe read-only');
    assert.ok(Array.isArray(report.unknownInformation), 'unknownInformation must be an array');

    // Assert safe diagnostic checks do not contain destructive commands
    report.recommendedDiagnosticChecks.forEach((check) => {
      assert.equal(check.safetyLevel, 'READ_ONLY_SAFE', 'Commands must be marked safe');
      assert.doesNotMatch(check.command, /DROP|DELETE|TRUNCATE|rm -rf|kill -9/i, 'No destructive commands');
    });
  });

  await t.test('Audit Service: records immutable audit events with actor and timestamp', () => {
    const logs = store.getAuditLogs(org.id);
    assert.ok(logs.length >= 2, 'Audit logs must be populated');
    const first = logs[0];
    assert.ok(first.id.startsWith('aud_'), 'Audit log must have aud_ prefix');
    assert.ok(first.userEmail, 'Audit log must record actor userEmail');
    assert.ok(first.action, 'Audit log must record action');
    assert.ok(first.createdAt, 'Audit log must have ISO timestamp');
  });
});
