# Quality Assurance & Test Strategy

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 10 — Testing & Quality Assurance  
**Status:** VERIFIED  

---

## 1. Testing Pyramid

- **Layer 1: Deterministic Pure Logic Unit Tests (`node:test`)**
  - Fast execution (< 50ms) using Node.js built-in test runner via `npx --yes tsx --test`.
  - Verifies: Memory retention, memory recall, two-incident critical flow, tenant boundary isolation, hypothesis scoring, and audit trail immutability.
- **Layer 2: REST API Integration Tests**
  - Verifies Express endpoint contracts, authentication guards, status transitions, and error serialization.
- **Layer 3: End-to-End Two-Incident Journey Verification**
  - Complete verification of the critical scenario: Incident 1 (PostgreSQL pool exhaustion) → Investigate → Resolve → Approve Postmortem → Retain in Hindsight → Incident 2 (Similar symptoms) → Recalls Incident 1 with source reference and recommended fix.
- **Layer 4: Browser Automation & Accessibility Verification**
  - Executed via `playwright-cli` for UI rendering, tab navigation, interactive dual-incident simulator, and responsive inspection.
