# End-to-End Two-Incident Verification Scenario

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 10 — Testing & Quality Assurance  
**Status:** VERIFIED  

---

## 1. Critical Two-Incident Verification Narrative

### Incident 1 (The Initial Crisis)
1. **Creation:** SRE creates Incident #142: *"PostgreSQL Connection Pool Exhaustion on Payments DB"*.
2. **Evidence:** Logs show `FATAL: remaining connection slots are reserved (error 53300)`. Metrics series shows active connections pegged at 100/100.
3. **Investigation:** Agent investigates without historical precedent. Confidence is moderate (65%). Safe diagnostic checks recommended (`SELECT * FROM pg_stat_activity`).
4. **Resolution:** SRE discovers unclosed connections in batch routine, modifies HikariCP `maxLifetime=1800000` & `idleTimeout=600000`, and marks incident `RESOLVED`.
5. **Postmortem & Approval:** SRE writes postmortem. Operations Admin Elena Rostova reviews and approves it in the Knowledge Approval Queue.
6. **Hindsight Retain:** System calls Hindsight `retain()`, storing memory `mem_pg_pool_0814` with key symptoms and verified fix playbook.

### Incident 2 (The Repeat Outage — Memory in Action)
1. **Creation:** Two weeks later, a new alert fires on checkout service: Incident #158 *"Checkout DB pool saturated with error 53300"*.
2. **Evidence:** Similar log error and connection plateau.
3. **Investigation:** SRE triggers AI Investigation.
4. **Hindsight Recall:** The agent calls `recall()` and retrieves `mem_pg_pool_0814` with a **94% similarity score**.
5. **Epistemological Output:**
   - **Observed Facts:** Error 53300, 100 connections active.
   - **Historical Memories:** Incident #142 HikariCP leak.
   - **Possible Causes:** High likelihood missing pool lifetime configuration matching Incident #142.
   - **Recommended Safe Checks:** Check `pg_stat_activity` state and Hikari datasource properties.
   - **Resolution Accelerant:** SRE immediately applies the verified playbook from Incident #142, resolving the incident in under 4 minutes.
