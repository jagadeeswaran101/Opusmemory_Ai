# Test Cases Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 10 — Testing & Quality Assurance  
**Status:** VERIFIED  

---

## 1. Unit & Integration Test Case Suite

| Case ID | Category | Description | Input Condition | Expected Output | Status |
|---|---|---|---|---|---|
| **TC-01** | Hindsight Retain | Retaining approved postmortem stores in memory bank | Valid approved postmortem | Returns valid memoryId and records bank commitment | VERIFIED |
| **TC-02** | Hindsight Recall | Recalls matching memory on similar incident symptoms | Symptom vector matching error 53300 | Returns Incident #89 memory with score >= 0.85 | VERIFIED |
| **TC-03** | Two-Incident E2E | Critical lifecycle from Incident 1 to Incident 2 | Incident 1 resolved, then Incident 2 investigated | Incident 2 explicitly cites Incident 1 as primary historical memory | VERIFIED |
| **TC-04** | Tenant Isolation | Querying bank of different organization | Tenant B query to Tenant A | Zero matches returned; isolation maintained | VERIFIED |
| **TC-05** | Epistemological Separation | AI Investigation output formatting | Attached evidence items | Output strictly separates facts, memories, causes, checks, and unknowns | VERIFIED |
| **TC-06** | Audit Trail | Auditing state transitions and memory commits | Incident resolution & approval | Immutable audit log records actor, action, and target ID | VERIFIED |
