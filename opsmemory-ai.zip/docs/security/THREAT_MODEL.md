# Threat Model (STRIDE Methodology)

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 9 — Security, Privacy & Reliability  
**Status:** VERIFIED  

---

## 1. Threat Matrix

| Threat Category | Potential Attack Vector | OpsMemory AI Defense |
|---|---|---|
| **Spoofing** | Attacker fakes authorization token or impersonates admin | Cryptographic session tokens, strict role verification, token expiry |
| **Tampering** | Modifying postmortem approval logs or historical memories | PostgreSQL append-only audit trail, SHA-256 payload integrity hashing |
| **Repudiation** | User denies approving a flawed postmortem into Hindsight | Immutable audit log capturing user ID, timestamp, IP, and approval diff |
| **Information Disclosure** | Cross-tenant memory recall leaking Incident data from Org B to Org A | Hard-isolated bank IDs (`org_{orgId}_ops`), API tenant guard middleware |
| **Denial of Service** | Malicious burst of large log uploads or continuous AI investigation loops | Payload size limits (1MB/log), rate-limiting middleware, request queue caps |
| **Elevation of Privilege** | Responder attempting to approve postmortems or alter org settings | RBAC policy middleware checking explicit role capabilities |
