# Production Troubleshooting Runbook

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Top Diagnostic Procedures

### Triage 1: Verify PostgreSQL Connection Pool
```bash
# Check active connections
psql -h $DB_HOST -U $DB_USER -d opsmemory -c "SELECT count(*), state FROM pg_stat_activity GROUP BY state;"
```

### Triage 2: Health & Hindsight Engine Ping
```bash
curl -i http://localhost:3000/api/health
# Response should indicate: { "status": "UP", "database": "CONNECTED", "memoryEngine": "OPERATIONAL" }
```

### Triage 3: Re-index Memory Bank from PostgreSQL Postmortems
If the external Hindsight vector volume is rebuilt from scratch, run the admin re-indexing job:
```bash
node -e "require('./src/services/hindsight').reindexOrgBank('org_default_01')"
```
