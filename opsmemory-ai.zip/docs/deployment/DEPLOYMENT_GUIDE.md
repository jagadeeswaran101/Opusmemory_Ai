# Production Deployment Guide

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Cloud Run / Kubernetes Deployment Steps

1. **Build Container Image:**
   ```bash
   gcloud builds submit --tag gcr.io/opsmemory-prod/opsmemory-app:0.1.0
   ```
2. **Deploy to Cloud Run:**
   ```bash
   gcloud run deploy opsmemory-app \
     --image gcr.io/opsmemory-prod/opsmemory-app:0.1.0 \
     --platform managed \
     --region us-central1 \
     --allow-unauthenticated \
     --set-env-vars="NODE_ENV=production" \
     --set-secrets="GEMINI_API_KEY=opsmemory-gemini-key:latest"
   ```
3. **Verify Health:**
   ```bash
   curl -f https://opsmemory.yourdomain.com/api/health
   ```
