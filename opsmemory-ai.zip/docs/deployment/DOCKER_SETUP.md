# Docker & Docker Compose Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Dockerfile (Multi-Stage Production Build)

```dockerfile
FROM node:22-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:22-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV PORT=3000
COPY package*.json ./
RUN npm ci --only=production
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/server.ts ./
COPY --from=builder /app/src ./src
COPY --from=builder /app/tsconfig.json ./
EXPOSE 3000
CMD ["node", "--loader", "tsx", "server.ts"]
```

---

## 2. Docker Compose (`docker-compose.yml`)

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://opsuser:opspass@postgres:5432/opsmemory
      - HINDSIGHT_ENDPOINT=http://hindsight:8080
      - GEMINI_API_KEY=${GEMINI_API_KEY}
    depends_on:
      - postgres
      - hindsight

  postgres:
    image: postgres:16-alpine
    environment:
      - POSTGRES_USER=opsuser
      - POSTGRES_PASSWORD=opspass
      - POSTGRES_DB=opsmemory
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  hindsight:
    image: vectorize/hindsight:latest
    ports:
      - "8080:8080"
    volumes:
      - hindsight_data:/data

volumes:
  pgdata:
  hindsight_data:
```
