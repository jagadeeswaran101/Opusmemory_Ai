# Environment Variables Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Variable Directory

| Variable Name | Required | Default | Description |
|---|---|---|---|
| `PORT` | No | `3000` | Port for the Express full-stack HTTP server |
| `NODE_ENV` | No | `development` | Runtime environment (`development`, `production`, `test`) |
| `GEMINI_API_KEY` | Yes (for live AI) | None | Google Gemini API key for real-time investigation reasoning |
| `HINDSIGHT_ENDPOINT`| No | `http://localhost:8080` | URL of external Hindsight cognitive memory cluster |
| `HINDSIGHT_API_KEY` | No | None | Optional bearer token for secure Hindsight instances |
| `DATABASE_URL` | No | In-Memory SOR | PostgreSQL connection string |
| `SESSION_SECRET` | No | `opsmemory_sec_dev` | Secret for cryptographic token hashing |
| `APP_URL` | No | `http://localhost:3000` | Canonical public URL of the application instance |
