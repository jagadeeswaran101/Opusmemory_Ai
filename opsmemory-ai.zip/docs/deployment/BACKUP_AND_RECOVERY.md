# Backup, Recovery & Operational Troubleshooting

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Backup Schedule & RPO/RTO

- **PostgreSQL Database:** Continuous WAL archiving to cloud storage. Daily full snapshots.
  - RPO: `< 5 minutes`
  - RTO: `< 15 minutes`
- **Hindsight Memory Graphs:** Daily snapshot of persistent vector volume. In the event of catastrophic volume loss, memory banks can be re-indexed directly from approved postmortems in PostgreSQL.

---

## 2. Troubleshooting Runbook

1. **Hindsight Connection Timeout:**
   - *Symptom:* Logs report `Hindsight circuit breaker opened`.
   - *Action:* System automatically falls back to in-memory resilient cognitive bank. Check Hindsight service cluster health and network connectivity.
2. **Missing Historical Recall on Incident Triage:**
   - *Symptom:* Expected past postmortem not appearing in investigation panel.
   - *Action:* Verify that the postmortem was explicitly approved in the Knowledge Approval Queue. Unapproved drafts are never retained in Hindsight.
3. **Cross-Tenant Access Denial (403):**
   - *Symptom:* User receiving unauthorized access error.
   - *Action:* Verify caller's organization ID matches target incident tenant.
