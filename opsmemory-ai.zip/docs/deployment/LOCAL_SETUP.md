# Local Development & Quickstart Guide

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 11 — Deployment & Production Readiness  
**Status:** VERIFIED  

---

## 1. Prerequisites

- Node.js 22 LTS or newer
- npm v10+ or yarn
- Optional: Running Hindsight memory engine instance (`http://localhost:8080`)
- Optional: PostgreSQL 16 (`postgresql://postgres:postgres@localhost:5432/opsmemory`)

---

## 2. Installation & Running

```bash
# 1. Clone repository and install dependencies
git clone https://github.com/opsmemory/opsmemory-ai.git
cd opsmemory-ai
npm install

# 2. Configure Environment
cp .env.example .env
# Edit .env with your GEMINI_API_KEY if testing live cloud LLM reasoning

# 3. Run Automated Logic Tests
npm run test

# 4. Start Full-Stack Development Server
npm run dev
# The application starts on http://localhost:3000
```
