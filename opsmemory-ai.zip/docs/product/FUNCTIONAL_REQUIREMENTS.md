# Functional Requirements Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 1 — Product Requirements & Business Analysis  
**Status:** VERIFIED  

---

## 1. Authentication & Multi-Tenancy (FR-01 to FR-05)

- **FR-01: Multi-Tenancy Isolation:** All entities (Users, Incidents, Evidence, Memories, Audit Logs) must belong to an explicit `organization_id`. Cross-tenant data access is strictly forbidden at API and database query layers.
- **FR-02: Role-Based Access Control (RBAC):** Five standardized roles:
  1. `ORGANIZATION_OWNER`: Full billing, tenant management, user management, and security configuration.
  2. `OPERATIONS_ADMIN`: Incident oversight, knowledge approval sign-off, memory bank administration.
  3. `DEVOPS_ENGINEER`: Incident creation, evidence ingestion, AI investigation triggers, postmortem authoring.
  4. `INCIDENT_RESPONDER`: Incident triage, diagnostics execution, status transitions.
  5. `READ_ONLY_OBSERVER`: View-only access to dashboards, incidents, and audit logs.
- **FR-03: Session Management:** Secure token-based session handling with standard header authorization.

---

## 2. Incident & Evidence Management (FR-06 to FR-10)

- **FR-06: Incident Creation & Triage:** Support incident title, summary, affected service, severity (`SEV-1 Critical`, `SEV-2 Major`, `SEV-3 Moderate`, `SEV-4 Minor`), status (`TRIGGERED`, `INVESTIGATING`, `IDENTIFIED`, `MITIGATED`, `RESOLVED`), and assigned responder.
- **FR-07: Multi-Modal Evidence Attachment:** Ingest evidence of types:
  - `LOG_SNIPPET` (application or system logs with timestamps)
  - `METRIC_SERIES` (timeseries datapoints, e.g. connection pool exhaustion, CPU spike)
  - `STACK_TRACE` (runtime exception traces)
  - `DEPLOYMENT_DIFF` (git commit shas, config flag changes)
- **FR-08: Evidence Integrity:** Evidence items are immutable once attached and stamped with ingest timestamp, author, and checksum.

---

## 3. AI Investigation & Epistemological Separation (FR-11 to FR-15)

- **FR-11: Investigation Trigger:** On-demand or automated triggering of AI analysis across attached evidence.
- **FR-12: Strict 5-Part Epistemological Output:** Investigation findings must partition output into:
  1. *Observed Facts* (concrete data grounded directly in attached evidence)
  2. *Historical Memories* (recalled past incident cases with similarity metrics and source links)
  3. *Possible Causes & Hypotheses* (ranked by evidence score: High, Medium, Low)
  4. *Recommended Safe Diagnostic Checks* (read-only inspection commands with zero write operations)
  5. *Unknown Information* (telemetry gaps or ambiguities)
- **FR-13: Confidence Scoring & Rationale:** Agent provides numerical confidence (0–100%) and textual uncertainty rationale.

---

## 4. Hindsight Memory Lifecycle & Governance (FR-16 to FR-20)

- **FR-16: Automated Recall during Triage:** Query Hindsight memory bank using current incident symptoms and service metadata.
- **FR-17: Postmortem Authoring:** Structured postmortem editor containing summary, root cause, trigger event, resolution steps, and prevention measures.
- **FR-18: Knowledge Approval Queue:** Postmortems submitted for memory retention enter a review queue. Approval requires `OPERATIONS_ADMIN` or `ORGANIZATION_OWNER` authorization.
- **FR-19: Hindsight Retain Execution:** Upon approval, payload is formatted, hashed, and committed via Hindsight `retain()`. Resulting `memory_id` is linked in PostgreSQL.
- **FR-20: Memory Bank Explorer:** Responders can inspect retained memories, search past fixes, and review recall analytics.
