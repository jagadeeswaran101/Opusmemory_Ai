# Acceptance Criteria (MVP Baseline 0.1.0)

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 1 — Product Requirements & Business Analysis  
**Status:** VERIFIED  

---

## 1. Traceability & Acceptance Matrix

| Item ID | Requirement | Acceptance Criterion | Verification Method |
|---|---|---|---|
| **AC-01** | Multi-Tenancy Isolation | Data created in Tenant 1 cannot be queried or updated by Tenant 2. | Automated unit & integration tests (`src/services/engine.test.ts`) |
| **AC-02** | Evidence Attachment | Users can attach logs, metrics series, and git diffs to an incident. | REST API test + UI Evidence Inspector |
| **AC-03** | AI Investigation Separation | Investigation report renders distinct sections for: Observed Facts, Historical Memories, Hypotheses, Diagnostic Checks, Unknowns. | Automated schema validation + UI Workspace check |
| **AC-04** | Hindsight Retain | Approved postmortems are committed to Hindsight via `retain()` and assigned a unique memory ID. | Unit test + Memory Explorer view |
| **AC-05** | Hindsight Recall | Investigation queries Hindsight with incident symptoms and retrieves relevant historical incidents. | Unit test + Recall visualizer |
| **AC-06** | Critical 2-Incident Reuse | Resolving and approving Incident 1 (DB pool leak) causes subsequent Incident 2 with similar symptoms to recall Incident 1 with explicit citation. | E2E Scenario test + Interactive Demo flow |
| **AC-07** | Human Approval Gate | Unapproved postmortems are NOT retained into Hindsight memory banks. | Authorization check in approval service |
| **AC-08** | Audit Trail | Every incident creation, status change, investigation, and approval is logged with timestamp and user ID. | Immutable audit log inspection |
