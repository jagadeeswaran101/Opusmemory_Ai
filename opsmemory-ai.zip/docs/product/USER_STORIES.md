# User Stories: Core Product Journeys

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 1 — Product Requirements & Business Analysis  
**Status:** VERIFIED  

---

## 1. Epics & User Stories

### Epic 1: Incident Creation & Evidence Ingestion
- **US-01:** As an Incident Responder, I want to create an incident with title, severity, and impacted service, so my team can coordinate triage immediately.
- **US-02:** As an Incident Responder, I want to attach logs, metric snippets, and deployment diffs to the incident, so the AI agent and my peers have full technical context.

### Epic 2: Evidence-Driven AI Investigation & Memory Recall
- **US-03:** As an Incident Responder, I want the AI to query Hindsight memory banks using current symptoms, so I can immediately see if a similar incident occurred before.
- **US-04:** As an Incident Responder, I want the investigation report to clearly distinguish observed evidence from unproven hypotheses, so I don't act on hallucinations.
- **US-05:** As an Incident Responder, I want safe, read-only diagnostic check commands with explanations of what each command checks, so I can verify hypotheses safely.

### Epic 3: Resolution & Knowledge Governance
- **US-06:** As a DevOps Engineer, I want to draft a structured postmortem with root cause and fix details, and submit it for knowledge retention.
- **US-07:** As an Operations Admin, I want to review submitted postmortems in a Knowledge Approval Queue, so only high-quality, verified resolutions enter permanent memory.
- **US-08:** As an Operations Admin, when I approve a postmortem, I want it committed to Hindsight via `retain()`, so all future incidents benefit from the learning.

### Epic 4: Verification of Reused Memory (Critical Two-Incident Flow)
- **US-09:** As an SRE, when I investigate a second incident with identical symptoms (e.g. DB connection leak), I want to see the exact recalled memory from the first incident with source attribution, proving that the platform learned and applied historical experience.
