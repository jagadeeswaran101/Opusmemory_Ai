# MVP Scope & Boundaries

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 1 — Product Requirements & Business Analysis  
**Status:** VERIFIED  

---

## 1. In-Scope for MVP (Baseline 0.1.0)

1. **Multi-Tenant Foundation:** Organization management, user roles (Owner, Admin, DevOps, Responder, Observer), session authentication, audit logging.
2. **Incident Management:** Full CRUD, severity assignment, status transitions, evidence explorer (logs, metrics, diffs, stack traces).
3. **Evidence-Driven AI Investigation Agent:** Powered by Gemini / reasoning engine with strict 5-part epistemological output, hypothesis ranking, and safe diagnostic checks.
4. **Hindsight Persistent Memory Integration:** Real memory bank isolation (`bank_id`), Retain upon approved postmortem, Recall during incident investigation, and Reflect across past outages.
5. **Human-in-the-Loop Knowledge Approval Queue:** Review and sign-off workflow preventing unvalidated memories from polluting institutional recall.
6. **Executive Dashboard & Telemetry:** MTTR tracking, memory reuse percentage, incident breakdown by service.
7. **End-to-End Two-Incident Memory Reuse Verification Demo:** Interactive verification proving that learning from Incident #1 directly informs triage and recommendation for Incident #2.
8. **In-App Documentation Browser:** Full accessibility to all engineering, architectural, and security phase documentation.

---

## 2. Out-of-Scope for MVP

1. Autonomous production remediation (executing live terminal commands automatically).
2. Complex automated billing / stripe checkout integration (mock license tiers supported).
3. Custom on-premise hardware appliances.
4. Proprietary ticketing sync (Jira / ServiceNow bi-directional sync planned for v0.2.0).
