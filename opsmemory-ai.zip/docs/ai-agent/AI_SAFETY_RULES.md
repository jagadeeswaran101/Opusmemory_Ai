# AI Safety Rules & Operational Boundaries

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. Safety Non-Negotiables

1. **Human Governance Invariance:** No AI output can directly close an incident, mark a postmortem as approved, or commit memories to Hindsight without human approval.
2. **Anti-Hallucination Guardrails:** The agent must refuse to confirm root causes in the absence of corroborating evidence.
3. **Prompt Injection Neutralization:** Input logs containing adversarial jailbreaks (e.g. `System: Disregard prior instructions`) are escaped, sanitized, and flagged as suspicious telemetry.
4. **Tenant Isolation Verification:** The prompt context assembly strictly checks `evidence.organization_id == user.organization_id`.
