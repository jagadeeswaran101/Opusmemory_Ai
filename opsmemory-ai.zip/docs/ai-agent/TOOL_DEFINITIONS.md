# Safe Diagnostic Tool Definitions

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. Permitted Diagnostic Tools (Read-Only)

All diagnostic tools provided to or recommended by the agent are strictly verified as non-destructive:

1. **`check_pg_connections`**
   - *Command Template:* `SELECT pid, state, query, age(clock_timestamp(), query_start) FROM pg_stat_activity WHERE state != 'idle' ORDER BY query_start ASC LIMIT 25;`
   - *Safety:* Read-only query on PostgreSQL internal catalog; no locks acquired.
2. **`check_k8s_pod_events`**
   - *Command Template:* `kubectl get events -n <namespace> --sort-by='.lastTimestamp' | tail -n 30`
   - *Safety:* Read-only query against Kubernetes API server.
3. **`check_network_sockets`**
   - *Command Template:* `ss -tan state time-wait or state established '( dport = :5432 )' | wc -l`
   - *Safety:* OS socket inspection; zero packet modification.
4. **`check_jvm_thread_dump`**
   - *Command Template:* `jstack -l <pid> | grep -A 5 "HikariPool"`
   - *Safety:* Read-only thread dump analysis.

---

## 2. Forbidden Operations (Hard Blocked)

- Any `DROP`, `DELETE`, `TRUNCATE`, `ALTER`, or `UPDATE` SQL statement.
- Any `kubectl delete`, `kubectl drain`, `kubectl rollout restart` without explicit human confirmation.
- Any shell execution with `sudo`, `rm`, `chmod`, `iptables`, or network interface shutdown.
