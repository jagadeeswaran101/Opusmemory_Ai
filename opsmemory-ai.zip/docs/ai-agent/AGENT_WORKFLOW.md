# AI Incident Investigation Agent Workflow

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. Complete Agent Execution Loop

The Investigation Agent executes a 14-step verified workflow upon receiving an incident investigation request:

```
 1. Receive incident ID and caller context
 2. Validate tenant organization and user RBAC permissions
 3. Query PostgreSQL for all attached IncidentEvidence items
 4. Normalize evidence into structured tokens (error codes, services, timestamps, metrics)
 5. Extract core symptom signature
 6. Query Hindsight Memory Bank via Recall(bank_id, symptom_signature)
 7. Correlate current evidence tokens with recalled postmortem playbooks
 8. Generate possible root cause hypotheses
 9. Score and rank hypotheses by evidence weight (High, Medium, Low)
10. Formulate safe, read-only diagnostic check commands
11. Compute numerical confidence score and uncertainty rationale
12. Assemble 5-part epistemological contract
13. Persist investigation report in PostgreSQL
14. Stream/deliver findings to the human investigator in the Incident Workspace
```
