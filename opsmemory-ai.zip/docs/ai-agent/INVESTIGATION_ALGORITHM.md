# Investigation Algorithm & Hypothesis Ranking

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. Epistemological Separation Principle

Every piece of output emitted by the Investigation Agent is assigned to one of five distinct epistemological categories:

1. **Observed Facts:** Statements that can be verified directly from the attached evidence without inference (e.g. "Container logged error code 53300 at 09:18:42 UTC").
2. **Historical Memories:** Knowledge items recalled from previous approved postmortems in Hindsight (e.g. "Incident #89 resolved by setting HikariCP maxLifetime").
3. **Hypotheses & Root Causes:** Inferred possibilities explaining the discrepancy, ranked by corroborating evidence.
4. **Recommended Safe Diagnostics:** Inspection commands that can confirm or refute a hypothesis without modifying infrastructure state.
5. **Unknown Information:** Gaps in telemetry or unmeasured variables explicitly stated to prevent false certainty.

---

## 2. Hypothesis Ranking Algorithm

Each hypothesis $H_i$ is scored as:
$$\text{Score}(H_i) = w_e \sum_{e \in E^+} \text{weight}(e) - w_c \sum_{c \in E^-} \text{weight}(c) + w_m \cdot \text{Similarity}(H_i, M)$$
Where $E^+$ are supporting evidence items, $E^-$ are contradicting evidence items, and $M$ is the recalled historical memory.
- Score $> 0.80$: Likelihood `HIGH`
- Score $0.50 - 0.80$: Likelihood `MEDIUM`
- Score $< 0.50$: Likelihood `LOW`
