# Structured Output Schema Definition

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. JSON Schema Contract

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "OpsMemoryInvestigationReport",
  "type": "object",
  "properties": {
    "confidence_score": { "type": "number", "minimum": 0, "maximum": 100 },
    "confidence_rationale": { "type": "string" },
    "observed_facts": {
      "type": "array",
      "items": { "type": "string" }
    },
    "historical_memories": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "memory_id": { "type": "string" },
          "incident_number": { "type": "integer" },
          "title": { "type": "string" },
          "similarity_score": { "type": "number" },
          "relevance_explanation": { "type": "string" },
          "key_takeaway": { "type": "string" }
        },
        "required": ["memory_id", "title", "similarity_score", "key_takeaway"]
      }
    },
    "possible_root_causes": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": { "type": "string" },
          "hypothesis": { "type": "string" },
          "likelihood": { "type": "string", "enum": ["HIGH", "MEDIUM", "LOW"] },
          "supporting_evidence_ids": { "type": "array", "items": { "type": "string" } },
          "contradicting_evidence_ids": { "type": "array", "items": { "type": "string" } }
        },
        "required": ["id", "hypothesis", "likelihood"]
      }
    },
    "recommended_diagnostic_checks": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "id": { "type": "string" },
          "title": { "type": "string" },
          "command": { "type": "string" },
          "safety_level": { "type": "string", "enum": ["READ_ONLY_SAFE", "CAUTION"] },
          "rationale": { "type": "string" }
        },
        "required": ["id", "title", "command", "safety_level", "rationale"]
      }
    },
    "unknown_information": {
      "type": "array",
      "items": { "type": "string" }
    }
  },
  "required": [
    "confidence_score",
    "observed_facts",
    "historical_memories",
    "possible_root_causes",
    "recommended_diagnostic_checks",
    "unknown_information"
  ]
}
```
