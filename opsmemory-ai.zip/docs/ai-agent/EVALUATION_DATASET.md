# Evaluation Dataset & Ground-Truth Scenarios

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 7 — AI Incident Investigation Agent  
**Status:** VERIFIED  

---

## 1. Ground-Truth Golden Test Cases

| Scenario ID | Incident Signature | Expected Recalled Memory | Ground-Truth Root Cause | Safe Diagnostic Check |
|---|---|---|---|---|
| **SCN-001** | PostgreSQL error 53300, HikariCP max 100 conns | Incident #89 (HikariCP leak) | Stale connections hanging without maxLifetime/idleTimeout | `SELECT pid, state, query FROM pg_stat_activity WHERE state != 'idle'` |
| **SCN-002** | Kubernetes OOMKilled on Auth Service, RSS spiking | Incident #64 (Go routine memory leak) | Unbounded in-memory token cache without LRU eviction | `kubectl top pod -l app=auth-service` |
| **SCN-003** | Gateway 504 Gateway Timeout, upstream latency spike | Incident #112 (Downstream DNS resolution delay) | DNS resolution thread starvation on CoreDNS | `dig @kube-dns auth.internal +stats` |
| **SCN-004** | Redis WRONGTYPE Operation against key holding string | Incident #41 (Key collision on session namespace) | Unnamespaced session key clash across microservices | `redis-cli TYPE user:session:active` |
