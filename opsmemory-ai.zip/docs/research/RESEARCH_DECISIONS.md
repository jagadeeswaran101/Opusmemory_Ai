# Research Decisions & Architectural Baseline (ADR-000)

**Product:** OpsMemory AI  
**Document Version:** 1.0.0  
**Phase:** 0 — Repository Reconnaissance & Reverse Engineering  
**Status:** VERIFIED  

---

## 1. Context

Operations teams continuously face recurrent infrastructure incidents (connection pool exhaustion, runaway queries, bad deployment rollouts, memory leaks). While postmortems are authored, their insights remain inert and forgotten. We need a system that actively recalls verified historical experience during ongoing incidents without introducing autonomous danger.

---

## 2. Key Decisions

### Decision 1: Hindsight as Cognitive Memory Layer, PostgreSQL as System of Record
- **Adopted:** Hindsight (`vectorize-io/hindsight`) is designated as the core persistent-memory engine for Retain, Recall, and Reflect operations.
- **Rationale:** Hindsight provides semantic associative retrieval, memory graph awareness, and bank isolation.
- **Constraint:** PostgreSQL remains the transactional system of record. Hindsight failure must never impede incident updates or corrupt transactional records.

### Decision 2: Epistemological Separation of Investigation Data
- **Adopted:** Every AI investigation report must explicitly separate:
  1. *Observed Facts* (concrete logs, error codes, metrics)
  2. *Historical Memories* (recalled past postmortems with link and similarity score)
  3. *Possible Causes & Hypotheses* (ranked by evidence strength)
  4. *Recommended Diagnostic Checks* (safe, read-only commands)
  5. *Unknown Information* (missing telemetry, unprobed subsystems)
- **Rationale:** Eliminates AI hallucination and builds trust with site reliability engineers.

### Decision 3: Mandatory Human-in-the-Loop Knowledge Approval
- **Adopted:** AI-generated findings or incident resolutions cannot be retained directly into long-term organizational memory without explicit human approval from an Operations Admin, DevOps Engineer, or Org Owner.
- **Rationale:** Prevents poisoned or transient assumptions from permanently corrupting organizational memory.

### Decision 4: Zero Autonomous Production Mutation in MVP
- **Adopted:** OpsMemory AI recommends safe read-only diagnostics (e.g. `pg_stat_activity`, `kubectl logs`, `netstat`) but never executes mutations or commands automatically against production clusters.
- **Rationale:** Enterprise security policy compliance and absolute protection against catastrophic automated outages.
