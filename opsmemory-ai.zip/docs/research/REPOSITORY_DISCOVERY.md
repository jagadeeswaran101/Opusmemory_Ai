# Repository Discovery & Reconnaissance: Reverse Engineering & Prior Art

**Product:** OpsMemory AI  
**Document Version:** 1.0.0  
**Phase:** 0 — Repository Reconnaissance & Reverse Engineering  
**Status:** VERIFIED  

---

## 1. Executive Summary

OpsMemory AI is a B2B SaaS persistent-memory incident response platform for engineering and operations teams. To ensure enterprise-grade architecture, robust clean-room implementation, and avoidance of unverified proprietary code or fragile dependencies, we conducted structured reconnaissance across GitHub open-source repositories and foundational systems.

Our primary investigation centered on:
1. **Long-Term Memory Engines:** Specifically Hindsight (`vectorize-io/hindsight`) and memory graph/vector systems.
2. **Reverse Engineering & System Discovery:** Repositories within `reverse-engineer-anything` and related system discovery topics.
3. **Incident Response & Postmortem Systems:** Open-source incident workflows, evidence normalization, and audit trails.
4. **Agent Orchestration & Protocol Analysis:** Safe tool-calling, MCP (Model Context Protocol), and structured telemetry.

---

## 2. Candidate Repositories Review

| Repository | Purpose | Relevant Capability | License | Maintenance | Integration | Risks | Decision |
|---|---|---|---|---|---|---|---|
| `https://github.com/vectorize-io/hindsight` | AI agent long-term memory engine | Core Retain, Recall, Reflect operations; bank isolation; cross-incident memory | Apache 2.0 | Active (v0.2+) | Native REST / SDK integration with fallback adapter | Network partition or service unavailability requires circuit breaker | **Adopt (Core Memory)** |
| `https://github.com/reverse-engineer-anything/clean-arch-patterns` | Architecture discovery & protocol analysis | Clean-room architectural separation and protocol isolation patterns | MIT | Active | Design patterns for normalized incident evidence | Over-engineering if applied outside domain boundary | **Adapt (Architecture)** |
| `https://github.com/modelcontextprotocol/servers` | Anthropic MCP reference servers | Standardized context retrieval & external tooling interfaces | MIT | Active | Schema inspiration for diagnostic check tooling | Protocol churn; keep MVP decoupled from direct MCP runtime | **Study (Schema Inspiration)** |
| `https://github.com/elastic/ecs` | Elastic Common Schema (ECS) | Standardized telemetry, log, and audit event taxonomies | Apache 2.0 | Active | Normalized evidence ingestion format (logs, metrics, events) | Heavy schema footprint; adapt essential fields only | **Adapt (Telemetry Schema)** |
| `https://github.com/facebook/docusaurus` | Documentation & knowledge management | Multi-version technical documentation structure | MIT | Active | Reference for in-app knowledge base and postmortem rendering | Not needed as runtime dependency | **Study (Structure)** |
| `https://github.com/getsentry/sentry` | Incident & error monitoring | Error grouping, stack trace normalization, breadcrumb tracking | FSL / BSL | Active | Reference for incident timeline & evidence correlation | License restrictions (BSL); clean-room implementation required | **Study (Clean-Room Only)** |

---

## 3. Discovery Findings & Boundary Rules

1. **Clean-Room Boundary:** No code from copyleft or proprietary/BSL projects (such as Sentry or commercial APMs) may be copied. OpsMemory AI relies solely on permissive MIT/Apache 2.0 specifications and clean-room domain engineering.
2. **Hindsight Independence:** Hindsight serves as the cognitive memory layer, while PostgreSQL remains the transactional system of record. Hindsight failure must never corrupt or block PostgreSQL state changes.
3. **No Autonomous Production Modification:** Unlike risky autonomous remediation tools found in exploratory repos, OpsMemory AI strictly limits AI agent output to verified diagnostics, hypotheses, and safe read-only recommendations. Human review is mandatory.
