# License & Dependency Compliance Review

**Product:** OpsMemory AI  
**Document Version:** 1.0.0  
**Phase:** 0 — Repository Reconnaissance & Reverse Engineering  
**Status:** VERIFIED  

---

## 1. Governance & Compliance Principles

Enterprise B2B SaaS deployments require rigorous compliance verification:
1. **No Viral Copyleft:** Strictly reject GPL, AGPL, and derivative copyleft licenses that compromise SaaS intellectual property.
2. **No Ambiguous Non-Commercial or Source-Available Licenses:** Reject BSL (Business Source License) or SSPL to ensure unconditional freedom to operate.
3. **Audit Trail for Third-Party Code:** All third-party packages must be recorded with verified version pins and checksums.

---

## 2. Dependency Inventory

| Package | Version | License | Security Advisory Check | Decision |
|---|---|---|---|---|
| `react` | 19.0.1 | MIT | 0 known vulnerabilities | APPROVED |
| `react-dom` | 19.0.1 | MIT | 0 known vulnerabilities | APPROVED |
| `express` | 4.21.2 | MIT | 0 known vulnerabilities | APPROVED |
| `@google/genai` | 2.4.0 | Apache 2.0 | 0 known vulnerabilities | APPROVED |
| `lucide-react` | 0.546.0 | ISC | 0 known vulnerabilities | APPROVED |
| `motion` | 12.23.24 | MIT | 0 known vulnerabilities | APPROVED |
| `tailwindcss` | 4.3.3 | MIT | 0 known vulnerabilities | APPROVED |
| `dotenv` | 17.2.3 | BSD-2-Clause | 0 known vulnerabilities | APPROVED |
| `tsx` | 4.21.0 | MIT | 0 known vulnerabilities | APPROVED |
| `typescript` | 7.0.2 | Apache 2.0 | 0 known vulnerabilities | APPROVED |

---

## 3. Dependency Risk Mitigation

- External Hindsight network connectivity is isolated behind a resilience proxy layer. If the external Hindsight instance drops offline, the application falls back without service degradation or data loss.
- Gemini API key is maintained securely on the server-side environment (`process.env.GEMINI_API_KEY`) and never leaked to the client browser or serialized in client states.
