# System Architecture Diagrams (C4 Model)

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. C4 Context Diagram

```
┌────────────────────────────────────────────────────────┐
│                   Engineering Team                     │
│  (Ops Admin, DevOps Engineer, Incident Responder)      │
└───────────┬────────────────────────────────┬───────────┘
            │ HTTPS                          │ Webhook Ingest
            ▼                                ▼
┌────────────────────────────────────────────────────────┐
│                 OpsMemory AI Platform                  │
│                                                        │
│  - Incident Lifecycle & Triage                         │
│  - Evidence Parsing & Correlation                      │
│  - AI Investigation with Epistemological Separation    │
│  - Hindsight Persistent Memory Engine                  │
│  - Knowledge Approval & Governance Queue               │
└───────────┬────────────────────────────────┬───────────┘
            │ SQL Queries                    │ REST / RPC
            ▼                                ▼
┌───────────────────────┐        ┌───────────────────────┐
│     PostgreSQL 16     │        │    Hindsight Engine   │
│   (System of Record)  │        │  (Cognitive Memory)   │
└───────────────────────┘        └───────────────────────┘
```

---

## 2. C4 Container Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│ OpsMemory AI Web Application (React 19 + Tailwind CSS)           │
│ - Triage Console, Evidence Inspector, AI Workspace, Memory Bank  │
└─────────────────────────────────┬────────────────────────────────┘
                                  │ JSON / HTTPS
┌─────────────────────────────────▼────────────────────────────────┐
│ OpsMemory API Service (Node.js / Express / TypeScript)           │
│                                                                  │
│ ┌───────────────────────────┐  ┌───────────────────────────────┐ │
│ │ Auth & Tenant Middleware  │  │ Incident & Evidence Service   │ │
│ └───────────────────────────┘  └───────────────────────────────┘ │
│ ┌───────────────────────────┐  ┌───────────────────────────────┐ │
│ │ AI Investigation Agent    │  │ Hindsight Memory Adapter      │ │
│ └───────────────────────────┘  └───────────────────────────────┘ │
│ ┌───────────────────────────┐  ┌───────────────────────────────┐ │
│ │ Knowledge Approval Engine │  │ Immutable Audit Logger        │ │
│ └───────────────────────────┘  └───────────────────────────────┘ │
└──────────┬─────────────────────────────┬─────────────────────────┘
           │                             │
           ▼                             ▼
┌───────────────────────┐    ┌───────────────────────────────────┐
│ PostgreSQL Database   │    │ Hindsight Cognitive Memory API    │
│ (Tables: orgs, users, │    │ (Endpoints: /retain, /recall,     │
│ incidents, evidence,  │    │  /reflect, /banks)                │
│ postmortems, audits)  │    └───────────────────────────────────┘
└───────────────────────┘
```
