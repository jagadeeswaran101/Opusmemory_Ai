# Hindsight Memory Engine Architecture

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. Hindsight Primitive Mapping

| Hindsight Operation | Operational Semantics | Trigger in OpsMemory AI |
|---|---|---|
| **Retain** | Store verified knowledge item into memory bank with semantic embeddings and entity graph links. | Executed when an Operations Admin approves a resolved incident postmortem in the Knowledge Approval Queue. |
| **Recall** | Associative search retrieving past incidents, root causes, and playbook fixes matching symptom vector. | Automatically executed when an incident is opened or when the responder clicks "Run AI Investigation". |
| **Reflect** | Synthesize higher-order insights across multiple retained memories (e.g., recurrent pool leaks). | Executed on the Analytics and Memory Explorer dashboards to identify recurring architectural fragility. |

---

## 2. Multi-Tenant Memory Bank Isolation

Hindsight memory banks are strictly partitioned by organization ID:
- **Naming Convention:** `org_{organization_id}_ops`
- **Identity Isolation:** The Hindsight adapter automatically prepends the caller's verified `organization_id` to all Retain and Recall requests. Under no circumstances can a query bridge across multiple bank IDs.
- **Auditing:** Every Retain and Recall request emits an audit log event with tenant ID, memory bank ID, query vector, and retrieved memory IDs.
