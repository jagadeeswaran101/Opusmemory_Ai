# Architecture Decision Records (ADR Summary)

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## ADR Summary Log

- **ADR-001: Separation of System of Record and Cognitive Memory**  
  *Status:* Accepted  
  *Context:* Incident status and audit logs require transactional ACID guarantees, whereas memory recall requires semantic associative search.  
  *Decision:* PostgreSQL serves as system of record; Hindsight manages associative memory banks.

- **ADR-002: Strict Multi-Tenant Memory Banks**  
  *Status:* Accepted  
  *Context:* Multi-tenant SaaS must prevent cross-customer data leakage in vector/memory spaces.  
  *Decision:* All Hindsight calls prefix `bank_id` with `org_{orgId}`. Memory retrieval queries are hard-bounded to this bank.

- **ADR-003: 5-Part Epistemological Investigation Contract**  
  *Status:* Accepted  
  *Context:* Responders must not confuse verified logs with speculative AI hypotheses.  
  *Decision:* Investigation outputs strictly enforce 5 distinct arrays: Observed Facts, Historical Memories, Hypotheses, Diagnostic Checks, Unknowns.

- **ADR-004: Read-Only Tool Execution Boundary**  
  *Status:* Accepted  
  *Context:* Automated AI execution of shell commands in production is hazardous.  
  *Decision:* AI suggests safe read-only inspection commands with explanations. The system will not execute automated write/remediation scripts against infrastructure.
