# Backend Architecture Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. Modular Services Design

The backend is built as a modular TypeScript service architecture in Node.js / Express:
1. **Tenant & Context Middleware:** Validates API tokens, extracts user identity and `organization_id`, and attaches a scoped execution context to every incoming request.
2. **Incident Service:** Handles lifecycle state transitions (`TRIGGERED` → `INVESTIGATING` → `IDENTIFIED` → `MITIGATED` → `RESOLVED`), assigns responders, and maintains timeline events.
3. **Evidence Service:** Ingests and normalizes multi-modal payloads (`LOG_SNIPPET`, `METRIC_SERIES`, `DEPLOYMENT_DIFF`, `STACK_TRACE`), validating schema constraints and payload sizes.
4. **Hindsight Memory Adapter:** Interfaces with Hindsight memory banks using tenant-scoped identifiers (`bank_id: "org_{orgId}_ops"`). Handles `retain`, `recall`, and `reflect` requests with exponential backoff and circuit-breaking.
5. **Investigation Agent Service:** Gathers active incident evidence, calls Hindsight `recall()`, constructs the Gemini prompt, and parses the structured 5-part epistemological response.
6. **Knowledge Approval Service:** Manages postmortem promotion workflow. Enforces required role checks (`OPERATIONS_ADMIN` or `ORGANIZATION_OWNER`) before triggering Hindsight `retain()`.
7. **Audit Service:** Writes immutable audit entries for all system actions.
