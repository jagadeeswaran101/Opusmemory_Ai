# Frontend Architecture Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. Design Philosophy & Technology Baseline

- **Framework:** React 19 (functional components, typed custom hooks, strict mode).
- **Styling:** Tailwind CSS v4 using semantic dark navy tokens (`slate-950`, `slate-900`, `cyan-500`, `emerald-500`, `amber-500`, `rose-500`).
- **Icons:** Lucide React for consistent, high-density engineering iconography.
- **State Management:** Reactive modular store with typed REST service client, optimistic mutations, and resilient caching.
- **Accessibility:** Semantic HTML elements, explicit accessible labels (`aria-label`, headings, labeled inputs), high contrast ratios compliant with WCAG 2.1 AA.

---

## 2. Component Hierarchy

```
App.tsx
├── Header (Organization Switcher, Active User Role, Live Alert Badge)
├── Sidebar Navigation (Dashboard, Incidents, Memory Explorer, Approvals, Demo, Logs, Docs)
└── Main Content Container
    ├── DashboardView (Metrics, Active Incidents, Recent Retentions, System Status)
    ├── IncidentsListView (Filter by severity, status, search)
    ├── IncidentDetailWorkspace
    │   ├── IncidentHeader (Severity, Status transition triggers, Assigned engineer)
    │   ├── EvidenceTimeline (Attached logs, metrics series, diffs, stack traces)
    │   ├── InvestigationPanel (Trigger AI Analysis, 5-part epistemological report)
    │   ├── HistoricalRecallInspector (Recalled past postmortems with match score)
    │   └── PostmortemModal (Authoring and submission to approval queue)
    ├── MemoryExplorerView (Hindsight memory banks, retained knowledge items, search)
    ├── KnowledgeApprovalQueueView (Review postmortem learnings, approve to Hindsight)
    ├── TwoIncidentDemoView (Interactive step-by-step verification of memory reuse)
    ├── AuditLogsView (Filterable append-only audit trail)
    └── DocumentationBrowserView (Interactive navigation of all phase specifications)
```
