# Deployment Architecture Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. Container & Deployment Model

OpsMemory AI is architected for deployment as a 12-factor cloud-native containerized application:
- **Application Container:** Multi-stage Docker container running Node.js 22 LTS, serving the Express API and Vite React frontend bundle.
- **System of Record (PostgreSQL 16):** Hosted PostgreSQL instance with read replicas for high-throughput analytics.
- **Hindsight Memory Cluster:** Dedicated or managed Hindsight service instance configured with persistent volume storage for memory graphs.
- **Secret & Config Management:** Environment variables injected at container runtime via secure secret managers (e.g. Google Cloud Secret Manager / Kubernetes Secrets).

---

## 2. Scalability & Resilience Topology

- Stateless HTTP workers scaled horizontally behind an L7 Load Balancer.
- Health check endpoints (`/api/health`) reporting status of database connectivity, memory engine responsiveness, and API availability.
- Graceful degradation: If Hindsight is temporarily unreachable, incident CRUD and diagnostic workflows operate normally with in-memory resilient fallback.
