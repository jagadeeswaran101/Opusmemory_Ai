# System Architecture Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. High-Level Architecture Overview

OpsMemory AI uses a decoupled, event-aware multi-tier architecture designed around two complementary storage and reasoning backbones:
1. **System of Record (PostgreSQL):** Authoritative state machine for Organizations, Users, Incidents, Evidence, Postmortems, Approval Queues, and Audit Logs.
2. **Persistent Cognitive Memory (Hindsight):** Dedicated memory engine managing bank-isolated associative networks (`bank_id`), handling `retain`, `recall`, and `reflect` primitives.
3. **AI Investigation Agent (Gemini Orchestrator):** Grounded reasoning engine consuming normalized incident evidence and recalled memories to generate structured diagnostic reports.
4. **Operations Web Client (React 19 + Tailwind CSS):** High-density, dark navy operational dashboard for incident responders, SRE leads, and executives.

---

## 2. Container & Component Topology

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENT TIER (React 19 SPA)                     │
│  - Incident Workspace  - Evidence Inspector  - Memory Bank Explorer    │
│  - Two-Incident Demo   - Approval Queue      - Documentation Browser   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ HTTPS / REST API
┌───────────────────────────────────▼────────────────────────────────────┐
│                  BACKEND APPLICATION TIER (Node.js / Express)          │
│                                                                        │
│  ┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────┐ │
│  │ Tenant & Auth Guard   │ │ Incident Controller   │ │ Audit Logger  │ │
│  └───────────────────────┘ └───────────────────────┘ └───────────────┘ │
│  ┌───────────────────────┐ ┌───────────────────────┐ ┌───────────────┐ │
│  │ Investigation Agent   │ │ Hindsight Adapter     │ │ Approval Svc  │ │
│  └───────────┬───────────┘ └───────────┬───────────┘ └───────────────┘ │
└──────────────┼─────────────────────────┼───────────────────────────────┘
               │                         │
               ▼                         ▼
    ┌─────────────────────┐   ┌───────────────────────────────┐
    │  Gemini 2.5 Flash   │   │  Hindsight Memory Engine      │
    │  Reasoning Engine   │   │  - Org Memory Banks           │
    │  Structured Outputs │   │  - Retain / Recall / Reflect  │
    └─────────────────────┘   └───────────────────────────────┘
                                         │
               ┌─────────────────────────┴───────────────┐
               ▼                                         ▼
    ┌─────────────────────────┐               ┌─────────────────────────┐
    │  PostgreSQL 16 (SOR)    │               │  Resilient Fallback     │
    │  Row-Level Security     │               │  In-Memory Cognitive    │
    │  Transactional Entities │               │  Vector Cache           │
    └─────────────────────────┘               └─────────────────────────┘
```
