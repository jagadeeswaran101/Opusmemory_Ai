# Data Flow Architecture

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. End-to-End Investigation Flow

```
[ Incident Triggered ] 
         │ 
         ▼
[ Evidence Attached: Logs, Metrics, Diffs ] 
         │ 
         ▼
[ Investigation Triggered by Responder ]
         │
         ├───▶ [ Query Hindsight: recall(bank_id, symptoms) ] ────▶ [ Returns Past Incident Matches ]
         │                                                                   │
         └───▶ [ Compile Evidence Payload + Recalled Memories ] ─────────────┘
                                 │
                                 ▼
                     [ Gemini Reasoning Engine ]
                                 │
                                 ▼
         [ Validate 5-Part Epistemological Schema ]
                                 │
                                 ▼
         [ Store Investigation Record in PostgreSQL ]
                                 │
                                 ▼
         [ Render Diagnostic Findings in UI ]
```

---

## 2. Postmortem & Memory Retention Flow

```
[ Incident Resolved by SRE ]
         │
         ▼
[ Author Postmortem in Editor ]
         │
         ▼
[ Submit to Knowledge Approval Queue ]
         │
         ▼
[ Admin / Owner Review & Approval ]
         │
         ├───▶ If Rejected: Return to Author with Feedback
         │
         └───▶ If Approved:
                   ├── Write Approval Audit Log
                   ├── Execute Hindsight retain(bank_id, knowledge)
                   ├── Receive Unique Memory ID from Hindsight
                   └── Update PostgreSQL Postmortem with memory_id & timestamp
```
