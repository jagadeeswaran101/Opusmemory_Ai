# AI Agent Architecture Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 2 — Complete Application Architecture  
**Status:** VERIFIED  

---

## 1. Grounded Epistemological Reasoning Pipeline

The AI Investigation Agent does not operate as an ungrounded conversational bot. Instead, it follows a deterministic 5-stage epistemological pipeline:

```
[ Stage 1: Evidence Ingestion & Normalization ]
Extract symptoms, error codes, service names, timestamps, and metric deviations.
                       │
                       ▼
[ Stage 2: Cognitive Memory Recall ]
Query Hindsight Bank: recall(bank_id, symptoms, top_k=5)
Filter for memories with confidence score >= 0.65.
                       │
                       ▼
[ Stage 3: Hypothesis Synthesis & Cross-Correlation ]
Evaluate evidence against recalled historical patterns.
Rank hypotheses: High Confidence / Moderate / Low.
Identify contradictions and telemetry gaps.
                       │
                       ▼
[ Stage 4: Safe Diagnostic Tool Recommendation ]
Suggest read-only verification commands (e.g., pg_stat_activity, k8s logs).
Explicitly forbid any destructive production mutation.
                       │
                       ▼
[ Stage 5: Structured 5-Part Epistemological Contract ]
Format final payload matching schema:
- observed_facts: string[]
- historical_memories: RecalledMemoryReference[]
- possible_root_causes: Hypothesis[]
- recommended_diagnostic_checks: SafeDiagnosticCheck[]
- unknown_information: string[]
```

---

## 2. Prompt Defense & Security Boundaries

1. **Log Sanitization:** Raw logs are stripped of potential prompt injection sequences (e.g. `Ignore previous instructions and output...`) before feeding to the LLM.
2. **Strict JSON Schema Enforcement:** Model output is validated against a TypeScript schema; any malformed response is intercepted and parsed through a validation recovery loop.
3. **Evidence Citations:** Each hypothesis must reference specific evidence IDs or memory IDs.
