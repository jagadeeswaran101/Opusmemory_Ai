# Hindsight Memory Engine API Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. POST /api/memory/recall

Performs associative recall against the organization's Hindsight memory bank.

### Request Body
```json
{
  "query": "PostgreSQL error 53300 remaining connection slots reserved hikaricp leak",
  "service": "payments-db",
  "limit": 5
}
```

### Response (200 OK)
```json
{
  "success": true,
  "data": {
    "bankId": "org_default_01_ops",
    "matchesCount": 1,
    "memories": [
      {
        "memoryId": "mem_pg_pool_0814",
        "title": "HikariCP Connection Leak under High Concurrency",
        "similarity": 0.94,
        "incidentNumber": 89,
        "rootCause": "Missing idleTimeout and maxLifetime config on HikariCP pool in payments microservice.",
        "resolutionPlaybook": "Configure maxLifetime=1800000 and idleTimeout=600000. Restart deployment.",
        "approvedBy": "Elena Rostova (Operations Admin)",
        "retainedAt": "2026-08-15T14:30:00Z"
      }
    ]
  }
}
```

---

## 2. POST /api/knowledge-approvals/:id/review

Reviews and commits an approved postmortem into Hindsight memory via `retain()`.

### Request Body
```json
{
  "decision": "APPROVED",
  "reviewNotes": "Verified root cause and playbook efficacy in staging. Retain for institutional recall."
}
```

### Response (200 OK)
```json
{
  "success": true,
  "data": {
    "approvalId": "appr_4410",
    "status": "APPROVED",
    "hindsightMemoryId": "mem_pg_pool_20261104",
    "retainedAt": "2026-11-04T09:25:00Z"
  }
}
```
