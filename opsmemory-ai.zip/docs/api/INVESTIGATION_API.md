# AI Investigation & Findings API Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. POST /api/incidents/:id/investigate

Initiates evidence normalization, Hindsight recall, and Gemini reasoning to produce the 5-part epistemological investigation report.

### Response (200 OK)
```json
{
  "success": true,
  "data": {
    "investigationId": "inv_7721a9",
    "incidentId": "inc_20261104_001",
    "confidenceScore": 94.0,
    "confidenceRationale": "Strong alignment between current 53300 PostgreSQL errors and historical postmortem PM-20260814-04.",
    "observedFacts": [
      "Payments service container logs indicate error 53300: remaining connection slots are reserved.",
      "Connection pool metric plateaued at exactly 100/100 active connections.",
      "Incident began 4 minutes after deployment of release v2.4.1."
    ],
    "historicalMemories": [
      {
        "memoryId": "mem_pg_pool_0814",
        "title": "Incident #89: HikariCP Idle Timeout Connection Leak",
        "similarityScore": 0.94,
        "resolvedDate": "2026-08-14",
        "keyTakeaway": "Missing spring.datasource.hikari.maxLifetime setting caused stale connections to hang open after batch invoice runs."
      }
    ],
    "possibleCauses": [
      {
        "id": "hyp_1",
        "hypothesis": "HikariCP pool leak introduced in v2.4.1 batch query routine",
        "likelihood": "HIGH",
        "supportingEvidenceIds": ["evi_988b12"],
        "contradictingEvidenceIds": []
      }
    ],
    "recommendedDiagnosticChecks": [
      {
        "id": "diag_1",
        "title": "Inspect Active Connection States in PostgreSQL",
        "command": "SELECT pid, state, query, age(clock_timestamp(), query_start) FROM pg_stat_activity WHERE state != 'idle' ORDER BY query_start ASC LIMIT 20;",
        "safetyLevel": "READ_ONLY_SAFE",
        "rationale": "Identifies long-running uncommitted queries holding pool slots."
      }
    ],
    "unknownInformation": [
      "Whether pgbouncer or direct pod connection is currently in effect.",
      "Detailed query timeout configuration inside application.yaml."
    ]
  }
}
```
