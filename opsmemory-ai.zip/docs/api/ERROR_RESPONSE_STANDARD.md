# Error Response Standard & RFC 7807 Compliance

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. Unified Error Payload Structure

All API error responses adhere to a predictable, standardized envelope:

```json
{
  "success": false,
  "error": {
    "code": "RESOURCE_NOT_FOUND",
    "message": "Incident with ID 'inc_999' does not exist in this organization.",
    "statusCode": 404,
    "details": {
      "resourceType": "Incident",
      "resourceId": "inc_999"
    },
    "requestId": "req_55a298",
    "timestamp": "2026-11-04T09:20:00Z"
  }
}
```

---

## 2. Standard Error Codes Matrix

| HTTP Status | Error Code | Description | User Action |
|---|---|---|---|
| **400** | `INVALID_INPUT` | Request failed schema validation or missing required fields. | Check payload parameters |
| **401** | `UNAUTHENTICATED` | Missing or expired session token. | Re-authenticate |
| **403** | `FORBIDDEN` | Caller lacks required role (e.g. non-admin attempting approval). | Request elevated role |
| **404** | `RESOURCE_NOT_FOUND` | Target entity not found in caller's organization. | Verify entity identifier |
| **409** | `CONFLICT` | Concurrent edit or duplicate incident number collision. | Retry with latest version |
| **422** | `UNPROCESSABLE_ENTITY` | Semantic business rule violated (e.g., retaining unapproved postmortem). | Satisfy workflow prerequisite |
| **500** | `INTERNAL_SERVER_ERROR` | Unhandled runtime exception; sanitized before return. | Contact support with requestId |
| **503** | `UPSTREAM_UNAVAILABLE` | External Hindsight / LLM service degraded; fallback active. | Retry operation |
