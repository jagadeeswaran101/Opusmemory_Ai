# Authentication & Organization API Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. POST /api/auth/login

Authenticates a user with email and credentials or development mock role.

### Request Body
```json
{
  "email": "marcus@opsmemory.internal",
  "password": "SecurePassword123!"
}
```

### Response (200 OK)
```json
{
  "success": true,
  "data": {
    "token": "tok_ops_992a71f4",
    "user": {
      "id": "usr_01",
      "email": "marcus@opsmemory.internal",
      "fullName": "Marcus Vance",
      "role": "DEVOPS_ENGINEER",
      "organization": {
        "id": "org_default_01",
        "name": "Acme Cloud Infrastructure",
        "slug": "acme-cloud"
      }
    }
  }
}
```

---

## 2. GET /api/auth/me

Retrieves the currently authenticated user's profile and active organization context.

### Headers
`Authorization: Bearer <token>`

### Response (200 OK)
```json
{
  "success": true,
  "data": {
    "id": "usr_01",
    "email": "marcus@opsmemory.internal",
    "fullName": "Marcus Vance",
    "role": "DEVOPS_ENGINEER",
    "organizationId": "org_default_01"
  }
}
```
