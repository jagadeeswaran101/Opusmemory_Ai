# Incident & Evidence API Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. POST /api/incidents

Creates a new operational incident and dispatches notification events.

### Request Body
```json
{
  "title": "PostgreSQL Connection Pool Exhaustion on Payments DB",
  "summary": "Payments microservice reporting HTTP 500 spikes; active db pool reaching max 100 conns.",
  "severity": "SEV-1",
  "service": "payments-db",
  "assignedUserId": "usr_01"
}
```

### Response (201 Created)
```json
{
  "success": true,
  "data": {
    "id": "inc_20261104_001",
    "incidentNumber": 142,
    "title": "PostgreSQL Connection Pool Exhaustion on Payments DB",
    "severity": "SEV-1",
    "status": "TRIGGERED",
    "service": "payments-db",
    "createdAt": "2026-11-04T09:20:00Z"
  }
}
```

---

## 2. POST /api/incidents/:id/evidence

Attaches structured technical telemetry to an active incident.

### Request Body
```json
{
  "evidenceType": "LOG_SNIPPET",
  "sourceName": "payments-service-pod-774f9",
  "summary": "FATAL: remaining connection slots are reserved for non-replication superuser connections",
  "rawPayload": {
    "timestamp": "2026-11-04T09:18:42Z",
    "errorCode": "53300",
    "activeConnections": 100,
    "poolCapacity": 100
  }
}
```

### Response (201 Created)
```json
{
  "success": true,
  "data": {
    "id": "evi_988b12",
    "incidentId": "inc_20261104_001",
    "evidenceType": "LOG_SNIPPET",
    "createdAt": "2026-11-04T09:20:05Z"
  }
}
```
