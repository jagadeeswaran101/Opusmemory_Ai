# REST API Contract Overview

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. Global API Conventions

- **Base URL:** `/api`
- **Protocol:** HTTPS / JSON
- **Headers:**
  - `Content-Type: application/json`
  - `Authorization: Bearer <session_token>`
  - `X-Organization-Id: <org_uuid>` (optional override if user has multi-org memberships)
- **Standard Success Response Format:**
  ```json
  {
    "success": true,
    "data": { ... },
    "metadata": {
      "timestamp": "2026-11-04T09:20:00Z",
      "requestId": "req_88f9a0c2"
    }
  }
  ```

---

## 2. API Endpoint Matrix

| Module | Method | Path | Description | Required Role |
|---|---|---|---|---|
| **Auth** | POST | `/api/auth/login` | Authenticate user & issue session token | Public |
| **Auth** | GET | `/api/auth/me` | Retrieve active profile & permissions | Any Authenticated |
| **Incidents** | GET | `/api/incidents` | List incidents with filters & pagination | Observer+ |
| **Incidents** | POST | `/api/incidents` | Create a new operational incident | Responder+ |
| **Incidents** | GET | `/api/incidents/:id` | Get incident details & timeline | Observer+ |
| **Incidents** | PATCH | `/api/incidents/:id` | Update severity, status, or assignee | Responder+ |
| **Evidence** | POST | `/api/incidents/:id/evidence` | Ingest logs, metrics, or git diffs | Responder+ |
| **AI Investigation** | POST | `/api/incidents/:id/investigate`| Run AI investigation agent + Hindsight recall | Responder+ |
| **Postmortems** | POST | `/api/incidents/:id/postmortem` | Draft and submit incident postmortem | DevOps+ |
| **Approvals** | GET | `/api/knowledge-approvals` | List pending postmortem memory approvals | Admin+ |
| **Approvals** | POST | `/api/knowledge-approvals/:id/review` | Approve or reject memory retention | Admin+ |
| **Memory** | GET | `/api/memory/banks` | List organization memory bank metrics | Observer+ |
| **Memory** | POST | `/api/memory/recall` | Associative search in Hindsight memory | Responder+ |
| **Audit Logs** | GET | `/api/audit-logs` | Query append-only audit trail | Admin+ |
| **Analytics** | GET | `/api/analytics` | Retrieve MTTR and memory reuse metrics | Observer+ |
| **Demo** | POST | `/api/simulate-two-incident-journey`| Execute end-to-end memory reuse simulation | Any Authenticated |
