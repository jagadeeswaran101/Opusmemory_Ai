# Hackathon Demo Script: The Two-Interaction Memory Reuse Journey

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 12 — Hackathon Demo & Submission Package  
**Status:** VERIFIED  

---

## 1. Demo Setup & Rules

- **Total Duration:** 3–4 minutes.
- **Narrator Persona:** Marcus Vance (DevOps Lead) & Elena Rostova (Operations Admin).
- **Synthetic Data Disclaimer:** All diagnostic logs and metrics are clearly labelled as synthetic operational data for demonstration safety.
- **Target Audience:** Hackathon Judges, VP of Engineering, SRE Directors, Platform Engineers.

---

## 2. Interaction 1: The Initial Outage & Memory Commitment

### Step 1: Incident Alert & Evidence Ingestion
- **Action:** Open OpsMemory AI Dashboard. Navigate to Incident Console.
- **Presenter:** "It's 2:15 AM. A critical SEV-1 alert fires: *Incident #142 — PostgreSQL Connection Pool Saturation on Payments DB*. The payments microservice is throwing HTTP 500 spikes."
- **Screen:** Show Incident #142 details. Point out attached synthetic technical evidence:
  - `LOG_SNIPPET`: `FATAL: remaining connection slots are reserved for non-replication superuser connections (SQLSTATE 53300)`.
  - `METRIC_SERIES`: HikariCP active connections plateaued at 100/100 slots for 18 minutes.
  - `DEPLOYMENT_DIFF`: Release `v2.4.1` deployed 32 minutes ago added an unpaginated batch query.

### Step 2: Trigger AI Investigation (First Interaction)
- **Action:** Click `Run AI Investigation`.
- **Presenter:** "Because this specific issue hasn't been codified yet, Hindsight memory returns no past exact matches. The agent synthesizes a baseline report adhering to our strict 5-part contract:"
- **Screen:** Highlight:
  - *Observed Facts:* Concrete error 53300, 100/100 pool cap.
  - *Hypotheses:* Likely HikariCP pool leak or query timeout pinning.
  - *Recommended Diagnostic Check:* Read-only query: `SELECT pid, state, query FROM pg_stat_activity WHERE state != 'idle';` (Click 'Copy Command').

### Step 3: Resolution & Postmortem Creation
- **Action:** Click `Resolve & Postmortem`.
- **Presenter:** "Marcus runs the diagnostic, identifies idle connections left open by unpaginated queries, and applies the fix: adding `spring.datasource.hikari.maxLifetime=1800000` and `idleTimeout=600000`. The outage is mitigated. Now Marcus authors the official postmortem and submits it for knowledge approval."
- **Screen:** Show Postmortem modal with root cause, trigger event, and resolution playbook. Click `Submit to Approval Queue`.

### Step 4: Governance Gate & Hindsight Retain
- **Action:** Switch persona to Elena Rostova (`OPERATIONS_ADMIN`) and navigate to `Knowledge Approval Queue`.
- **Presenter:** "Rule BR-03 dictates: no unverified AI hallucinations can enter institutional memory. Elena reviews the verified playbook and clicks `Approve & Commit to Hindsight`."
- **Screen:** Click `Approve & Commit to Hindsight`. Show memory successfully committed: `mem_payments_db_142` assigned by Hindsight.

---

## 3. Interaction 2: The Repeat Alert & Instant Cognitive Recall

### Step 5: Second Incident Fires (Similar Database Failure)
- **Action:** Navigate to Incident Console and click `Report Incident` (or trigger via the Two-Incident E2E Studio).
- **Incident Data:** Title: *Checkout Service DB Connection Pool Saturation (SQLSTATE 53300)*; Service: `checkout-db`.
- **Presenter:** "Two weeks later, Black Friday traffic spikes and an alert fires on the checkout database. An inexperienced junior responder takes the page. In the past, they would panic and spend 60 minutes rediscovering the fix."

### Step 6: Investigation with Active Memory Recall
- **Action:** Click `Run AI Investigation`.
- **Presenter:** "Watch what happens now. The Investigation Agent instantly queries Hindsight memory bank `org_acme_prod_ops`. Look at section 2 of the report:"
- **Screen:** Show the 5-Part Epistemological Findings:
  - **Section 2 (Recalled Historical Memories):** Highlights Incident #142 memory with **94% similarity score**!
  - **Source Attribution:** Shows exact link to Incident #142.
  - **Verified Playbook Citation:** Displays the exact playbook approved by Elena: `Configure spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000`.
  - **Confidence:** Spikes from baseline 60% to **98% confidence**.

### Step 7: Conclusion & Business Impact
- **Presenter:** "The junior responder applies the verified playbook in under 3 minutes. Mean Time to Resolution dropped by 90%, zero production commands were executed blindly, and the organization's institutional knowledge got permanently smarter."
