# Page Inventory & Route Map

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Complete Page Directory (36 Functional Modules)

### Public Pages
1. `Landing Page` (Product value prop, architecture overview, live demo preview)
2. `Product Features` (Epistemological AI, Hindsight persistent memory, multi-tenant RBAC)
3. `How It Works` (Incident → Evidence → Hindsight Recall → Resolution → Retain)
4. `Pricing` (Starter, Pro, Enterprise tiers)
5. `Login` (Email/password, SSO, demo quick-login)
6. `Registration` (Organization onboarding & workspace provisioning)
7. `Forgot Password` (Secure email reset)
8. `Privacy Policy` (Data retention, tenant isolation guarantees)
9. `Terms of Service` (Enterprise SLA, acceptable use)

### Authenticated Application
10. `Onboarding Wizard` (Tenant name, team members, initial cloud integrations)
11. `Organization Setup` (SSO, Slack/PagerDuty webhook settings)
12. `Main Dashboard` (Active incidents, MTTR telemetry, memory reuse rate, system health)
13. `Incident List` (Multi-filter triage table: severity, status, assigned SRE)
14. `Incident Details` (Metadata, status flow, assigned engineer, timeline)
15. `Create Incident Modal / Form` (Title, service, severity, initial summary)
16. `Evidence Explorer` (Logs, metrics series, git diffs, stack traces with raw payload viewer)
17. `Investigation Workspace` (AI investigation trigger, progress indicator, real-time reasoning)
18. `AI Findings Inspector` (5-part separation: Facts, Memories, Hypotheses, Checks, Unknowns)
19. `Recommendations Panel` (Safe read-only diagnostics with copy-to-clipboard)
20. `Historical Incident Search` (Fast search across all past organization outages)
21. `Memory Explorer` (Hindsight memory banks, retained items, semantic similarity inspector)
22. `Knowledge Approval Queue` (Admin review list for postmortems awaiting retention)
23. `Postmortem Editor` (Root cause, trigger event, resolution playbook, prevention items)
24. `Analytics Dashboard` (MTTR trend, incident frequency by service, memory efficiency score)
25. `Integrations Hub` (Hindsight cluster, PostgreSQL, PagerDuty, Datadog webhooks)
26. `Notification Center` (Urgent alerts, approval requests, incident assignments)
27. `Team Management` (Invite members, role assignment, active responders)
28. `User Profile` (Personal preferences, on-call schedule, API tokens)
29. `Organization Settings` (Tenant slug, memory bank prefix, data retention policies)
30. `Security & Audit Logs` (Filterable immutable audit trail with actor, action, timestamp)
31. `Help & Documentation` (In-app comprehensive engineering documentation browser)

### Administrative & Verification
32. `Platform Admin Dashboard` (Tenant health, total memory vectors, system load)
33. `Organization Management` (Tenant provisioning, tier upgrades)
34. `System Health & Diagnostics` (PostgreSQL connection pool, Hindsight engine ping)
35. `Usage Monitoring` (API requests, LLM token consumption, memory retentions)
36. `Critical Two-Incident E2E Demo Studio` (Interactive execution of Incident 1 → Retain → Incident 2 → Recall)
