# Responsive Design & Multi-Device Strategy

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Breakpoint Taxonomy

- **Desktop Large (1440px+):** Full multi-column view; sidebar expanded; dual-pane evidence vs investigation workspace.
- **Desktop Standard (1024px – 1439px):** Sidebar compact icon-mode; dual-pane workspace with adjustable width.
- **Tablet (768px – 1023px):** Stacked panes with tab switcher (`Evidence` vs `Investigation Findings`); responsive tables with horizontal scroll guards.
- **Mobile Handheld (390px – 767px):** Mobile app shell; bottom/sheet navigation; full-width stacked incident cards and high-contrast alert notifications for on-call triage.
