# Accessibility Compliance (WCAG 2.1 AA)

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Accessibility Standards Applied

1. **Color Contrast:** All body text meets at least 4.5:1 contrast against `#0B0F19` and `#111827` background surfaces. Large headers exceed 7:1.
2. **Keyboard Navigation:** Full keyboard support (`Tab`, `Shift+Tab`, `Enter`, `Escape`) across all interactive elements (modals, dropdowns, evidence expanders, copy buttons).
3. **Screen Reader Semantic Tree:** Native semantic elements (`<main>`, `<nav>`, `<aside>`, `<header>`, `<h1>`–`<h3>`, `<button>`, `<label>`). Icon-only buttons include descriptive `aria-label` attributes.
4. **Focus Rings:** Visible, high-contrast cyan focus indicators (`focus-visible:ring-2 focus-visible:ring-cyan-400 focus-visible:outline-none`).
5. **No Color-Only Information:** Severity indicators pair color with explicit text labels (`SEV-1 Critical`, `SEV-2 Major`, etc.).
