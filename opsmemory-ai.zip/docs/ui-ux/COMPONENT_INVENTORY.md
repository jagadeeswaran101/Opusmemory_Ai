# Component Inventory & Design Tokens

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Atoms & Primitives

- `SeverityBadge`: Colored visual pill (`SEV-1 Critical` red, `SEV-2` orange, `SEV-3` amber, `SEV-4` blue).
- `StatusBadge`: State indicator (`TRIGGERED` purple, `INVESTIGATING` cyan, `IDENTIFIED` yellow, `MITIGATED` blue, `RESOLVED` emerald).
- `EvidenceTypeIcon`: Lucide icon mapping for Logs (FileText), Metrics (Activity), Diffs (GitCommit), StackTraces (AlertTriangle).
- `SafeCommandBlock`: Monospace snippet with one-click copy, syntax highlight, and "Read-Only Safe" badge.
- `ConfidenceMeter`: Visual percentage bar and numerical badge (0–100%).

---

## 2. Molecular & Organism Components

- `IncidentCard`: Compact summary card with title, severity, service, timestamp, assigned responder, and quick-action trigger.
- `EvidenceTimeline`: Chronological feed of attached logs, metric timeseries charts, and git diffs.
- `InvestigationReportViewer`: Structured 5-section layout strictly isolating Facts, Memories, Causes, Diagnostic Checks, and Unknowns.
- `MemoryBankCard`: Overview card for Hindsight memory banks showing total memories, bank ID, retention health, and recall latency.
- `ApprovalReviewModal`: Side-by-side postmortem review pane with approve/reject buttons and review notes textarea.
- `TwoIncidentSimulator`: Interactive dual-terminal verification console demonstrating memory retention in Incident 1 and memory recall in Incident 2.
- `AuditLogTable`: Searchable, filterable table rendering timestamp, actor, action, resource, and JSON details expander.
