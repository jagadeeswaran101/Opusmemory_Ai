# UI/UX Design System Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Visual Direction & Principles

OpsMemory AI uses an enterprise dark navy operational aesthetic designed for high information density, rapid scanning under stress, and zero decorative visual noise.

### Palette
- **Canvas Base:** `#0B0F19` (Deep Obsidian Navy)
- **Card / Surface:** `#111827` (Rich Slate Dark)
- **Elevated Hover / Panel:** `#1E293B` (Bordered Slate)
- **Borders & Dividers:** `#334155` (Subtle Slate Border)
- **Primary Accent:** `#06B6D4` (Restrained Cyan — Focus, Interactive primary controls)
- **Secondary Accent:** `#6366F1` (Indigo — Analytical metrics, AI reasoning highlights)
- **Severity Tokens:**
  - `SEV-1 Critical`: `#EF4444` (Ruby Crimson)
  - `SEV-2 Major`: `#F97316` (Deep Orange)
  - `SEV-3 Moderate`: `#F59E0B` (Amber)
  - `SEV-4 Minor`: `#3B82F6` (Operational Blue)
- **Success / Retained Token:** `#10B981` (Emerald Teal)

### Typography
- Primary: Inter / SF Pro / system sans-serif.
- Monospace: JetBrains Mono / Roboto Mono / Menlo (Log snippets, SQL diagnostics, Git commit diffs).
