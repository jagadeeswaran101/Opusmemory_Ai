# User Flows & Interaction Architecture

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Flow 1: Live Incident Investigation & Memory Recall

```
[ Dashboard ] 
    │ (Click active SEV-1 Incident)
    ▼
[ Incident Workspace ]
    ├── Step 1: Review Evidence Timeline (Logs show 53300 error, Metrics show 100/100 pool)
    ├── Step 2: Click "Run AI Investigation"
    ├── Step 3: Agent queries Hindsight: recall(bank_id, symptoms)
    ├── Step 4: UI highlights "Recalled Historical Memory: Incident #89 (94% match)"
    ├── Step 5: SRE reviews 5-part findings:
    │           - Facts: 53300 PostgreSQL error, HikariCP pool exhausted
    │           - Memories: Incident #89 resolved by setting maxLifetime & idleTimeout
    │           - Hypotheses: High likelihood pool leak in v2.4.1 routine
    │           - Safe Checks: Copy `SELECT pid, state, query FROM pg_stat_activity...`
    │           - Unknowns: pgbouncer configuration
    └── Step 6: SRE runs check, confirms leak, applies fix, transitions status to MITIGATED.
```

---

## 2. Flow 2: Postmortem, Human Approval, and Hindsight Retention

```
[ Incident Workspace ]
    │ (Incident marked RESOLVED)
    ▼
[ Open Postmortem Editor ]
    ├── SRE drafts Root Cause, Resolution Playbook, and Prevention Items
    └── Click "Submit to Knowledge Approval Queue"
    │
    ▼
[ Knowledge Approval Queue (Operations Admin View) ]
    ├── Admin reviews technical quality and verified playbook
    ├── Admin clicks "Approve & Retain to Institutional Memory"
    ├── Backend executes Hindsight `retain(bank_id, postmortem)`
    └── Memory Explorer confirms new memory ID committed and indexed.
```
