# Wireframe Specifications & Layout Hierarchy

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 4 — UI/UX Design & All Application Pages  
**Status:** VERIFIED  

---

## 1. Incident Detail & Investigation Workspace Layout

```
┌────────────────────────────────────────────────────────────────────────────┐
│ TOP BAR: Breadcrumbs > Incidents > #142 (SEV-1 Critical) [IDENTIFIED]      │
│ Status Actions: [ Mark Mitigated ] [ Resolve & Postmortem ] [ Assignee v ] │
├───────────────────────────────────┬────────────────────────────────────────┤
│ LEFT PANE (45% Width):            │ RIGHT PANE (55% Width):                │
│ ATTACHED EVIDENCE & TELEMETRY     │ AI INVESTIGATION & RECALLED MEMORY     │
│                                   │                                        │
│ [+ Attach Evidence] [Filter: All] │ [ Run AI Investigation ] [Refresh]     │
│                                   │ ────────────────────────────────────── │
│ 1. [LOG] 09:18:42                 │ CONFIDENCE: 94% (High Alignment)       │
│    FATAL: remaining connection... │ ────────────────────────────────────── │
│    [View Raw JSON]                │ 1. OBSERVED FACTS (3 facts)            │
│                                   │    • Error 53300 on port 5432          │
│ 2. [METRIC] Connection Pool       │    • Pool reached 100/100 cap          │
│    Active: 100/100 (Maxed Out)    │                                        │
│    [Sparkline Chart]              │ 2. RECALLED HISTORICAL MEMORIES (1)    │
│                                   │    ★ Inc #89 (HikariCP leak, 94% match)│
│ 3. [DIFF] Git Commit 8f2a1b       │       Fix: set maxLifetime & idleTimeout│
│    release/v2.4.1                 │                                        │
│    + batchInvoiceQuery()          │ 3. POSSIBLE ROOT CAUSES                │
│                                   │    [HIGH] Missing pool timeout config  │
│                                   │                                        │
│                                   │ 4. RECOMMENDED DIAGNOSTIC CHECKS       │
│                                   │    [SAFE] SELECT * FROM pg_stat_activity│
│                                   │    [Copy Command]                      │
│                                   │                                        │
│                                   │ 5. UNKNOWN INFORMATION                 │
│                                   │    • pgbouncer deployment status       │
└───────────────────────────────────┴────────────────────────────────────────┘
```
