# Data Retention & Lifecycle Policy

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. Retention Tiers & Durability

| Entity Type | Retention Period | Storage Location | Archival Strategy |
|---|---|---|---|
| **Incident Metadata** | 7 Years (Compliance) | PostgreSQL Primary | Indexed, Partitioned by Year |
| **Raw Telemetry Evidence** | 90 Days active | Object Storage / JSONB | Compressed or summarized into postmortem |
| **Approved Postmortems** | Indefinite | PostgreSQL Primary | Core institutional record |
| **Hindsight Memories** | Indefinite (Decay weighted) | Hindsight Vector Bank | Cognitive recall priority decays if unreferenced for 24 months |
| **Audit Logs** | 7 Years | PostgreSQL Audit Table | Immutable append-only log; write-once read-many |

---

## 2. Right to Erasure (GDPR / CCPA)

When an organization requests data deletion:
1. PostgreSQL executes `DELETE FROM organizations WHERE id = $org_id CASCADE`.
2. Hindsight Memory Engine deletes the associated memory bank (`DELETE /banks/org_{orgId}_ops`).
3. An audit log tombstone is recorded for compliance verification.
