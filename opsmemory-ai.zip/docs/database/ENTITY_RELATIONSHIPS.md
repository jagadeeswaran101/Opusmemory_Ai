# Entity Relationships Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. Relational Map

```
Organization (1)
├── (N) Users (Owner, Admin, DevOps, Responder, Observer)
├── (N) Incidents
│   ├── (N) IncidentEvidence (Logs, Metrics, Diffs, StackTraces)
│   ├── (N) Investigations (Epistemological 5-Part Reports)
│   └── (1) Postmortem
│       ├── (1) KnowledgeApproval (Pending / Approved / Rejected)
│       └── (1) Hindsight Memory Link (memory_id)
└── (N) AuditLogs (Append-Only Event Ledger)
```

---

## 2. Referential Integrity & Cascade Rules

- **Organization Deletion:** Deleting an organization cascades deletions across all subsidiary users, incidents, evidence, investigations, postmortems, approvals, and audit logs.
- **Incident Deletion:** Deleting an incident cascades to its attached evidence items and investigations.
- **User Deletion:** Deleting a user nullifies references in incidents (`assigned_user_id = NULL`), preserving incident timeline fidelity.
- **Postmortem Retention:** Deleting an incident revokes associated pending approvals. Retained memories in Hindsight are tombstoned via the Hindsight memory adapter.
