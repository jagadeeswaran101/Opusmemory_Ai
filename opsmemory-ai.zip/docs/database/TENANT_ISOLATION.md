# Tenant Isolation Architecture & Security Controls

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 3 — Database Design & API Contracts  
**Status:** VERIFIED  

---

## 1. Multi-Tenant Isolation Defense-in-Depth

OpsMemory AI implements four discrete isolation rings to guarantee zero cross-tenant contamination:

### Ring 1: API Gateway & Context Injection
Every authenticated HTTP request must carry an authorization token. The middleware decodes the token, verifies the user, queries their organization membership, and binds `ctx.organizationId` to the execution request context. Requests without verified organization scope are rejected immediately with HTTP 401/403.

### Ring 2: Database Query Layer (PostgreSQL Row-Level Security)
All database queries enforce `WHERE organization_id = $tenant_id`. In addition, PostgreSQL Row-Level Security (RLS) policies are active:
```sql
ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_policy ON incidents
    USING (organization_id = current_setting('app.current_tenant_id')::uuid);
```

### Ring 3: Hindsight Memory Bank Namespacing
Hindsight long-term memories are strictly partitioned into isolated cognitive memory banks using the format:
`bank_id: "org_" || organization_id || "_ops"`
The Hindsight client rejects any query attempt that does not supply a valid tenant-bound bank ID.

### Ring 4: Automated Cross-Tenant Regression Testing
Automated integration tests create two distinct test tenants (`tenant-alpha` and `tenant-beta`) and verify that Tenant Alpha cannot read, search, update, or recall memories belonging to Tenant Beta.
