# Memory Evaluation & Recall Benchmark Metrics

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Benchmark Criteria & Targets

To verify that OpsMemory AI's long-term memory engine is functioning effectively in production, the following evaluation metrics are tracked:

1. **Recall Precision@3:** Minimum 90% relevance among the top 3 recalled memories for incidents with existing historical precedents.
2. **Mean Time to Recall:** p95 latency under 600ms across 10,000 retained incident postmortems.
3. **Memory Reuse Velocity:** Percentage of resolved incidents where the approved postmortem cited at least one recalled historical memory (Target: > 35%).
4. **False Positive Rate:** < 5% irrelevant memories recalled above 0.70 confidence threshold.
