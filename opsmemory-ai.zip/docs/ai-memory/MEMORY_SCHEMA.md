# Memory Schema & Document Taxonomy

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Retain Document Schema (JSON)

When an approved postmortem is sent to Hindsight, the payload adheres to this strict schema:

```json
{
  "bank_id": "org_default_01_ops",
  "document": {
    "title": "HikariCP Connection Leak under High Concurrency",
    "incident_number": 89,
    "service": "payments-db",
    "severity": "SEV-1",
    "symptoms": [
      "PostgreSQL error 53300",
      "FATAL: remaining connection slots are reserved",
      "Active pool maxed at 100/100 connections",
      "Spike occurred during batch invoice settlement run"
    ],
    "root_cause": "HikariCP datasource missing maxLifetime and idleTimeout configurations in payments-service deployment.",
    "resolution_playbook": "1. Update deployment config with spring.datasource.hikari.maxLifetime=1800000 and idleTimeout=600000.\n2. Perform rolling restart of payments-service pods.\n3. Verify connection count returns to baseline < 20.",
    "diagnostic_checks_verified": [
      "SELECT pid, state, query, age(clock_timestamp(), query_start) FROM pg_stat_activity WHERE state != 'idle';"
    ],
    "prevention_measures": [
      "Add automated CI check for connection pool timeouts.",
      "Provision PgBouncer connection pooler in staging."
    ]
  },
  "metadata": {
    "source_incident_id": "inc_20260814_004",
    "postmortem_id": "pm_883a",
    "approved_by_user_id": "usr_admin_01",
    "approved_at": "2026-08-15T14:30:00Z",
    "retention_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
  }
}
```

---

## 2. Memory Recall Response Schema

```json
{
  "memory_id": "mem_pg_pool_0814",
  "similarity_score": 0.94,
  "incident_number": 89,
  "title": "HikariCP Connection Leak under High Concurrency",
  "service": "payments-db",
  "key_symptoms": ["PostgreSQL 53300", "Connection pool 100/100"],
  "root_cause": "HikariCP missing maxLifetime & idleTimeout",
  "resolution_playbook": "Configure maxLifetime=1800000 & idleTimeout=600000",
  "source_incident_url": "/incidents/inc_20260814_004"
}
```
