# Memory Retrieval Strategy & Hybrid Scoring

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Hybrid Retrieval Scoring Formula

When an incident triggers a recall request, candidate memories are ranked using a hybrid scoring algorithm combining semantic embedding proximity, exact token matches (error codes, services), and recency weighting:

$$\text{FinalScore} = 0.50 \cdot S_{\text{semantic}} + 0.30 \cdot S_{\text{token}} + 0.15 \cdot S_{\text{service}} + 0.05 \cdot S_{\text{recency}}$$

Where:
- $S_{\text{semantic}} \in [0, 1]$: Cosine similarity between query embedding and memory document vector.
- $S_{\text{token}} \in [0, 1]$: Exact match ratio on extracted error codes (e.g. `53300`, `ECONNRESET`, `OOMKilled`).
- $S_{\text{service}} \in \{0, 1\}$: Binary or fuzzy match on affected infrastructure service (e.g. `payments-db`).
- $S_{\text{recency}} \in [0, 1]$: Temporal decay prioritizing recent operational architectures over deprecated patterns.

Memories with a final score $\ge 0.65$ are presented to the investigator as high-confidence historical precedents.
