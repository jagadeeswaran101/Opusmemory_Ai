# Memory Lifecycle & Retention Governance

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Ten-Step Memory Lifecycle

1. **Incident Occurs:** Incident is created in PostgreSQL with status `TRIGGERED`.
2. **Evidence Attached:** Responders attach logs, metrics series, and git diffs.
3. **AI Investigation with Recall:** System queries Hindsight memory bank via `recall()` using current symptoms to retrieve past precedent.
4. **Triage & Diagnosis:** Responders execute recommended safe diagnostics, identify root cause, and apply mitigation.
5. **Incident Resolved:** Status updated to `RESOLVED` in PostgreSQL.
6. **Postmortem Prepared:** DevOps lead drafts structured postmortem (symptoms, root cause, playbook, prevention).
7. **Human Approval:** Postmortem submitted to Knowledge Approval Queue; Operations Admin approves resolution.
8. **Hindsight Retain Execution:** Memory payload sent via Hindsight `retain()`. Memory ID returned.
9. **PostgreSQL Linking:** Memory ID and commit timestamp stored in PostgreSQL `postmortems` record.
10. **Institutional Reuse:** Future incidents with matching symptoms recall this verified knowledge item.
