# Memory Engine Failure Handling & Circuit Breaker

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Resiliency & Graceful Degradation Matrix

| Failure Mode | Detection | System Action | User Impact |
|---|---|---|---|
| **Hindsight Service Offline / Timeout** | 3 consecutive timeouts (`> 1500ms`) | Circuit breaker trips to OPEN; request routed to in-memory local fallback vector store | Zero incident triage outage; UI displays `Memory Status: Local Resilient Mode` |
| **Network Partition between App & Hindsight** | TCP connection refused / RST | Fallback vector store activated; retention jobs queued in PostgreSQL retry table | Incident triage and postmortem creation succeed |
| **Duplicate Retain Submission** | Payload SHA-256 collision on `retention_hash` | Idempotent response returning existing `memory_id` | No duplicate memory bloat |
| **Malformed Postmortem Payload** | JSON Schema validation failure | Retention rejected with HTTP 422 before calling Hindsight | Clear validation error returned to author |
