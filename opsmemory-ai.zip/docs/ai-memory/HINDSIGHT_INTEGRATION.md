# Hindsight Integration & Cognitive Memory Specification

**Product:** OpsMemory AI  
**Baseline Version:** 0.1.0  
**Phase:** 6 — Hindsight Memory Engine  
**Status:** VERIFIED  

---

## 1. Official Hindsight Architecture

OpsMemory AI integrates with Hindsight (`https://github.com/vectorize-io/hindsight`) as its persistent cognitive memory engine:

```
┌────────────────────────────────────────────────────────┐
│               OpsMemory AI Backend Tier                │
│                                                        │
│  [ Postmortem Approved ]   [ Incident Under Triage ]   │
│            │                           │               │
│            ▼                           ▼               │
│    Hindsight Retain            Hindsight Recall        │
└────────────┬───────────────────────────┬───────────────┘
             │                           │
             ▼                           ▼
┌────────────────────────────────────────────────────────┐
│             Hindsight Memory Engine API                │
│                                                        │
│  - Bank Partitioning: bank_id = "org_{orgId}_ops"      │
│  - Associative Index: Semantic + Graph Entities        │
│  - Epistemic Decay & Confidence Weighting              │
│  - Synthesized Cross-Incident Reflection               │
└────────────────────────────────────────────────────────┘
```

---

## 2. Supported Primitives & Signatures

1. **`retain(bank_id, document, metadata)`**
   - Stores approved operational knowledge (root cause, fix playbook, symptoms, service) in the tenant's memory bank.
   - Generates an immutable `memory_id` and indexing vector.
2. **`recall(bank_id, query, filter, limit)`**
   - Semantically searches the tenant's memory bank for previous postmortems matching the query symptom vector.
   - Returns matched memories with similarity scores and source incident attribution.
3. **`reflect(bank_id, topic)`**
   - Synthesizes recurring incident patterns across multiple past outages to expose architectural fragility.
